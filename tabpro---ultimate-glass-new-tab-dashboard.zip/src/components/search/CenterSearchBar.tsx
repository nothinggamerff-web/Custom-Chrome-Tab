import React, { useState, useEffect, useRef } from 'react';
import { Search, ChevronDown, Move } from 'lucide-react';
import { SearchEngine, ElementPosition, ElementThemeStyle } from '../../types';
import { getFaviconUrl } from '../../utils/favicon';
import { useDraggable } from '../../hooks/useDraggable';
import { getThemeSurfaceClasses } from '../../utils/theme';

interface CenterSearchBarProps {
  position: ElementPosition;
  width: number;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
  scale?: number;
  themeStyle?: ElementThemeStyle;
  onLaunchApp?: (title: string, url: string) => void;
  accentColor?: string;
}

interface EngineOption {
  id: SearchEngine;
  name: string;
  url: string;
  domain: string;
  fallbackIcon: string;
  placeholder: string;
  color: string;
}

const SEARCH_ENGINES: EngineOption[] = [
  { id: 'google', name: 'Google', url: 'https://www.google.com/search?q=', domain: 'google.com', fallbackIcon: '🔍', placeholder: 'Search Google or enter URL...', color: '#4285F4' },
  { id: 'youtube', name: 'YouTube', url: 'https://www.youtube.com/results?search_query=', domain: 'youtube.com', fallbackIcon: '▶️', placeholder: 'Search YouTube videos & music...', color: '#FF0000' },
  { id: 'duckduckgo', name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=', domain: 'duckduckgo.com', fallbackIcon: '🦆', placeholder: 'Search DuckDuckGo private web...', color: '#DE5833' },
  { id: 'bing', name: 'Bing', url: 'https://www.bing.com/search?q=', domain: 'bing.com', fallbackIcon: '🌐', placeholder: 'Search Bing...', color: '#00809D' },
  { id: 'github', name: 'GitHub', url: 'https://github.com/search?q=', domain: 'github.com', fallbackIcon: '🐙', placeholder: 'Search GitHub repositories & code...', color: '#24292e' },
  { id: 'reddit', name: 'Reddit', url: 'https://www.reddit.com/search/?q=', domain: 'reddit.com', fallbackIcon: '💬', placeholder: 'Search Reddit discussions...', color: '#FF4500' },
  { id: 'wikipedia', name: 'Wikipedia', url: 'https://en.wikipedia.org/wiki/Special:Search?search=', domain: 'wikipedia.org', fallbackIcon: '📖', placeholder: 'Search Wikipedia knowledge...', color: '#636466' },
  { id: 'x', name: 'X / Twitter', url: 'https://x.com/search?q=', domain: 'x.com', fallbackIcon: '𝕏', placeholder: 'Search posts & trends on X...', color: '#000000' },
];

export const CenterSearchBar: React.FC<CenterSearchBarProps> = ({
  position,
  width,
  isDragMode = false,
  onPositionChange,
  scale = 1,
  themeStyle = 'oled',
  onLaunchApp,
  accentColor = '#ff453a'
}) => {
  const [engine, setEngine] = useState<SearchEngine>(() => {
    return (localStorage.getItem('tabpro_search_engine') as SearchEngine) || 'google';
  });
  const [query, setQuery] = useState('');
  const [showEngineDropdown, setShowEngineDropdown] = useState(false);
  const [failedFavicons, setFailedFavicons] = useState<Record<string, boolean>>({});
  const inputRef = useRef<HTMLInputElement>(null);

  const { elementRef: containerRef, isDragging, dragProps } = useDraggable({
    position,
    isDragMode,
    onPositionChange
  });

  const currentEngine = SEARCH_ENGINES.find((e) => e.id === engine) || SEARCH_ENGINES[0];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.key === '/' &&
        document.activeElement !== inputRef.current &&
        !['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName || '')
      ) {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (!q) return;

    if (/^(http:\/\/|https:\/\/)/i.test(q)) {
      onLaunchApp?.(q.replace(/^https?:\/\/(www\.)?/i, '').split('/')[0] || q, q);
      window.location.href = q;
      return;
    }
    if (/^[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/i.test(q)) {
      const target = `https://${q}`;
      onLaunchApp?.(q.split('/')[0], target);
      window.location.href = target;
      return;
    }

    const searchUrl = `${currentEngine.url}${encodeURIComponent(q)}`;
    onLaunchApp?.(`${currentEngine.name}: ${q}`, searchUrl);
    window.location.href = searchUrl;
  };

  const handleSelectEngine = (engId: SearchEngine) => {
    setEngine(engId);
    localStorage.setItem('tabpro_search_engine', engId);
    setShowEngineDropdown(false);
    inputRef.current?.focus();
  };

  return (
    <div
      ref={containerRef}
      {...dragProps}
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0) scale(${scale})`,
        width: `${width}px`,
        maxWidth: '92vw',
        cursor: isDragging ? 'grabbing' : isDragMode ? 'grab' : 'default',
        touchAction: isDragMode ? 'none' : 'auto'
      }}
      className={`pointer-events-auto relative mx-auto ${
        isDragging ? 'z-50' : 'z-20'
      } ${
        isDragMode ? 'p-1.5 ring-2 ring-emerald-400/80 rounded-full bg-white/5' : ''
      }`}
    >
      <form
        onSubmit={handleSearchSubmit}
        className={`group relative flex items-center gap-2 px-3.5 py-2.5 rounded-full backdrop-blur-2xl border focus-within:border-white/50 transition-all duration-200 ${getThemeSurfaceClasses(themeStyle)}`}
      >
        {isDragMode && (
          <div className="flex items-center text-emerald-400 pl-1 pr-1 cursor-grab">
            <Move className="w-3.5 h-3.5 opacity-80" />
          </div>
        )}

        {/* Engine Switcher Button with Google Favicon API Logo */}
        <button
          type="button"
          onClick={() => setShowEngineDropdown(!showEngineDropdown)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-white/10 hover:bg-white/25 text-xs font-semibold text-white/90 transition-all cursor-pointer flex-shrink-0"
          title="Switch search platform"
        >
          {!failedFavicons[currentEngine.id] ? (
            <img
              src={getFaviconUrl(currentEngine.domain)}
              alt={currentEngine.name}
              className="w-4 h-4 rounded-sm object-contain"
              onError={() =>
                setFailedFavicons((prev) => ({ ...prev, [currentEngine.id]: true }))
              }
            />
          ) : (
            <span className="text-xs">{currentEngine.fallbackIcon}</span>
          )}
          <span className="hidden sm:inline text-[11px] font-bold">{currentEngine.name}</span>
          <ChevronDown className="w-3 h-3 text-white/60" />
        </button>

        {/* Search Input */}
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={`${currentEngine.placeholder} (Press /)`}
          autoComplete="off"
          spellCheck="false"
          className="w-full bg-transparent border-none outline-none text-white placeholder-white/50 text-sm font-medium tracking-wide pr-2"
        />

        {/* Search Submit */}
        <button
          type="submit"
          className="w-8 h-8 rounded-full flex items-center justify-center bg-white/10 hover:bg-white/25 text-white/80 hover:text-white transition-all flex-shrink-0"
          title="Search"
        >
          <Search className="w-4 h-4" />
        </button>
      </form>

      {/* Engine Selection Dropdown with Real App Logos */}
      {showEngineDropdown && (
        <div className="absolute left-4 top-full mt-2 w-64 p-2 rounded-2xl bg-[#12141c]/95 backdrop-blur-2xl border border-white/20 shadow-2xl z-50 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="text-[10px] font-bold uppercase tracking-wider text-white/40 px-3 py-1.5 mb-1">
            Search Engines & Platforms
          </div>
          <div className="space-y-1">
            {SEARCH_ENGINES.map((eng) => {
              const faviconSrc = getFaviconUrl(eng.domain);
              const isSelected = eng.id === engine;

              return (
                <button
                  key={eng.id}
                  type="button"
                  onClick={() => handleSelectEngine(eng.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isSelected
                      ? 'bg-white/20 text-white shadow-sm font-bold'
                      : 'text-white/70 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <img
                      src={faviconSrc}
                      alt={eng.name}
                      className="w-4 h-4 rounded-sm object-contain"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                    <span>{eng.name}</span>
                  </div>
                  {isSelected && (
                    <span
                      className="w-1.5 h-1.5 rounded-full"
                      style={{ backgroundColor: accentColor }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { useClock } from '../../hooks/useClock';
import { useDraggable } from '../../hooks/useDraggable';
import { DigitalClockSettings, ElementPosition, ElementThemeStyle } from '../../types';

interface DigitalCenterClockProps {
  settings: DigitalClockSettings;
  position: ElementPosition;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
  scale?: number;
  themeStyle?: ElementThemeStyle;
}

export const DigitalCenterClock: React.FC<DigitalCenterClockProps> = ({
  settings,
  position,
  isDragMode = false,
  onPositionChange,
  scale = 1,
  themeStyle = 'oled'
}) => {
  const clock = useClock(false);
  const { elementRef, isDragging, dragProps } = useDraggable({
    position,
    isDragMode,
    onPositionChange
  });

  const hoursStr = settings.is12h
    ? String(clock.hours12).padStart(2, '0')
    : String(clock.hours24).padStart(2, '0');
  const minutesStr = String(clock.minutes).padStart(2, '0');
  const secondsStr = String(clock.seconds).padStart(2, '0');

  // Gradient or solid style
  const timeTextStyle: React.CSSProperties = {
    fontFamily: settings.font,
    fontSize: `${settings.fontSize * settings.scale}px`,
    lineHeight: 1,
    letterSpacing: '-0.02em',
    ...(settings.colorMode === 'gradient'
      ? {
          background: `linear-gradient(${settings.gradientAngle}deg, ${settings.gradientFrom}, ${settings.gradientTo})`,
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          filter: 'drop-shadow(0 4px 18px rgba(0,0,0,0.5))'
        }
      : {
          color: settings.solidColor,
          textShadow: '0 4px 20px rgba(0,0,0,0.6)'
        })
  };

  const getClockContainerTheme = () => {
    switch (themeStyle) {
      case 'glass':
        return 'px-6 py-3 rounded-3xl bg-white/10 backdrop-blur-xl border border-white/25 shadow-[0_16px_40px_rgba(0,0,0,0.25)]';
      case 'aurora':
        return 'px-6 py-3 rounded-3xl bg-gradient-to-br from-indigo-950/55 via-purple-950/45 to-cyan-950/55 backdrop-blur-xl border border-cyan-300/25 shadow-[0_16px_40px_rgba(56,189,248,0.18)]';
      case 'titanium':
        return 'px-6 py-3 rounded-3xl bg-slate-800/60 backdrop-blur-xl border border-slate-300/35 shadow-[0_16px_40px_rgba(148,163,184,0.2)]';
      case 'gold':
        return 'px-6 py-3 rounded-3xl bg-[#241b08]/65 backdrop-blur-xl border border-amber-400/35 shadow-[0_16px_40px_rgba(245,158,11,0.2)]';
      case 'oled':
      default:
        return '';
    }
  };

  return (
    <div
      ref={elementRef}
      {...dragProps}
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0) scale(${scale})`,
        cursor: isDragging ? 'grabbing' : isDragMode ? 'grab' : 'default',
        touchAction: isDragMode ? 'none' : 'auto'
      }}
      className={`pointer-events-auto flex flex-col items-center justify-center select-none ${getClockContainerTheme()} ${
        isDragging ? 'z-50' : 'z-20'
      } ${
        isDragMode ? 'p-2 ring-2 ring-emerald-400/80 rounded-2xl bg-white/5' : ''
      }`}
    >
      {/* Time Display */}
      <div className="flex items-baseline gap-2">
        <span style={timeTextStyle}>
          {hoursStr}:{minutesStr}
        </span>

        {settings.showSeconds && (
          <span
            style={{
              fontFamily: settings.font,
              fontSize: `${settings.fontSize * settings.scale * 0.45}px`,
              opacity: 0.85,
              ...(settings.colorMode === 'gradient'
                ? {
                    background: `linear-gradient(${settings.gradientAngle}deg, ${settings.gradientFrom}, ${settings.gradientTo})`,
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent'
                  }
                : { color: settings.solidColor })
            }}
          >
            :{secondsStr}
          </span>
        )}

        {settings.is12h && (
          <span
            className="text-xs sm:text-sm font-bold uppercase tracking-widest opacity-80 ml-1"
            style={{ color: settings.colorMode === 'solid' ? settings.solidColor : '#ffffff' }}
          >
            {clock.ampm}
          </span>
        )}
      </div>

      {/* Date Display */}
      {settings.showDate && (
        <div className="mt-2 text-sm sm:text-base font-semibold tracking-wide text-white/80 drop-shadow-md">
          {clock.dayString}, {clock.dateString}
        </div>
      )}
    </div>
  );
};

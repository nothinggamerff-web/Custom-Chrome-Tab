import React from 'react';
import { useClock } from '../../hooks/useClock';
import { ElementPosition } from '../../types';

interface TopLeftClockProps {
  position: ElementPosition;
  color?: string;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
}

export const TopLeftClock: React.FC<TopLeftClockProps> = ({
  position,
  color = '#ffffff',
  isDragMode = false,
  onPositionChange
}) => {
  const clock = useClock(false);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!isDragMode || !onPositionChange) return;
    e.preventDefault();
    const startX = e.clientX - position.x;
    const startY = e.clientY - position.y;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      onPositionChange({
        x: Math.max(0, moveEvent.clientX - startX),
        y: Math.max(0, moveEvent.clientY - startY)
      });
    };

    const handleMouseUp = () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  const hoursStr = String(clock.hours12).padStart(2, '0');
  const minutesStr = String(clock.minutes).padStart(2, '0');

  return (
    <div
      onMouseDown={handleMouseDown}
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0)`,
        color,
        cursor: isDragMode ? 'grab' : 'default'
      }}
      className={`fixed top-0 left-0 z-20 select-none ${
        isDragMode ? 'p-2 ring-2 ring-emerald-400/80 rounded-xl bg-white/5' : ''
      }`}
    >
      <div className="text-3xl font-extrabold tracking-tight drop-shadow-lg leading-none">
        {hoursStr}:{minutesStr} <span className="text-xs font-bold uppercase opacity-80">{clock.ampm}</span>
      </div>
      <div className="text-xs font-semibold opacity-75 mt-1 drop-shadow-md">
        {clock.dayString}, {clock.dateString}
      </div>
    </div>
  );
};

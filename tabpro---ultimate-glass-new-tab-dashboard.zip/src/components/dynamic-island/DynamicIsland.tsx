import React, { useState, useRef, useEffect } from 'react';
import {
  Home,
  Inbox,
  FileText,
  Clock,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Plus,
  Sliders,
  Image,
  Video,
  Settings,
  X,
  Upload,
  Trash2,
  Timer,
  CheckCircle,
  Link,
  Youtube,
  Globe,
  ExternalLink,
  XCircle
} from 'lucide-react';
import { SongTrack, LayoutSettings, ElementPosition, ElementThemeStyle, AppActivityEntry } from '../../types';
import { MusicHubModal } from './MusicHubModal';
import { useDraggable } from '../../hooks/useDraggable';
import { getIslandThemeClasses } from '../../utils/theme';
import { getFaviconUrl } from '../../utils/favicon';

interface DynamicIslandProps {
  layout: LayoutSettings;
  playlist: SongTrack[];
  onAddTrack: (track: SongTrack) => void;
  onDeleteTrack: (id: string) => void;
  onOpenControlCenter: () => void;
  onOpenWallpaperStudio: () => void;
  onOpenDrawer: () => void;
  position?: ElementPosition;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
  scale?: number;
  themeStyle?: ElementThemeStyle;
  appActivity?: AppActivityEntry[];
  onLaunchApp?: (title: string, url: string) => void;
  onCloseAppActivity?: (id: string) => void;
  onClearAppActivity?: () => void;
  accentColor?: string;
}

export const DynamicIsland: React.FC<DynamicIslandProps> = ({
  layout,
  playlist,
  onAddTrack,
  onDeleteTrack,
  onOpenControlCenter,
  onOpenWallpaperStudio,
  onOpenDrawer,
  position = { x: 0, y: 0 },
  isDragMode = false,
  onPositionChange,
  scale,
  themeStyle = 'oled',
  appActivity = [],
  onLaunchApp,
  onCloseAppActivity,
  onClearAppActivity,
  accentColor = '#ff453a'
}) => {
  const { elementRef, isDragging, dragProps } = useDraggable({
    position,
    isDragMode,
    onPositionChange,
    minMargin: 0
  });
  const [isExpanded, setIsExpanded] = useState(false);
  const [activeTab, setActiveTab] = useState<'home' | 'inbox' | 'notes' | 'timer'>('home');
  const [currentTrackIdx, setCurrentTrackIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showYtVideo, setShowYtVideo] = useState(false);
  const [showMusicHub, setShowMusicHub] = useState(false);

  // Pomodoro focus timer state (Integrated across dashboard and island!)
  const [pomoSec, setPomoSec] = useState(25 * 60);
  const [pomoRunning, setPomoRunning] = useState(false);
  const [pomoMode, setPomoMode] = useState<'work' | 'shortBreak' | 'longBreak'>('work');

  // Stopwatch state
  const [swMs, setSwMs] = useState(0);
  const [swRunning, setSwRunning] = useState(false);
  const [swLaps, setSwLaps] = useState<string[]>([]);

  // Alarm state
  const [alarmTime, setAlarmTime] = useState(() => localStorage.getItem('tabpro_alarm_time') || '');
  const [alarmRinging, setAlarmRinging] = useState(false);

  // Quick Scratchpad
  const [scratchpadText, setScratchpadText] = useState(() => localStorage.getItem('tabpro_scratchpad') || '');

  // Quick add track inputs for right card
  const [quickUrl, setQuickUrl] = useState('');

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const ytIframeRef = useRef<HTMLIFrameElement | null>(null);
  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const loadedAudioUrlRef = useRef<string>('');
  const isPlayingRef = useRef<boolean>(false);
  const [ytActiveUrl, setYtActiveUrl] = useState<string | null>(null);

  const currentTrack = playlist[currentTrackIdx] || playlist[0];

  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);

  const playChimeSound = () => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.2);
      osc.start();
      osc.stop(ctx.currentTime + 1.2);
    } catch {}
  };

  const getYouTubeEmbedUrl = (url: string) => {
    let videoId = '';
    if (url.includes('v=')) {
      videoId = url.split('v=')[1].split('&')[0];
    } else if (url.includes('youtu.be/')) {
      videoId = url.split('youtu.be/')[1].split('?')[0];
    } else if (url.includes('embed/')) {
      return url;
    }
    return `https://www.youtube.com/embed/${videoId}?autoplay=1&enablejsapi=1`;
  };

  const sendYtCommand = (func: 'playVideo' | 'pauseVideo') => {
    try {
      ytIframeRef.current?.contentWindow?.postMessage(
        JSON.stringify({ event: 'command', func, args: '' }),
        '*'
      );
    } catch {}
  };

  // Load new track ONLY when track URL changes (never reload on hover/collapse/layout updates)
  useEffect(() => {
    if (!currentTrack) return;
    if (currentTrack.isYt) {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      if (isPlayingRef.current) {
        setYtActiveUrl(currentTrack.url);
        setShowYtVideo(true);
      } else {
        setShowYtVideo(false);
      }
    } else {
      setShowYtVideo(false);
      setYtActiveUrl(null);
      if (audioRef.current && loadedAudioUrlRef.current !== currentTrack.url) {
        loadedAudioUrlRef.current = currentTrack.url;
        audioRef.current.src = currentTrack.url;
        audioRef.current.volume = Math.max(0, Math.min(1, layout.mediaVolume / 100));
        if (isPlayingRef.current) {
          audioRef.current.play().catch(() => {});
        }
      }
    }
  }, [currentTrackIdx, currentTrack?.url, currentTrack?.isYt]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = Math.max(0, Math.min(1, layout.mediaVolume / 100));
    }
  }, [layout.mediaVolume]);

  // Pomodoro timer logic
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (pomoRunning) {
      interval = setInterval(() => {
        setPomoSec((prev) => {
          if (prev <= 1) {
            setPomoRunning(false);
            playChimeSound();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [pomoRunning]);

  // Stopwatch logic
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (swRunning) {
      const startTime = performance.now() - swMs;
      interval = setInterval(() => {
        setSwMs(performance.now() - startTime);
      }, 35);
    }
    return () => clearInterval(interval);
  }, [swRunning]);

  // Alarm logic
  useEffect(() => {
    const interval = setInterval(() => {
      if (!alarmTime) return;
      const now = new Date();
      const currentHm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      if (currentHm === alarmTime && now.getSeconds() === 0) {
        playChimeSound();
        setAlarmRinging(true);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [alarmTime]);

  const handleMouseEnter = () => {
    if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    setIsExpanded(true);
  };

  const handleMouseLeave = () => {
    hoverTimeoutRef.current = setTimeout(() => {
      setIsExpanded(false);
    }, 280);
  };

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentTrack) return;
    if (currentTrack.isYt) {
      if (!ytActiveUrl || ytActiveUrl !== currentTrack.url) {
        setYtActiveUrl(currentTrack.url);
        setShowYtVideo(true);
        setIsPlaying(true);
        return;
      }
      if (isPlaying) {
        sendYtCommand('pauseVideo');
        setIsPlaying(false);
      } else {
        sendYtCommand('playVideo');
        setShowYtVideo(true);
        setIsPlaying(true);
      }
      return;
    }
    if (!audioRef.current) return;
    if (loadedAudioUrlRef.current !== currentTrack.url) {
      loadedAudioUrlRef.current = currentTrack.url;
      audioRef.current.src = currentTrack.url;
    }
    if (audioRef.current.paused) {
      audioRef.current.volume = Math.max(0, Math.min(1, layout.mediaVolume / 100));
      audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };

  const nextTrack = (e?: React.SyntheticEvent) => {
    e?.stopPropagation();
    setIsPlaying(true);
    isPlayingRef.current = true;
    setCurrentTrackIdx((prev) => (prev + 1) % playlist.length);
  };

  const prevTrack = (e?: React.SyntheticEvent) => {
    e?.stopPropagation();
    setIsPlaying(true);
    isPlayingRef.current = true;
    setCurrentTrackIdx((prev) => (prev - 1 + playlist.length) % playlist.length);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      setDuration(audioRef.current.duration || 0);
    }
  };

  const handleScrubberClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (!audioRef.current || !duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const percent = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    audioRef.current.currentTime = percent * duration;
  };

  const formatSeconds = (sec: number) => {
    if (isNaN(sec) || !isFinite(sec)) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const formatMs = (ms: number) => {
    const totalSec = Math.floor(ms / 1000);
    const m = String(Math.floor(totalSec / 60)).padStart(2, '0');
    const s = String(totalSec % 60).padStart(2, '0');
    const cs = String(Math.floor((ms % 1000) / 10)).padStart(2, '0');
    return `${m}:${s}.${cs}`;
  };

  // Upload music / video format directly
  const handleDirectUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    const cleanName = file.name.replace(/\.[^/.]+$/, '');
    const isVideoFile = file.type.startsWith('video');

    const newTrack: SongTrack = {
      id: `media-${Date.now()}`,
      title: cleanName,
      artist: isVideoFile ? 'Video Media Stream' : 'Local Audio File',
      url,
      isYt: false
    };

    onAddTrack(newTrack);
    isPlayingRef.current = true;
    setCurrentTrackIdx(playlist.length);
    setIsPlaying(true);
  };

  // Add URL directly
  const handleDirectAddUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickUrl.trim()) return;

    const isYt = /youtube\.com|youtu\.be/i.test(quickUrl);
    const newTrack: SongTrack = {
      id: `url-${Date.now()}`,
      title: isYt ? 'YouTube Track' : 'Online Stream',
      artist: isYt ? 'YouTube Music' : 'Web Audio',
      url: quickUrl.trim(),
      isYt
    };

    onAddTrack(newTrack);
    setQuickUrl('');
    isPlayingRef.current = true;
    setCurrentTrackIdx(playlist.length);
    setIsPlaying(true);
    if (isYt) {
      setYtActiveUrl(newTrack.url);
      setShowYtVideo(true);
    }
  };

  const setPomoInterval = (mins: number, mode: 'work' | 'shortBreak' | 'longBreak') => {
    setPomoRunning(false);
    setPomoMode(mode);
    setPomoSec(mins * 60);
  };

  const resolvedScale = scale ?? layout.islandScale;
  const showYtInPlayer = Boolean(
    isExpanded && activeTab === 'home' && showYtVideo && currentTrack?.isYt && ytActiveUrl
  );

  const formatRelativeTime = (ts: number) => {
    const diffSec = Math.max(0, Math.floor((Date.now() - ts) / 1000));
    if (diffSec < 60) return `${diffSec}s ago`;
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin}m ago`;
    const diffHr = Math.floor(diffMin / 60);
    return `${diffHr}h ago`;
  };

  const openApps = appActivity.filter((a) => a.status === 'open');
  const recentApps = appActivity.slice(0, 10);

  return (
    <>
      <div
        ref={elementRef}
        {...dragProps}
        style={{
          top: `${layout.islandTop}px`,
          transform: `translate3d(calc(-50% + ${position.x}px), ${position.y}px, 0) scale(${resolvedScale})`,
          cursor: isDragging ? 'grabbing' : isDragMode ? 'grab' : 'default',
          touchAction: isDragMode ? 'none' : 'auto'
        }}
        className={`fixed left-1/2 origin-top ${
          isDragging ? 'z-50' : 'z-40 transition-shadow duration-300'
        } ${
          isDragMode ? 'ring-2 ring-emerald-400/80 rounded-b-[24px]' : ''
        }`}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        <div className="relative flex justify-center">
          {/* Island Body */}
          <div
            onClick={(e) => {
              if (['BUTTON', 'INPUT', 'TEXTAREA', 'IFRAME', 'A'].includes((e.target as HTMLElement).tagName)) return;
              setIsExpanded(!isExpanded);
            }}
            className={`relative border border-t-0 select-none overflow-hidden transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] backdrop-blur-3xl ${getIslandThemeClasses(themeStyle)} ${
              isExpanded
                ? 'w-[780px] max-w-[95vw] h-[270px] rounded-b-[32px] cursor-default'
                : 'w-[320px] h-[36px] rounded-b-[20px] cursor-pointer'
            }`}
          >
            {/* Persistent YouTube Player (stays mounted when cursor leaves so playback never stops or reloads) */}
            {ytActiveUrl && (
              <div
                className={
                  showYtInPlayer
                    ? 'absolute top-[52px] left-[18px] w-[360px] max-w-[calc(50%-24px)] h-[198px] z-30 rounded-xl overflow-hidden bg-black shadow-2xl'
                    : 'absolute -left-[9999px] top-0 w-[2px] h-[2px] opacity-0 pointer-events-none'
                }
              >
                {showYtInPlayer && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowYtVideo(false);
                    }}
                    className="absolute top-2 right-2 z-30 w-6 h-6 rounded-full bg-black/80 border border-white/30 text-white flex items-center justify-center text-xs hover:bg-white/20 transition-all"
                    title="Minimize Video"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
                <iframe
                  ref={ytIframeRef}
                  key={ytActiveUrl}
                  src={getYouTubeEmbedUrl(ytActiveUrl)}
                  allow="autoplay; encrypted-media"
                  className="w-full h-full border-none"
                  title="YouTube Player"
                />
              </div>
            )}
            {/* 1. COMPACT PILL STATE */}
            {!isExpanded && (
              <div className="h-full flex items-center justify-between px-3.5 text-xs font-semibold">
                <div className="flex items-center gap-2 min-w-0 pr-2">
                  <div className="w-4 h-4 rounded-md bg-gradient-to-tr from-orange-500 via-rose-500 to-purple-600 flex-shrink-0" />
                  <span className="truncate max-w-[150px] text-[11px] font-bold text-white/90">
                    {currentTrack?.title || 'No Song Playing'}
                  </span>
                </div>

                {/* Pomodoro Indicator if Running */}
                {pomoRunning && (
                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-[10px] text-amber-300 font-mono font-bold animate-pulse">
                    <span>🍅</span>
                    <span>
                      {String(Math.floor(pomoSec / 60)).padStart(2, '0')}:
                      {String(pomoSec % 60).padStart(2, '0')}
                    </span>
                  </div>
                )}

                {/* Animated Pink Equalizer Bars */}
                <div className="flex items-center gap-[2.5px] h-3 flex-shrink-0">
                  <span className="w-[2.5px] h-full bg-pink-400 rounded-full animate-bounce [animation-delay:0.1s]" />
                  <span className="w-[2.5px] h-full bg-pink-400 rounded-full animate-bounce [animation-delay:0.35s]" />
                  <span className="w-[2.5px] h-full bg-pink-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-[2.5px] h-full bg-pink-400 rounded-full animate-bounce [animation-delay:0.5s]" />
                </div>
              </div>
            )}

            {/* 2. EXPANDED DUAL CARD STATE */}
            {isExpanded && (
              <div className="h-full flex flex-col p-3 gap-2">
                {/* Top Nav Bar */}
                <div className="flex items-center justify-between h-7 border-b border-white/10 pb-1.5 px-1">
                  {/* Left Tabs */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveTab('home')}
                      className={`p-1.5 rounded-full transition-all ${
                        activeTab === 'home'
                          ? 'bg-white/20 text-white font-bold'
                          : 'text-white/60 hover:text-white hover:bg-white/10'
                      }`}
                      title="Now Playing & Music List"
                    >
                      <Home className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setActiveTab('inbox')}
                      className={`p-1.5 rounded-full transition-all ${
                        activeTab === 'inbox'
                          ? 'bg-white/20 text-white font-bold'
                          : 'text-white/60 hover:text-white hover:bg-white/10'
                      }`}
                      title="System Connectivity"
                    >
                      <Inbox className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setActiveTab('notes')}
                      className={`p-1.5 rounded-full transition-all ${
                        activeTab === 'notes'
                          ? 'bg-white/20 text-white font-bold'
                          : 'text-white/60 hover:text-white hover:bg-white/10'
                      }`}
                      title="Quick Scratchpad"
                    >
                      <FileText className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setActiveTab('timer')}
                      className={`p-1.5 rounded-full transition-all ${
                        activeTab === 'timer'
                          ? 'bg-white/20 text-white font-bold'
                          : 'text-white/60 hover:text-white hover:bg-white/10'
                      }`}
                      title="Pomodoro & Time Hub"
                    >
                      <Clock className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Right Actions */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={onOpenControlCenter}
                      className="p-1.5 rounded-full text-white/60 hover:text-white hover:bg-white/10 transition-colors"
                      title="Quick Control Center"
                    >
                      <Sliders className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={onOpenWallpaperStudio}
                      className="p-1.5 rounded-full text-white/60 hover:text-white hover:bg-white/10 transition-colors"
                      title="Wallpaper Studio"
                    >
                      <Image className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={onOpenDrawer}
                      className="p-1.5 rounded-full text-white/60 hover:text-white hover:bg-white/10 transition-colors"
                      title="Element Customizer Studio"
                    >
                      <Settings className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* TAB 1: HOME (Left: Now Playing, Right: Music Playlist List) */}
                {activeTab === 'home' && (
                  <div className="flex-1 grid grid-cols-12 gap-3 min-h-0">
                    {/* Left Card: Now Playing Player */}
                    <div className="col-span-6 relative p-3 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between overflow-hidden shadow-inner">

                      {/* Track Info */}
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-orange-500 via-rose-500 to-purple-600 flex items-center justify-center shadow-lg flex-shrink-0">
                          {currentTrack?.isYt ? (
                            <Youtube className="w-5 h-5 text-white" />
                          ) : (
                            <span className="text-lg">🎵</span>
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-bold text-white truncate">
                            {currentTrack?.title || 'No song selected'}
                          </div>
                          <div className="text-[10px] text-white/60 truncate mt-0.5">
                            {currentTrack?.artist || 'TabPro Music Hub'}
                          </div>
                        </div>

                        {/* Equalizer */}
                        <div className="flex items-center gap-[2.5px] h-3.5 flex-shrink-0">
                          <span className="w-0.5 h-full bg-pink-400 rounded-full animate-bounce [animation-delay:0.1s]" />
                          <span className="w-0.5 h-full bg-pink-400 rounded-full animate-bounce [animation-delay:0.35s]" />
                          <span className="w-0.5 h-full bg-pink-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                          <span className="w-0.5 h-full bg-pink-400 rounded-full animate-bounce [animation-delay:0.5s]" />
                        </div>
                      </div>

                      {/* Scrubber */}
                      <div className="my-1">
                        <div className="flex justify-between text-[10px] font-mono text-white/50 mb-1">
                          <span>{formatSeconds(currentTime)}</span>
                          <span>{formatSeconds(duration || 180)}</span>
                        </div>
                        <div
                          onClick={handleScrubberClick}
                          className="w-full h-1.5 rounded-full bg-white/20 hover:bg-white/30 cursor-pointer overflow-hidden transition-all"
                        >
                          <div
                            className="h-full bg-white rounded-full transition-all duration-100"
                            style={{
                              width: `${duration ? (currentTime / duration) * 100 : 35}%`
                            }}
                          />
                        </div>
                      </div>

                      {/* Controls */}
                      <div className="flex items-center justify-between pt-1">
                        <button
                          onClick={() => setShowMusicHub(true)}
                          className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
                          title="Open Full Music Hub"
                        >
                          <Plus className="w-4 h-4" />
                        </button>

                        <div className="flex items-center gap-4">
                          <button
                            onClick={prevTrack}
                            className="text-white/80 hover:text-white transition-transform active:scale-90"
                          >
                            <SkipBack className="w-4 h-4" />
                          </button>
                          <button
                            onClick={togglePlay}
                            className="w-8 h-8 rounded-full bg-white text-black flex items-center justify-center transition-transform hover:scale-105 active:scale-95 shadow-md"
                          >
                            {isPlaying ? (
                              <Pause className="w-4 h-4 fill-black" />
                            ) : (
                              <Play className="w-4 h-4 fill-black ml-0.5" />
                            )}
                          </button>
                          <button
                            onClick={nextTrack}
                            className="text-white/80 hover:text-white transition-transform active:scale-90"
                          >
                            <SkipForward className="w-4 h-4" />
                          </button>
                        </div>

                        {currentTrack?.isYt ? (
                          <button
                            onClick={() => setShowYtVideo(!showYtVideo)}
                            className="text-xs px-2 py-0.5 rounded-full bg-red-600/30 text-red-300 border border-red-500/40 hover:bg-red-600/50 transition-colors"
                            title="Toggle in-island YouTube video"
                          >
                            Video
                          </button>
                        ) : (
                          <div className="w-6" />
                        )}
                      </div>
                    </div>

                    {/* Right Card: MUSIC PLAYLIST LIST (Replaced the Agenda side as requested!) */}
                    <div className="col-span-6 p-3 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between overflow-hidden shadow-inner">
                      <div className="flex items-center justify-between mb-1.5 pb-1 border-b border-white/10">
                        <span className="text-[10px] font-extrabold uppercase tracking-wider text-pink-400">
                          Playlist Queue ({playlist.length})
                        </span>
                        <div className="flex items-center gap-1.5">
                          {/* Upload audio or video format */}
                          <label
                            className="px-2 py-0.5 rounded-lg bg-white/10 hover:bg-white/20 text-[10px] font-bold text-white cursor-pointer flex items-center gap-1 transition-colors"
                            title="Upload music or video file"
                          >
                            <Upload className="w-3 h-3" />
                            Upload
                            <input
                              type="file"
                              accept="audio/*,video/*"
                              onChange={handleDirectUpload}
                              className="hidden"
                            />
                          </label>
                        </div>
                      </div>

                      {/* Song List with Title, Artist, and Duration/Badge */}
                      <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 max-h-[135px]">
                        {playlist.map((track, idx) => {
                          const isCurrent = idx === currentTrackIdx;
                          return (
                            <div
                              key={track.id}
                              onClick={() => {
                                isPlayingRef.current = true;
                                setIsPlaying(true);
                                setCurrentTrackIdx(idx);
                                if (track.isYt) {
                                  setYtActiveUrl(track.url);
                                  setShowYtVideo(true);
                                }
                              }}
                              className={`flex items-center justify-between p-1.5 rounded-xl cursor-pointer border text-xs transition-all ${
                                isCurrent
                                  ? 'bg-white/20 border-white/40 shadow-sm'
                                  : 'bg-white/5 border-white/5 hover:bg-white/10'
                              }`}
                            >
                              <div className="flex items-center gap-2 min-w-0 pr-1">
                                <span className="text-xs">
                                  {track.isYt ? '▶️' : '🎵'}
                                </span>
                                <div className="min-w-0">
                                  <div className="font-bold text-white truncate text-[11px]">
                                    {track.title}
                                  </div>
                                  <div className="text-[9px] text-white/60 truncate">
                                    {track.artist}
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-1 flex-shrink-0">
                                {isCurrent ? (
                                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/30 text-emerald-300">
                                    Playing
                                  </span>
                                ) : (
                                  <span className="text-[9px] text-white/40 font-mono">
                                    {track.isYt ? 'YouTube' : 'Audio'}
                                  </span>
                                )}
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onDeleteTrack(track.id);
                                  }}
                                  className="text-white/30 hover:text-red-400 p-1 transition-colors"
                                  title="Delete song"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Quick Add URL bar */}
                      <form onSubmit={handleDirectAddUrl} className="flex items-center gap-1 pt-1.5 border-t border-white/10">
                        <input
                          type="text"
                          value={quickUrl}
                          onChange={(e) => setQuickUrl(e.target.value)}
                          placeholder="Paste YouTube or music URL..."
                          className="flex-1 px-2.5 py-1 rounded-xl bg-white/10 border border-white/10 text-[10px] text-white placeholder-white/40 outline-none focus:border-pink-400"
                        />
                        <button
                          type="submit"
                          className="px-2.5 py-1 rounded-xl bg-pink-600 hover:bg-pink-500 text-[10px] font-bold text-white transition-colors"
                        >
                          Add
                        </button>
                      </form>
                    </div>
                  </div>
                )}

                {/* TAB 2: SYSTEM CONNECTIVITY (Current Open & Recent Opened/Closed Apps) */}
                {activeTab === 'inbox' && (
                  <div className="flex-1 grid grid-cols-12 gap-3 min-h-0 text-xs">
                    {/* Left Column: Current Open App & Connectivity */}
                    <div className="col-span-5 p-2.5 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between min-h-0">
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between border-b border-white/10 pb-1">
                          <span className="font-bold text-cyan-300 text-[11px]">
                            System Connectivity
                          </span>
                          <span className="font-mono text-[10px] text-emerald-400 font-bold">
                            {navigator.onLine ? '● Online' : '○ Offline'}
                          </span>
                        </div>

                        <div className="text-[9px] uppercase tracking-wider text-white/45 font-bold pt-0.5">
                          Current App Open
                        </div>

                        {openApps.length > 0 ? (
                          <div className="space-y-1 max-h-[82px] overflow-y-auto pr-0.5">
                            {openApps.map((app) => (
                              <div
                                key={app.id}
                                className="flex items-center justify-between gap-1.5 p-1.5 rounded-xl bg-emerald-500/15 border border-emerald-400/30"
                              >
                                <div className="flex items-center gap-2 min-w-0">
                                  <img
                                    src={getFaviconUrl(app.url)}
                                    alt={app.title}
                                    className="w-4 h-4 rounded-sm object-contain flex-shrink-0"
                                    onError={(e) => {
                                      (e.target as HTMLElement).style.display = 'none';
                                    }}
                                  />
                                  <div className="min-w-0">
                                    <div className="text-[11px] font-bold text-white truncate">
                                      {app.title}
                                    </div>
                                    <div className="text-[9px] text-emerald-300">
                                      Open · {formatRelativeTime(app.openedAt)}
                                    </div>
                                  </div>
                                </div>
                                <div className="flex items-center gap-1 flex-shrink-0">
                                  <a
                                    href={app.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    onClick={() => onLaunchApp?.(app.title, app.url)}
                                    className="p-1 rounded-lg bg-white/10 hover:bg-white/20 text-white/80 hover:text-white"
                                    title="Switch / Open Tab"
                                  >
                                    <ExternalLink className="w-3 h-3" />
                                  </a>
                                  <button
                                    onClick={() => onCloseAppActivity?.(app.id)}
                                    className="p-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/40 text-rose-300"
                                    title="Mark App Closed"
                                  >
                                    <XCircle className="w-3 h-3" />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 p-2 rounded-xl bg-white/5 border border-white/10">
                            <Globe className="w-4 h-4 text-cyan-300 flex-shrink-0" />
                            <div className="min-w-0">
                              <div className="text-[11px] font-bold text-white truncate">
                                TabPro Workspace
                              </div>
                              <div className="text-[9px] text-emerald-300">
                                ● Active Tab Now
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-between text-[9px] text-white/45 pt-1 border-t border-white/10">
                        <span>Media: {isPlaying ? 'Playing' : 'Standby'}</span>
                        <span>Profile Synced</span>
                      </div>
                    </div>

                    {/* Right Column: Recent Apps Opened & Closed */}
                    <div className="col-span-7 p-2.5 rounded-2xl bg-white/5 border border-white/10 flex flex-col min-h-0">
                      <div className="flex items-center justify-between border-b border-white/10 pb-1 mb-1.5">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-white/70">
                          Recent Opened & Closed Apps ({recentApps.length})
                        </span>
                        {recentApps.length > 0 && (
                          <button
                            onClick={() => onClearAppActivity?.()}
                            className="text-[9px] text-white/50 hover:text-rose-300 font-semibold transition-colors"
                          >
                            Clear
                          </button>
                        )}
                      </div>

                      {recentApps.length === 0 ? (
                        <div className="flex-1 flex items-center justify-center text-center text-[11px] text-white/45 px-4">
                          Open any app from the dock or search bar to track active & closed sessions here.
                        </div>
                      ) : (
                        <div className="flex-1 overflow-y-auto space-y-1 pr-1">
                          {recentApps.map((item) => (
                            <div
                              key={item.id}
                              className="flex items-center justify-between gap-2 px-2 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 transition-colors"
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                <img
                                  src={getFaviconUrl(item.url)}
                                  alt={item.title}
                                  className="w-4 h-4 rounded-sm object-contain flex-shrink-0"
                                  onError={(e) => {
                                    (e.target as HTMLElement).style.display = 'none';
                                  }}
                                />
                                <div className="min-w-0">
                                  <div className="text-[11px] font-bold text-white truncate">
                                    {item.title}
                                  </div>
                                  <div className="text-[9px] text-white/50 truncate">
                                    {item.status === 'open'
                                      ? `Opened ${formatRelativeTime(item.openedAt)}`
                                      : `Closed ${formatRelativeTime(item.closedAt || item.openedAt)}`}
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-1.5 flex-shrink-0">
                                <span
                                  className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                                    item.status === 'open'
                                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                                      : 'bg-white/10 text-white/55'
                                  }`}
                                >
                                  {item.status === 'open' ? 'Open' : 'Closed'}
                                </span>
                                <a
                                  href={item.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  onClick={() => onLaunchApp?.(item.title, item.url)}
                                  className="p-1 rounded-lg hover:bg-white/15 text-white/60 hover:text-white"
                                  title="Open App"
                                >
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* TAB 3: NOTES */}
                {activeTab === 'notes' && (
                  <div className="flex-1 p-2.5 rounded-2xl bg-white/5 border border-white/10 flex flex-col">
                    <textarea
                      value={scratchpadText}
                      onChange={(e) => {
                        setScratchpadText(e.target.value);
                        localStorage.setItem('tabpro_scratchpad', e.target.value);
                      }}
                      placeholder="Quick thoughts, scratchpad, snippets... (auto-saved locally)"
                      className="w-full flex-1 bg-transparent resize-none border-none outline-none text-xs text-white placeholder-white/40 leading-relaxed font-sans"
                    />
                    <div className="text-[9px] text-white/40 text-right">Auto-saved to local memory</div>
                  </div>
                )}

                {/* TAB 4: POMODORO FOCUS TIMER & TIME HUB */}
                {activeTab === 'timer' && (
                  <div className="flex-1 p-3 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between min-h-0">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Timer className="w-4 h-4 text-amber-400" />
                        <span className="text-xs font-bold text-white uppercase tracking-wider">
                          Pomodoro Focus Timer
                        </span>
                      </div>
                      {/* Interval Presets */}
                      <div className="flex gap-1">
                        <button
                          onClick={() => setPomoInterval(25, 'work')}
                          className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold transition-all ${
                            pomoMode === 'work' ? 'bg-amber-400 text-black' : 'bg-white/10 text-white/70 hover:bg-white/20'
                          }`}
                        >
                          Work (25m)
                        </button>
                        <button
                          onClick={() => setPomoInterval(5, 'shortBreak')}
                          className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold transition-all ${
                            pomoMode === 'shortBreak' ? 'bg-emerald-400 text-black' : 'bg-white/10 text-white/70 hover:bg-white/20'
                          }`}
                        >
                          Short Break (5m)
                        </button>
                        <button
                          onClick={() => setPomoInterval(15, 'longBreak')}
                          className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold transition-all ${
                            pomoMode === 'longBreak' ? 'bg-cyan-400 text-black' : 'bg-white/10 text-white/70 hover:bg-white/20'
                          }`}
                        >
                          Long Break (15m)
                        </button>
                      </div>
                    </div>

                    {/* Countdown Display */}
                    <div className="text-4xl font-light font-mono text-center tracking-tight text-white my-1">
                      {String(Math.floor(pomoSec / 60)).padStart(2, '0')}:
                      {String(pomoSec % 60).padStart(2, '0')}
                    </div>

                    {/* Action Controls */}
                    <div className="flex justify-center gap-3">
                      <button
                        onClick={() => setPomoRunning(!pomoRunning)}
                        className="px-5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black text-xs font-bold shadow-lg transition-colors"
                      >
                        {pomoRunning ? 'Pause Session' : 'Start Focus'}
                      </button>
                      <button
                        onClick={() => setPomoInterval(25, 'work')}
                        className="px-3.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold transition-colors"
                      >
                        Reset
                      </button>
                    </div>

                    <div className="text-[10px] text-white/50 text-center">
                      Plays sound automatically upon completion. Displays countdown in Dynamic Island pill!
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Hidden audio element */}
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onEnded={nextTrack}
        className="hidden"
      />

      {/* Full Music Hub Modal */}
      <MusicHubModal
        isOpen={showMusicHub}
        onClose={() => setShowMusicHub(false)}
        playlist={playlist}
        currentTrackIndex={currentTrackIdx}
        onSelectTrack={(idx) => {
          isPlayingRef.current = true;
          setCurrentTrackIdx(idx);
          setIsPlaying(true);
          const picked = playlist[idx];
          if (picked?.isYt) {
            setYtActiveUrl(picked.url);
            setShowYtVideo(true);
          }
        }}
        onAddTrack={onAddTrack}
        onDeleteTrack={onDeleteTrack}
        accentColor={accentColor}
      />
    </>
  );
};

import React, { useState } from 'react';
import { X, Music, Upload, Play, Trash2, Youtube, Radio, Plus } from 'lucide-react';
import { SongTrack } from '../../types';

interface MusicHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  playlist: SongTrack[];
  currentTrackIndex: number;
  onSelectTrack: (index: number) => void;
  onAddTrack: (track: SongTrack) => void;
  onDeleteTrack: (id: string) => void;
  accentColor?: string;
}

export const MusicHubModal: React.FC<MusicHubModalProps> = ({
  isOpen,
  onClose,
  playlist,
  currentTrackIndex,
  onSelectTrack,
  onAddTrack,
  onDeleteTrack,
  accentColor = '#ff453a'
}) => {
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');

  if (!isOpen) return null;

  const isYouTubeUrl = (testUrl: string) => {
    return /youtube\.com|youtu\.be|music\.youtube\.com/i.test(testUrl);
  };

  const handleAddTrackUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;

    const trackTitle = title.trim() || (isYouTubeUrl(url) ? 'YouTube Track' : 'Audio Stream');
    const trackArtist = artist.trim() || (isYouTubeUrl(url) ? 'YouTube Music' : 'Online Source');

    const newTrack: SongTrack = {
      id: `track-${Date.now()}`,
      title: trackTitle,
      artist: trackArtist,
      url: url.trim(),
      isYt: isYouTubeUrl(url)
    };

    onAddTrack(newTrack);
    setUrl('');
    setTitle('');
    setArtist('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const blobUrl = URL.createObjectURL(file);
    const cleanName = file.name.replace(/\.[^/.]+$/, '');

    const newTrack: SongTrack = {
      id: `local-${Date.now()}`,
      title: cleanName,
      artist: 'Local Audio File',
      url: blobUrl,
      isYt: false
    };

    onAddTrack(newTrack);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
      <div className="w-full max-w-2xl p-6 rounded-3xl bg-[#141620] border border-white/20 shadow-2xl animate-in fade-in zoom-in-95 duration-150 text-white max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 to-rose-500 flex items-center justify-center shadow-md">
              <Music className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Island Music & YouTube Stream Hub</h3>
              <p className="text-[11px] text-white/50">Add online YouTube tracks or local audio files to the Dynamic Island player</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/10 text-white/60 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Add Form */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400 mb-3 flex items-center gap-1.5">
              <Youtube className="w-4 h-4 text-rose-500" />
              Add Song or YouTube Stream
            </h4>

            <form onSubmit={handleAddTrackUrl} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-white/70 mb-1">
                  Track URL (YouTube or MP3 / AAC Audio Stream)
                </label>
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://www.youtube.com/watch?v=... or .mp3 URL"
                  required
                  className="w-full px-3 py-2 rounded-xl bg-white/10 border border-white/15 text-xs text-white placeholder-white/40 outline-none focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-white/70 mb-1">
                    Song Title
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Track Title"
                    className="w-full px-3 py-1.5 rounded-xl bg-white/10 border border-white/15 text-xs text-white placeholder-white/40 outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-white/70 mb-1">
                    Artist / Channel
                  </label>
                  <input
                    type="text"
                    value={artist}
                    onChange={(e) => setArtist(e.target.value)}
                    placeholder="Artist Name"
                    className="w-full px-3 py-1.5 rounded-xl bg-white/10 border border-white/15 text-xs text-white placeholder-white/40 outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-xs font-bold text-white shadow-md transition-all flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Track
                </button>

                <label className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white/90 border border-white/15 cursor-pointer flex items-center gap-1.5 transition-all">
                  <Upload className="w-3.5 h-3.5" />
                  Upload Audio File
                  <input
                    type="file"
                    accept="audio/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </form>

            <div className="mt-4 p-3 rounded-2xl bg-white/5 border border-white/10 text-[11px] text-white/60 space-y-1">
              <span className="font-bold text-white/90 block">✨ In-Island Video & Audio:</span>
              <p>
                When a YouTube song is selected, it embeds seamlessly <b>directly inside the Dynamic Island’s left music card</b> without interrupting your workflow.
              </p>
            </div>
          </div>

          {/* Current Playlist Queue */}
          <div className="flex flex-col">
            <h4 className="text-xs font-bold uppercase tracking-wider text-pink-400 mb-3 flex items-center justify-between">
              <span>Saved Playlist Queue ({playlist.length})</span>
            </h4>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1 max-h-[300px]">
              {playlist.map((track, idx) => {
                const isCurrent = idx === currentTrackIndex;
                return (
                  <div
                    key={track.id}
                    onClick={() => onSelectTrack(idx)}
                    className={`flex items-center justify-between p-2.5 rounded-2xl cursor-pointer border transition-all ${
                      isCurrent
                        ? 'bg-white/20 border-white/40 shadow-sm'
                        : 'bg-white/5 border-white/5 hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0 pr-2">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                          track.isYt ? 'bg-red-600' : 'bg-gradient-to-tr from-purple-600 to-indigo-600'
                        }`}
                      >
                        {track.isYt ? (
                          <Youtube className="w-4 h-4 text-white" />
                        ) : (
                          <Music className="w-4 h-4 text-white" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-white truncate">{track.title}</div>
                        <div className="text-[10px] text-white/60 truncate">{track.artist}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {isCurrent && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          Playing
                        </span>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteTrack(track.id);
                        }}
                        className="w-7 h-7 rounded-lg flex items-center justify-center text-white/40 hover:text-red-400 hover:bg-white/10 transition-colors"
                        title="Delete from playlist"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

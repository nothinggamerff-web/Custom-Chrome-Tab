import React, { useState, useEffect } from 'react';
import {
  X,
  Type,
  Clock as ClockIcon,
  Palette,
  Layout,
  Sliders,
  RotateCcw,
  Move,
  Eye,
  CheckSquare,
  Newspaper,
  KeyRound,
  ShieldAlert
} from 'lucide-react';
import {
  LayoutSettings,
  DigitalClockSettings,
  AnalogClockSettings,
  ElementKey,
  ElementThemeOverride
} from '../../types';
import { CLOCK_FONTS, GRADIENT_PRESETS } from '../../constants/fonts';

interface CustomizationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  layout: LayoutSettings;
  onUpdateLayout: (updater: (prev: LayoutSettings) => LayoutSettings) => void;
  digitalClock: DigitalClockSettings;
  onUpdateDigitalClock: (updater: (prev: DigitalClockSettings) => DigitalClockSettings) => void;
  analogClock: AnalogClockSettings;
  onUpdateAnalogClock: (updater: (prev: AnalogClockSettings) => AnalogClockSettings) => void;
  initialTab?: string;
  onResetDefaults: () => void;
}

export const CustomizationDrawer: React.FC<CustomizationDrawerProps> = ({
  isOpen,
  onClose,
  layout,
  onUpdateLayout,
  digitalClock,
  onUpdateDigitalClock,
  analogClock,
  onUpdateAnalogClock,
  initialTab = 'clock',
  onResetDefaults
}) => {
  const [activeTab, setActiveTab] = useState<'clock' | 'analog' | 'layout' | 'visibility' | 'theme'>(
    (initialTab as any) || 'clock'
  );

  const [fontSearch, setFontSearch] = useState('');

  useEffect(() => {
    if (isOpen && initialTab) {
      setActiveTab(initialTab as any);
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  const filteredFonts = CLOCK_FONTS.filter((f) =>
    f.name.toLowerCase().includes(fontSearch.toLowerCase()) ||
    f.category.toLowerCase().includes(fontSearch.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex justify-end pointer-events-none select-none">
      {/* Non-obscuring liquid glass drawer so user sees changes live on screen! */}
      <div className="pointer-events-auto w-[380px] max-w-full h-full bg-[#12141c]/90 text-white backdrop-blur-md border-l border-white/20 shadow-[-16px_0_50px_rgba(0,0,0,0.65)] flex flex-col animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-3.5 border-b border-white/10 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center shadow-md">
              <Sliders className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-white tracking-tight">Element Customizer Studio</h2>
              <p className="text-[9px] text-white/50">Live Liquid Glass Engine</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={onResetDefaults}
              className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[9px] font-bold text-rose-300 transition-colors flex items-center gap-1"
              title="Reset to defaults"
            >
              <RotateCcw className="w-2.5 h-2.5" />
              Reset
            </button>
            <button
              onClick={onClose}
              className="w-6 h-6 rounded-full flex items-center justify-center hover:bg-white/10 text-white/60 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 p-2 border-b border-white/10 overflow-x-auto scrollbar-none flex-shrink-0 text-[11px] font-semibold">
          <button
            onClick={() => setActiveTab('clock')}
            className={`px-2.5 py-1 rounded-lg transition-all whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'clock' ? 'bg-white/20 text-white shadow-sm font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            <Type className="w-3 h-3" />
            Clock & Fonts
          </button>
          <button
            onClick={() => setActiveTab('analog')}
            className={`px-2.5 py-1 rounded-lg transition-all whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'analog' ? 'bg-white/20 text-white shadow-sm font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            <ClockIcon className="w-3 h-3" />
            Analog Clock
          </button>
          <button
            onClick={() => setActiveTab('layout')}
            className={`px-2.5 py-1 rounded-lg transition-all whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'layout' ? 'bg-white/20 text-white shadow-sm font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            <Layout className="w-3 h-3" />
            Layout & Drag
          </button>
          <button
            onClick={() => setActiveTab('visibility')}
            className={`px-2.5 py-1 rounded-lg transition-all whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'visibility' ? 'bg-white/20 text-white shadow-sm font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            <Eye className="w-3 h-3" />
            Widgets
          </button>
          <button
            onClick={() => setActiveTab('theme')}
            className={`px-2.5 py-1 rounded-lg transition-all whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'theme' ? 'bg-white/20 text-white shadow-sm font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            <Palette className="w-3 h-3" />
            Themes
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-3.5 text-xs">
          {/* TAB 1: CLOCK & FONTS */}
          {activeTab === 'clock' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs">
                    Digital Clock Font ({CLOCK_FONTS.length} Fonts)
                  </span>
                  <span className="text-[9px] text-white/50">Applies to clock only</span>
                </div>
                <input
                  type="text"
                  value={fontSearch}
                  onChange={(e) => setFontSearch(e.target.value)}
                  placeholder="Filter 32 Google Fonts..."
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white/10 border border-white/15 text-xs text-white placeholder-white/40 outline-none focus:border-amber-400"
                />

                <div className="max-h-44 overflow-y-auto space-y-1 pr-1">
                  {filteredFonts.map((font) => {
                    const isSelected = digitalClock.font.includes(font.name);
                    return (
                      <button
                        key={font.name}
                        onClick={() =>
                          onUpdateDigitalClock((prev) => ({
                            ...prev,
                            font: font.family
                          }))
                        }
                        className={`w-full text-left px-2.5 py-1.5 rounded-xl border transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-500/40 text-amber-200 font-bold shadow-sm'
                            : 'bg-white/5 border-white/5 hover:bg-white/10 text-white/80'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-sm" style={{ fontFamily: font.family }}>
                            10:42
                          </span>
                          <span className="text-xs">{font.name}</span>
                        </div>
                        <span className="text-[8px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-white/10 text-white/60">
                          {font.category}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Color Mode */}
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs">Color & Style</span>
                  <div className="flex gap-1 p-0.5 rounded-lg bg-black/30">
                    <button
                      onClick={() =>
                        onUpdateDigitalClock((prev) => ({ ...prev, colorMode: 'solid' }))
                      }
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        digitalClock.colorMode === 'solid' ? 'bg-white text-black' : 'text-white/60'
                      }`}
                    >
                      Solid
                    </button>
                    <button
                      onClick={() =>
                        onUpdateDigitalClock((prev) => ({ ...prev, colorMode: 'gradient' }))
                      }
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        digitalClock.colorMode === 'gradient' ? 'bg-white text-black' : 'text-white/60'
                      }`}
                    >
                      Gradient
                    </button>
                  </div>
                </div>

                {digitalClock.colorMode === 'solid' ? (
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-white/70">Solid Clock Color</span>
                    <input
                      type="color"
                      value={digitalClock.solidColor}
                      onChange={(e) =>
                        onUpdateDigitalClock((prev) => ({ ...prev, solidColor: e.target.value }))
                      }
                      className="w-7 h-7 rounded-full border-none cursor-pointer bg-transparent"
                    />
                  </div>
                ) : (
                  <div className="space-y-2 pt-1">
                    <div className="grid grid-cols-2 gap-1.5">
                      {GRADIENT_PRESETS.map((gp, i) => (
                        <button
                          key={i}
                          onClick={() =>
                            onUpdateDigitalClock((prev) => ({
                              ...prev,
                              gradientFrom: gp.from,
                              gradientTo: gp.to,
                              gradientAngle: gp.angle
                            }))
                          }
                          className="p-1.5 rounded-xl border border-white/10 hover:border-white/30 text-left flex items-center gap-1.5 transition-all"
                        >
                          <span
                            className="w-3.5 h-3.5 rounded-full flex-shrink-0"
                            style={{
                              background: `linear-gradient(${gp.angle}deg, ${gp.from}, ${gp.to})`
                            }}
                          />
                          <span className="text-[10px] font-semibold text-white truncate">
                            {gp.name}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Size & Format */}
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-2.5">
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-white/80">Font Size: {digitalClock.fontSize}px</span>
                  </div>
                  <input
                    type="range"
                    min="36"
                    max="140"
                    step="2"
                    value={digitalClock.fontSize}
                    onChange={(e) =>
                      onUpdateDigitalClock((prev) => ({
                        ...prev,
                        fontSize: Number(e.target.value)
                      }))
                    }
                    className="w-full h-1.5 rounded-full bg-white/20 accent-amber-400 cursor-pointer"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-white/10">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={digitalClock.is12h}
                      onChange={(e) =>
                        onUpdateDigitalClock((prev) => ({ ...prev, is12h: e.target.checked }))
                      }
                      className="rounded accent-amber-400"
                    />
                    <span className="text-[11px] text-white/80">12h Format</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={digitalClock.showSeconds}
                      onChange={(e) =>
                        onUpdateDigitalClock((prev) => ({
                          ...prev,
                          showSeconds: e.target.checked
                        }))
                      }
                      className="rounded accent-amber-400"
                    />
                    <span className="text-[11px] text-white/80">Seconds</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ANALOG CLOCK */}
          {activeTab === 'analog' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <span className="font-bold text-white text-xs block">Themes</span>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'cream', name: 'Cream Minimalist' },
                    { id: 'dark', name: 'Dark OLED' },
                    { id: 'glass', name: 'Frosted Glass' },
                    { id: 'titanium', name: 'Silver Titanium' }
                  ].map((t) => (
                    <button
                      key={t.id}
                      onClick={() =>
                        onUpdateAnalogClock((prev) => ({ ...prev, theme: t.id as any }))
                      }
                      className={`p-2 rounded-xl border text-left text-xs font-bold transition-all ${
                        analogClock.theme === t.id
                          ? 'bg-amber-500/20 border-amber-500/40 text-amber-200'
                          : 'bg-white/5 border-white/5 text-white/70 hover:text-white'
                      }`}
                    >
                      {t.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span>Size: {analogClock.size}px</span>
                </div>
                <input
                  type="range"
                  min="130"
                  max="280"
                  step="5"
                  value={analogClock.size}
                  onChange={(e) =>
                    onUpdateAnalogClock((prev) => ({ ...prev, size: Number(e.target.value) }))
                  }
                  className="w-full h-1.5 rounded-full bg-white/20 accent-amber-400 cursor-pointer"
                />

                <div className="space-y-1.5 pt-2 border-t border-white/10">
                  <label className="flex items-center justify-between cursor-pointer">
                    <span className="text-[11px] text-white/80">Show Seconds Hand</span>
                    <input
                      type="checkbox"
                      checked={analogClock.showSeconds}
                      onChange={(e) =>
                        onUpdateAnalogClock((prev) => ({
                          ...prev,
                          showSeconds: e.target.checked
                        }))
                      }
                      className="rounded accent-amber-400"
                    />
                  </label>
                  <label className="flex items-center justify-between cursor-pointer">
                    <span className="text-[11px] text-white/80">Smooth Sweep Movement</span>
                    <input
                      type="checkbox"
                      checked={analogClock.smoothSweep}
                      onChange={(e) =>
                        onUpdateAnalogClock((prev) => ({
                          ...prev,
                          smoothSweep: e.target.checked
                        }))
                      }
                      className="rounded accent-amber-400"
                    />
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: LAYOUT & DRAG */}
          {activeTab === 'layout' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-500/20 via-teal-500/10 to-transparent border border-emerald-500/40">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <Move className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-xs font-bold text-white">Drag & Drop Mode</span>
                  </div>
                  <button
                    onClick={() =>
                      onUpdateLayout((prev) => ({
                        ...prev,
                        dragModeEnabled: !prev.dragModeEnabled
                      }))
                    }
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                      layout.dragModeEnabled
                        ? 'bg-emerald-400 text-black shadow-lg animate-pulse'
                        : 'bg-white/10 text-white/70 hover:bg-white/20'
                    }`}
                  >
                    {layout.dragModeEnabled ? 'ACTIVE' : 'Enable Drag'}
                  </button>
                </div>
                <p className="text-[10px] text-white/70 leading-relaxed">
                  When enabled, click & drag any widget (clocks, search bar, dock, tasks, news, password vault) across the screen! You can also toggle this via the <b>bottom-right Edit button</b>.
                </p>
              </div>

              {/* Search Bar width */}
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-white/80">Search Bar Width</span>
                  <span className="font-mono text-white/60">{layout.searchWidth}px</span>
                </div>
                <input
                  type="range"
                  min="340"
                  max="700"
                  step="10"
                  value={layout.searchWidth}
                  onChange={(e) =>
                    onUpdateLayout((prev) => ({ ...prev, searchWidth: Number(e.target.value) }))
                  }
                  className="w-full h-1.5 rounded-full bg-white/20 accent-emerald-400 cursor-pointer"
                />
              </div>

              {/* Island top offset */}
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-white/80">Dynamic Island Top Offset</span>
                  <span className="font-mono text-white/60">{layout.islandTop}px</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="60"
                  value={layout.islandTop}
                  onChange={(e) =>
                    onUpdateLayout((prev) => ({ ...prev, islandTop: Number(e.target.value) }))
                  }
                  className="w-full h-1.5 rounded-full bg-white/20 accent-emerald-400 cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* TAB 4: WIDGETS, SIZE & THEME STYLE */}
          {activeTab === 'visibility' && (
            <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-2 animate-in fade-in duration-150">
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-white text-xs">
                  Components: Visibility, Size & Theme
                </span>
              </div>
              <div className="space-y-2">
                {(
                  [
                    { showKey: 'showDynamicIsland', elemKey: 'island', label: 'Dynamic Island' },
                    { showKey: 'showCenterClock', elemKey: 'digitalClock', label: 'Digital Center Clock' },
                    { showKey: 'showSearchBar', elemKey: 'searchBar', label: 'Center Search Bar' },
                    { showKey: 'showAnalogClock', elemKey: 'analogClock', label: 'Analog Clock Widget' },
                    { showKey: 'showWeather', elemKey: 'weather', label: 'Weather Widget' },
                    { showKey: 'showCalendar', elemKey: 'calendar', label: 'Monthly Calendar' },
                    { showKey: 'showTodo', elemKey: 'todo', label: 'Focus To-Do Widget' },
                    { showKey: 'showNews', elemKey: 'news', label: 'Headlines News Widget' },
                    { showKey: 'showPasswordGen', elemKey: 'passwordGen', label: 'Password Generator' },
                    { showKey: 'showBottomDock', elemKey: 'dock', label: 'Bottom Dock Apps' }
                  ] as Array<{ showKey: keyof LayoutSettings; elemKey: ElementKey; label: string }>
                ).map((item) => {
                  const isVisible = Boolean(layout[item.showKey]);
                  const currentScale =
                    layout.elementScales?.[item.elemKey] ??
                    (item.elemKey === 'island'
                      ? layout.islandScale
                      : item.elemKey === 'dock'
                      ? layout.dockScale
                      : 1);
                  const currentTheme = layout.elementThemes?.[item.elemKey] ?? 'inherit';

                  return (
                    <div
                      key={item.elemKey}
                      className="p-2.5 rounded-xl bg-white/5 border border-white/10 space-y-2"
                    >
                      {/* Row 1: Visibility Toggle */}
                      <label className="flex items-center justify-between cursor-pointer">
                        <span className="text-[11px] font-bold text-white/95">{item.label}</span>
                        <input
                          type="checkbox"
                          checked={isVisible}
                          onChange={(e) =>
                            onUpdateLayout((prev) => ({
                              ...prev,
                              [item.showKey]: e.target.checked
                            }))
                          }
                          className="rounded accent-emerald-400 w-3.5 h-3.5"
                        />
                      </label>

                      {/* Row 2: Size Slider + Theme Style Selector */}
                      <div className="grid grid-cols-12 gap-2 items-center pt-1 border-t border-white/5">
                        <div className="col-span-7 space-y-0.5">
                          <div className="flex justify-between text-[9px] text-white/60 font-semibold">
                            <span>Size</span>
                            <span className="font-mono">{Math.round(currentScale * 100)}%</span>
                          </div>
                          <input
                            type="range"
                            min="0.65"
                            max="1.45"
                            step="0.05"
                            value={currentScale}
                            onChange={(e) => {
                              const nextScale = Number(e.target.value);
                              onUpdateLayout((prev) => ({
                                ...prev,
                                ...(item.elemKey === 'island' ? { islandScale: nextScale } : {}),
                                ...(item.elemKey === 'dock' ? { dockScale: nextScale } : {}),
                                elementScales: {
                                  ...(prev.elementScales || {}),
                                  [item.elemKey]: nextScale
                                } as any
                              }));
                            }}
                            className="w-full h-1 rounded-full bg-white/20 accent-emerald-400 cursor-pointer"
                          />
                        </div>

                        <div className="col-span-5">
                          <select
                            value={currentTheme}
                            onChange={(e) => {
                              const nextTheme = e.target.value as ElementThemeOverride;
                              onUpdateLayout((prev) => ({
                                ...prev,
                                elementThemes: {
                                  ...(prev.elementThemes || {}),
                                  [item.elemKey]: nextTheme
                                } as any
                              }));
                            }}
                            aria-label={`${item.label} Theme`}
                            className="w-full px-1.5 py-1 rounded-lg bg-[#181b26] border border-white/15 text-[10px] font-semibold text-white outline-none focus:border-purple-400 cursor-pointer"
                          >
                            <option value="inherit">Global</option>
                            <option value="oled">OLED</option>
                            <option value="glass">Glass</option>
                            <option value="aurora">Aurora</option>
                            <option value="titanium">Titanium</option>
                            <option value="gold">Gold</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 5: THEMES */}
          {activeTab === 'theme' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs block">Global Dashboard Style</span>
                  <button
                    onClick={() =>
                      onUpdateLayout((prev) => ({
                        ...prev,
                        elementThemes: {
                          island: 'inherit',
                          digitalClock: 'inherit',
                          analogClock: 'inherit',
                          searchBar: 'inherit',
                          weather: 'inherit',
                          calendar: 'inherit',
                          todo: 'inherit',
                          passwordGen: 'inherit',
                          news: 'inherit',
                          dock: 'inherit'
                        }
                      }))
                    }
                    className="text-[10px] font-semibold text-purple-300 hover:text-purple-200 underline"
                  >
                    Apply to All
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'oled', name: '🖤 OLED Black' },
                    { id: 'glass', name: '✨ Frosted Glass' },
                    { id: 'aurora', name: '🔮 Aurora Glow' },
                    { id: 'titanium', name: '⚪ Titanium' },
                    { id: 'gold', name: '👑 Cyber Gold' }
                  ].map((th) => (
                    <button
                      key={th.id}
                      onClick={() =>
                        onUpdateLayout((prev) => ({ ...prev, themeStyle: th.id as any }))
                      }
                      className={`p-2 rounded-xl border text-left text-xs font-bold transition-all ${
                        layout.themeStyle === th.id
                          ? 'bg-purple-500/20 border-purple-500/50 text-white'
                          : 'bg-white/5 border-white/5 text-white/70 hover:text-white'
                      }`}
                    >
                      {th.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Accent Color */}
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white text-xs block">Global Accent Color</span>
                </div>
                <input
                  type="color"
                  value={layout.accentColor}
                  onChange={(e) =>
                    onUpdateLayout((prev) => ({ ...prev, accentColor: e.target.value }))
                  }
                  className="w-7 h-7 rounded-full border-none cursor-pointer bg-transparent"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

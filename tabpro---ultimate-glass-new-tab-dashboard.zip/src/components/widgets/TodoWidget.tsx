import React, { useState } from 'react';
import { CheckSquare, Square, Plus, Trash2, CheckCircle2, ListTodo } from 'lucide-react';
import { TodoItem, ElementPosition, ElementThemeStyle } from '../../types';
import { useDraggable } from '../../hooks/useDraggable';
import { getThemeSurfaceClasses } from '../../utils/theme';

interface TodoWidgetProps {
  todos: TodoItem[];
  onAddTodo: (text: string) => void;
  onToggleTodo: (id: string) => void;
  onDeleteTodo: (id: string) => void;
  position: ElementPosition;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
  scale?: number;
  themeStyle?: ElementThemeStyle;
  accentColor?: string;
}

export const TodoWidget: React.FC<TodoWidgetProps> = ({
  todos,
  onAddTodo,
  onToggleTodo,
  onDeleteTodo,
  position,
  isDragMode = false,
  onPositionChange,
  scale = 1,
  themeStyle = 'oled',
  accentColor = '#ff453a'
}) => {
  const [inputText, setInputText] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'done'>('all');

  const { elementRef, isDragging, dragProps } = useDraggable({
    position,
    isDragMode,
    onPositionChange
  });

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onAddTodo(inputText.trim());
    setInputText('');
  };

  const completedCount = todos.filter((t) => t.completed).length;
  const totalCount = todos.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const filteredTodos = todos.filter((t) => {
    if (filter === 'active') return !t.completed;
    if (filter === 'done') return t.completed;
    return true;
  });

  return (
    <div
      ref={elementRef}
      {...dragProps}
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0) scale(${scale})`,
        transformOrigin: 'top left',
        cursor: isDragging ? 'grabbing' : isDragMode ? 'grab' : 'default',
        touchAction: isDragMode ? 'none' : 'auto'
      }}
      className={`fixed top-0 left-0 w-[290px] p-4 rounded-3xl backdrop-blur-2xl border select-none transition-shadow ${getThemeSurfaceClasses(themeStyle)} ${
        isDragging ? 'z-50' : 'z-30'
      } ${isDragMode ? 'ring-2 ring-emerald-400/80' : ''}`}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <ListTodo className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-bold text-white tracking-tight">Focus Tasks</span>
        </div>
        <span className="text-[10px] font-mono font-bold text-white/60">
          {completedCount}/{totalCount} ({progressPercent}%)
        </span>
      </div>

      {/* Progress Bar */}
      <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden mb-3">
        <div
          className="h-full rounded-full transition-all duration-300"
          style={{
            width: `${progressPercent}%`,
            backgroundColor: progressPercent === 100 ? '#10b981' : accentColor
          }}
        />
      </div>

      {/* Input */}
      <form onSubmit={handleFormSubmit} className="flex items-center gap-1.5 mb-2.5">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Add task & press enter..."
          className="flex-1 px-3 py-1.5 rounded-xl bg-white/10 border border-white/15 text-xs text-white placeholder-white/40 outline-none focus:border-emerald-400"
        />
        <button
          type="submit"
          className="w-7 h-7 rounded-xl bg-white/15 hover:bg-white/25 flex items-center justify-center text-white/80 hover:text-white transition-colors"
          title="Add task"
        >
          <Plus className="w-4 h-4" />
        </button>
      </form>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between text-[10px] font-semibold text-white/50 mb-2 px-1">
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`transition-colors ${filter === 'all' ? 'text-white font-bold underline' : 'hover:text-white'}`}
          >
            All ({totalCount})
          </button>
          <button
            onClick={() => setFilter('active')}
            className={`transition-colors ${filter === 'active' ? 'text-white font-bold underline' : 'hover:text-white'}`}
          >
            Active ({totalCount - completedCount})
          </button>
          <button
            onClick={() => setFilter('done')}
            className={`transition-colors ${filter === 'done' ? 'text-white font-bold underline' : 'hover:text-white'}`}
          >
            Done ({completedCount})
          </button>
        </div>
      </div>

      {/* List */}
      <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
        {filteredTodos.length === 0 ? (
          <div className="py-4 text-center text-[11px] text-white/40">
            {totalCount === 0 ? 'No tasks yet. Create one!' : 'No tasks in this view.'}
          </div>
        ) : (
          filteredTodos.map((todo) => (
            <div
              key={todo.id}
              className={`flex items-center justify-between p-2 rounded-xl border transition-all ${
                todo.completed
                  ? 'bg-black/20 border-white/5 opacity-60'
                  : 'bg-white/5 border-white/10 hover:bg-white/10'
              }`}
            >
              <button
                onClick={() => onToggleTodo(todo.id)}
                className="flex items-center gap-2 min-w-0 flex-1 text-left cursor-pointer"
              >
                {todo.completed ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                ) : (
                  <Square className="w-3.5 h-3.5 text-white/40 hover:text-white flex-shrink-0" />
                )}
                <span
                  className={`text-xs truncate text-white/90 ${
                    todo.completed ? 'line-through text-white/50' : ''
                  }`}
                >
                  {todo.text}
                </span>
              </button>

              <button
                onClick={() => onDeleteTodo(todo.id)}
                className="text-white/30 hover:text-red-400 p-0.5 transition-colors ml-1"
                title="Delete task"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

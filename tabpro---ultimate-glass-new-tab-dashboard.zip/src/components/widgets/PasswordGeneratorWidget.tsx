import React, { useState, useEffect } from 'react';
import { KeyRound, Copy, Check, RefreshCw, ShieldCheck } from 'lucide-react';
import { ElementPosition, PasswordSettings, ElementThemeStyle } from '../../types';
import { useDraggable } from '../../hooks/useDraggable';
import { getThemeSurfaceClasses } from '../../utils/theme';

interface PasswordGeneratorWidgetProps {
  position: ElementPosition;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
  scale?: number;
  themeStyle?: ElementThemeStyle;
  accentColor?: string;
}

export const PasswordGeneratorWidget: React.FC<PasswordGeneratorWidgetProps> = ({
  position,
  isDragMode = false,
  onPositionChange,
  scale = 1,
  themeStyle = 'oled',
  accentColor = '#ff453a'
}) => {
  const [settings, setSettings] = useState<PasswordSettings>(() => {
    try {
      const saved = localStorage.getItem('tabpro_pwd_settings');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      length: 16,
      useUpper: true,
      useLower: true,
      useNumbers: true,
      useSymbols: true
    };
  });

  const [password, setPassword] = useState('');
  const [copied, setCopied] = useState(false);

  const generatePassword = () => {
    const uppers = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const lowers = 'abcdefghijkmnopqrstuvwxyz';
    const numbers = '23456789';
    const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';

    let pool = '';
    let guaranteed = '';

    if (settings.useUpper) {
      pool += uppers;
      guaranteed += uppers[Math.floor(Math.random() * uppers.length)];
    }
    if (settings.useLower) {
      pool += lowers;
      guaranteed += lowers[Math.floor(Math.random() * lowers.length)];
    }
    if (settings.useNumbers) {
      pool += numbers;
      guaranteed += numbers[Math.floor(Math.random() * numbers.length)];
    }
    if (settings.useSymbols) {
      pool += symbols;
      guaranteed += symbols[Math.floor(Math.random() * symbols.length)];
    }

    if (!pool) pool = lowers + numbers;

    let res = guaranteed;
    const remaining = settings.length - guaranteed.length;
    for (let i = 0; i < remaining; i++) {
      res += pool[Math.floor(Math.random() * pool.length)];
    }

    // Shuffle characters
    const shuffled = res.split('').sort(() => 0.5 - Math.random()).join('');
    setPassword(shuffled);
  };

  useEffect(() => {
    generatePassword();
    localStorage.setItem('tabpro_pwd_settings', JSON.stringify(settings));
  }, [settings]);

  const handleCopy = () => {
    if (!password) return;
    navigator.clipboard.writeText(password);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const calculateStrength = () => {
    let score = 0;
    if (settings.length >= 12) score++;
    if (settings.length >= 16) score++;
    if (settings.useUpper) score++;
    if (settings.useLower) score++;
    if (settings.useNumbers) score++;
    if (settings.useSymbols) score++;

    if (score <= 2) return { label: 'Weak', color: 'bg-rose-500', width: '25%' };
    if (score <= 4) return { label: 'Good', color: 'bg-amber-400', width: '50%' };
    if (score <= 5) return { label: 'Strong', color: 'bg-emerald-400', width: '75%' };
    return { label: 'Very Strong', color: 'bg-cyan-400', width: '100%' };
  };

  const strength = calculateStrength();

  const { elementRef, isDragging, dragProps } = useDraggable({
    position,
    isDragMode,
    onPositionChange
  });

  return (
    <div
      ref={elementRef}
      {...dragProps}
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0) scale(${scale})`,
        transformOrigin: 'top left',
        cursor: isDragging ? 'grabbing' : isDragMode ? 'grab' : 'default',
        touchAction: isDragMode ? 'none' : 'auto'
      }}
      className={`fixed top-0 left-0 w-[290px] p-4 rounded-3xl backdrop-blur-2xl border select-none transition-shadow ${getThemeSurfaceClasses(themeStyle)} ${
        isDragging ? 'z-50' : 'z-30'
      } ${isDragMode ? 'ring-2 ring-emerald-400/80' : ''}`}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
            <KeyRound className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-bold text-white tracking-tight">Key Vault Gen</span>
        </div>
        <span className="text-[10px] font-bold text-white/50">{strength.label}</span>
      </div>

      {/* Generated Password Pill with Copy button */}
      <div className="relative flex items-center justify-between p-2 rounded-2xl bg-black/30 border border-white/10 mb-2">
        <span className="font-mono text-xs text-cyan-200 tracking-wider truncate pr-2 select-all">
          {password}
        </span>
        <div className="flex items-center gap-1">
          <button
            onClick={generatePassword}
            className="w-6 h-6 rounded-lg flex items-center justify-center hover:bg-white/10 text-white/70 hover:text-white transition-colors"
            title="Generate new password"
          >
            <RefreshCw className="w-3 h-3" />
          </button>
          <button
            onClick={handleCopy}
            className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all ${
              copied ? 'bg-emerald-500 text-black' : 'bg-white/15 hover:bg-white/25 text-white'
            }`}
            title="Copy password"
          >
            {copied ? <Check className="w-3 h-3 stroke-[3]" /> : <Copy className="w-3 h-3" />}
          </button>
        </div>
      </div>

      {/* Strength indicator */}
      <div className="w-full h-1 rounded-full bg-white/10 overflow-hidden mb-3">
        <div
          className={`h-full rounded-full transition-all duration-300 ${strength.color}`}
          style={{ width: strength.width }}
        />
      </div>

      {/* Length Slider */}
      <div className="mb-2.5">
        <div className="flex justify-between text-[10px] font-semibold text-white/70 mb-1">
          <span>Length: {settings.length} characters</span>
        </div>
        <input
          type="range"
          min="8"
          max="32"
          value={settings.length}
          onChange={(e) => setSettings({ ...settings, length: Number(e.target.value) })}
          className="w-full h-1.5 rounded-full bg-white/20 accent-cyan-400 cursor-pointer"
        />
      </div>

      {/* Character Toggles */}
      <div className="grid grid-cols-2 gap-1.5 text-[10px] text-white/80">
        <label className="flex items-center gap-1.5 cursor-pointer">
          <input
            type="checkbox"
            checked={settings.useUpper}
            onChange={(e) => setSettings({ ...settings, useUpper: e.target.checked })}
            className="rounded accent-cyan-400"
          />
          <span>A-Z (Upper)</span>
        </label>
        <label className="flex items-center gap-1.5 cursor-pointer">
          <input
            type="checkbox"
            checked={settings.useLower}
            onChange={(e) => setSettings({ ...settings, useLower: e.target.checked })}
            className="rounded accent-cyan-400"
          />
          <span>a-z (Lower)</span>
        </label>
        <label className="flex items-center gap-1.5 cursor-pointer">
          <input
            type="checkbox"
            checked={settings.useNumbers}
            onChange={(e) => setSettings({ ...settings, useNumbers: e.target.checked })}
            className="rounded accent-cyan-400"
          />
          <span>0-9 (Numbers)</span>
        </label>
        <label className="flex items-center gap-1.5 cursor-pointer">
          <input
            type="checkbox"
            checked={settings.useSymbols}
            onChange={(e) => setSettings({ ...settings, useSymbols: e.target.checked })}
            className="rounded accent-cyan-400"
          />
          <span>!@#$ (Symbols)</span>
        </label>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { Newspaper, RefreshCw, ExternalLink } from 'lucide-react';
import { NewsArticle, ElementPosition, ElementThemeStyle } from '../../types';
import { fetchTopHeadlines } from '../../services/newsService';
import { useDraggable } from '../../hooks/useDraggable';
import { getThemeSurfaceClasses } from '../../utils/theme';

interface NewsWidgetProps {
  position: ElementPosition;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
  scale?: number;
  themeStyle?: ElementThemeStyle;
  onLaunchApp?: (title: string, url: string) => void;
  accentColor?: string;
}

export const NewsWidget: React.FC<NewsWidgetProps> = ({
  position,
  isDragMode = false,
  onPositionChange,
  scale = 1,
  themeStyle = 'oled',
  onLaunchApp,
  accentColor = '#ff453a'
}) => {
  const [category, setCategory] = useState<string>('technology');
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const loadNews = async () => {
    setLoading(true);
    try {
      const data = await fetchTopHeadlines(category);
      setArticles(data);
    } catch {
      // handled inside service
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadNews();
  }, [category]);

  const { elementRef, isDragging, dragProps } = useDraggable({
    position,
    isDragMode,
    onPositionChange
  });

  return (
    <div
      ref={elementRef}
      {...dragProps}
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0) scale(${scale})`,
        transformOrigin: 'top left',
        cursor: isDragging ? 'grabbing' : isDragMode ? 'grab' : 'default',
        touchAction: isDragMode ? 'none' : 'auto'
      }}
      className={`fixed top-0 left-0 w-[300px] p-4 rounded-3xl backdrop-blur-2xl border select-none transition-shadow ${getThemeSurfaceClasses(themeStyle)} ${
        isDragging ? 'z-50' : 'z-30'
      } ${isDragMode ? 'ring-2 ring-emerald-400/80' : ''}`}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
            <Newspaper className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-bold text-white tracking-tight">Top Headlines</span>
        </div>
        <button
          onClick={loadNews}
          disabled={loading}
          className={`w-6 h-6 rounded-full flex items-center justify-center hover:bg-white/10 text-white/60 hover:text-white transition-colors ${
            loading ? 'animate-spin' : ''
          }`}
          title="Refresh news"
        >
          <RefreshCw className="w-3 h-3" />
        </button>
      </div>

      {/* Category Pills */}
      <div className="flex gap-1.5 mb-2.5 overflow-x-auto scrollbar-none pb-0.5 text-[10px] font-semibold">
        {[
          { id: 'technology', label: 'Tech' },
          { id: 'general', label: 'World' },
          { id: 'business', label: 'Finance' },
          { id: 'science', label: 'Science' }
        ].map((c) => (
          <button
            key={c.id}
            onClick={() => setCategory(c.id)}
            className={`px-2 py-0.5 rounded-lg transition-all ${
              category === c.id
                ? 'bg-purple-500/30 text-purple-200 border border-purple-500/40 font-bold'
                : 'bg-white/5 text-white/60 hover:text-white'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {/* Article List */}
      <div className="space-y-2 max-h-[200px] overflow-y-auto pr-1">
        {loading ? (
          <div className="py-6 text-center text-[11px] text-white/50 animate-pulse">
            Fetching latest headlines...
          </div>
        ) : (
          articles.map((item) => (
            <a
              key={item.id}
              href={item.url}
              target="_blank"
              rel="noreferrer"
              onClick={() => onLaunchApp?.(item.source || 'News Article', item.url)}
              className="block p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/20 transition-all group"
            >
              <div className="text-[11px] font-bold text-white/90 line-clamp-2 leading-snug group-hover:text-purple-300 transition-colors">
                {item.title}
              </div>
              <div className="flex items-center justify-between text-[9px] text-white/50 mt-1">
                <span>{item.source}</span>
                <span className="flex items-center gap-0.5">
                  {item.publishedAt}
                  <ExternalLink className="w-2.5 h-2.5 opacity-60" />
                </span>
              </div>
            </a>
          ))
        )}
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { RefreshCw, MapPin, Search, Wind, Droplets, X } from 'lucide-react';
import { WeatherData, ElementPosition, ElementThemeStyle } from '../../types';
import { fetchWeather, searchLocations, mapWeatherCode } from '../../services/weatherService';
import { useDraggable } from '../../hooks/useDraggable';
import { getThemeSurfaceClasses } from '../../utils/theme';

interface WeatherWidgetProps {
  position: ElementPosition;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
  scale?: number;
  themeStyle?: ElementThemeStyle;
  accentColor?: string;
}

interface SavedLocation {
  city: string;
  region: string;
  lat: number;
  lon: number;
}

export const WeatherWidget: React.FC<WeatherWidgetProps> = ({
  position,
  isDragMode = false,
  onPositionChange,
  scale = 1,
  themeStyle = 'oled'
}) => {
  const { elementRef, isDragging, dragProps } = useDraggable({
    position,
    isDragMode,
    onPositionChange
  });
  const [selectedLocation, setSelectedLocation] = useState<SavedLocation | null>(() => {
    try {
      const saved = localStorage.getItem('tabpro_weather_location');
      if (saved) return JSON.parse(saved);
    } catch {}
    return null;
  });

  const [isCelsius, setIsCelsius] = useState<boolean>(() => {
    return localStorage.getItem('tabpro_weather_unit') !== 'F';
  });

  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [showLocationModal, setShowLocationModal] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [searchResults, setSearchResults] = useState<
    Array<{ name: string; admin1?: string; country: string; lat: number; lon: number }>
  >([]);
  const [isSearching, setIsSearching] = useState<boolean>(false);

  const loadWeatherData = async (loc: SavedLocation | null = selectedLocation) => {
    if (!loc) {
      setWeather(null);
      setLoading(false);
      setError(null);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const data = await fetchWeather(loc.lat, loc.lon, loc.city, loc.region, isCelsius);
      setWeather(data);
    } catch (err: any) {
      console.error('Weather load error:', err);
      setError('Unable to load weather data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedLocation) {
      localStorage.setItem('tabpro_weather_location', JSON.stringify(selectedLocation));
      loadWeatherData(selectedLocation);
    } else {
      localStorage.removeItem('tabpro_weather_location');
      setWeather(null);
      setLoading(false);
    }
  }, [selectedLocation, isCelsius]);

  const handleUnitToggle = () => {
    const next = !isCelsius;
    setIsCelsius(next);
    localStorage.setItem('tabpro_weather_unit', next ? 'C' : 'F');
  };

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.trim().length < 2) {
      setSearchResults([]);
      return;
    }
    setIsSearching(true);
    try {
      const results = await searchLocations(query);
      setSearchResults(results);
    } catch {
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleClearLocation = () => {
    setSelectedLocation(null);
    setWeather(null);
    setError(null);
  };

  return (
    <div
      ref={elementRef}
      {...dragProps}
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0) scale(${scale})`,
        transformOrigin: 'top left',
        cursor: isDragging ? 'grabbing' : isDragMode ? 'grab' : 'default',
        touchAction: isDragMode ? 'none' : 'auto'
      }}
      className={`fixed top-0 left-0 w-[280px] p-4 rounded-3xl backdrop-blur-2xl border select-none ${getThemeSurfaceClasses(themeStyle)} ${
        isDragging ? 'z-50 transition-shadow' : 'z-30 transition-shadow'
      } ${isDragMode ? 'ring-2 ring-emerald-400/80' : ''}`}
    >
      {/* Top Header Row */}
      <div className="flex items-center justify-between gap-1 mb-2">
        <button
          onClick={() => setShowLocationModal(true)}
          className="flex items-center gap-1.5 min-w-0 group text-left cursor-pointer hover:opacity-90 transition-opacity"
          title="Search Locations"
        >
          <MapPin className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
          <div className="truncate">
            <span className="text-xs font-bold text-white tracking-tight block truncate group-hover:underline">
              {selectedLocation ? selectedLocation.city : 'Search Locations'}
            </span>
            {selectedLocation && (
              <span className="text-[10px] text-white/60 block truncate -mt-0.5">
                {selectedLocation.region}
              </span>
            )}
          </div>
        </button>

        {selectedLocation && (
          <div className="flex items-center gap-1 flex-shrink-0">
            <button
              onClick={handleUnitToggle}
              className="px-1.5 py-0.5 rounded-lg bg-white/10 hover:bg-white/20 text-[10px] font-bold text-white/80 transition-colors"
              title="Toggle °C / °F"
            >
              °{isCelsius ? 'C' : 'F'}
            </button>
            <button
              onClick={() => loadWeatherData()}
              disabled={loading}
              className={`w-6 h-6 rounded-full flex items-center justify-center hover:bg-white/15 text-white/70 hover:text-white transition-colors ${
                loading ? 'animate-spin' : ''
              }`}
              title="Refresh weather"
            >
              <RefreshCw className="w-3 h-3" />
            </button>
            <button
              onClick={handleClearLocation}
              className="w-6 h-6 rounded-full flex items-center justify-center hover:bg-white/15 text-white/50 hover:text-white transition-colors"
              title="Clear location"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>

      {/* Empty State when no default location */}
      {!selectedLocation ? (
        <div className="py-2.5 text-center space-y-2">
          <p className="text-[11px] text-white/55">No location selected</p>
          <button
            onClick={() => setShowLocationModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 hover:bg-white/25 border border-white/20 text-[11px] font-semibold text-white transition-all active:scale-95"
          >
            <Search className="w-3 h-3" />
            <span>Search City</span>
          </button>
        </div>
      ) : error ? (
        <div className="py-4 text-center text-xs text-rose-300">
          <p>{error}</p>
          <button
            onClick={() => loadWeatherData()}
            className="mt-2 px-3 py-1 text-[11px] rounded-xl bg-white/15 hover:bg-white/25"
          >
            Retry
          </button>
        </div>
      ) : weather ? (
        <>
          <div className="flex items-center justify-between my-2">
            <div>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-extralight tracking-tight font-mono text-white leading-none">
                  {weather.temp}°
                </span>
                <span className="text-xs font-semibold text-white/60">
                  {isCelsius ? 'C' : 'F'}
                </span>
              </div>
              <div className="text-xs font-medium text-white/90 mt-1 flex items-center gap-1.5">
                <span>{weather.condition}</span>
              </div>
              <div className="text-[10px] text-white/50 mt-0.5">
                Feels like {weather.feelsLike}° · H: {weather.high}° L: {weather.low}°
              </div>
            </div>

            <div className="text-4xl select-none filter drop-shadow-md">
              {mapWeatherCode(weather.weatherCode).icon}
            </div>
          </div>

          {/* Quick Metrics (Humidity, Wind) */}
          <div className="grid grid-cols-2 gap-2 py-1.5 px-2 my-2 rounded-xl bg-black/20 text-[10px] text-white/70">
            <div className="flex items-center gap-1.5">
              <Droplets className="w-3 h-3 text-cyan-300" />
              <span>Humidity: {weather.humidity}%</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Wind className="w-3 h-3 text-teal-300" />
              <span>Wind: {weather.windSpeed} km/h</span>
            </div>
          </div>

          {/* Hourly Forecast: Next 6 Hours */}
          <div className="pt-2 border-t border-white/10">
            <div className="text-[9px] font-bold text-white/50 uppercase tracking-wider mb-1.5">
              Next 6 Hours
            </div>
            <div className="flex justify-between items-center text-center">
              {weather.hourly.map((item, idx) => (
                <div key={idx} className="flex flex-col items-center">
                  <span className="text-[10px] font-medium text-white/60 mb-0.5">
                    {item.timeStr}
                  </span>
                  <span className="text-sm my-0.5">
                    {mapWeatherCode(item.weatherCode).icon}
                  </span>
                  <span className="text-xs font-bold text-white/90">
                    {item.temp}°
                  </span>
                  {item.rainProb > 0 && (
                    <span className="text-[8px] font-semibold text-cyan-300">
                      {item.rainProb}%
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </>
      ) : (
        <div className="py-8 text-center text-xs text-white/50 animate-pulse">
          Fetching weather data...
        </div>
      )}

      {/* Very Small Clean "Search Locations" Modal */}
      {showLocationModal && (
        <div
          onClick={() => setShowLocationModal(false)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/30"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-[230px] max-w-[88vw] p-2.5 rounded-2xl bg-[#141620]/95 backdrop-blur-2xl border border-white/20 shadow-2xl flex flex-col animate-in fade-in zoom-in-95 duration-150"
          >
            <div className="flex items-center justify-between pb-1.5 mb-2 border-b border-white/10">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3 h-3 text-amber-400" />
                <h3 className="text-[11px] font-bold text-white">Search Locations</h3>
              </div>
              <button
                onClick={() => setShowLocationModal(false)}
                className="w-5 h-5 rounded-full flex items-center justify-center hover:bg-white/10 text-white/60 hover:text-white"
              >
                <X className="w-3 h-3" />
              </button>
            </div>

            <div className="relative mb-1.5">
              <Search className="w-3 h-3 absolute left-2.5 top-1/2 -translate-y-1/2 text-white/40" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                placeholder="Search city..."
                autoFocus
                className="w-full pl-7 pr-2 py-1 rounded-xl bg-white/10 border border-white/15 text-[11px] text-white placeholder-white/40 outline-none focus:border-amber-400"
              />
            </div>

            {searchQuery.trim().length >= 2 ? (
              <div className="max-h-36 overflow-y-auto space-y-1">
                {isSearching ? (
                  <div className="text-[10px] text-white/50 py-1.5 text-center">Searching...</div>
                ) : searchResults.length > 0 ? (
                  searchResults.map((res, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        setSelectedLocation({
                          city: res.name,
                          region: `${res.admin1 ? res.admin1 + ', ' : ''}${res.country}`,
                          lat: res.lat,
                          lon: res.lon
                        });
                        setShowLocationModal(false);
                        setSearchQuery('');
                        setSearchResults([]);
                      }}
                      className="w-full text-left px-2 py-1 rounded-xl bg-white/5 hover:bg-white/15 border border-white/5 flex items-center justify-between transition-colors"
                    >
                      <div className="min-w-0 pr-2">
                        <span className="text-[11px] font-bold text-white block truncate">
                          {res.name}
                        </span>
                        <span className="text-[9px] text-white/60 block truncate">
                          {res.admin1 ? `${res.admin1}, ` : ''}
                          {res.country}
                        </span>
                      </div>
                      <span className="text-[9px] font-bold text-amber-400 flex-shrink-0">
                        Select
                      </span>
                    </button>
                  ))
                ) : (
                  <div className="text-[10px] text-white/50 py-1.5 text-center">No results found.</div>
                )}
              </div>
            ) : (
              <div className="py-1.5 text-center text-[10px] text-white/45">
                Type 2+ letters to search.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

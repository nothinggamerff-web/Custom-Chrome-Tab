import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Trash2, Calendar as CalIcon, X } from 'lucide-react';
import { CalendarEvent, ElementPosition, ElementThemeStyle } from '../../types';
import { useDraggable } from '../../hooks/useDraggable';
import { getThemeSurfaceClasses } from '../../utils/theme';

interface MonthlyCalendarWidgetProps {
  events: CalendarEvent[];
  onAddEvent: (event: Omit<CalendarEvent, 'id'>) => void;
  onDeleteEvent: (id: string) => void;
  position: ElementPosition;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
  scale?: number;
  accentColor?: string;
  themeStyle?: ElementThemeStyle;
}

export const MonthlyCalendarWidget: React.FC<MonthlyCalendarWidgetProps> = ({
  events,
  onAddEvent,
  onDeleteEvent,
  position,
  isDragMode = false,
  onPositionChange,
  scale = 1,
  accentColor = '#ff453a',
  themeStyle = 'oled'
}) => {
  const { elementRef, isDragging, dragProps } = useDraggable({
    position,
    isDragMode,
    onPositionChange
  });
  const [currentDate, setCurrentDate] = useState(() => new Date());
  const [selectedDate, setSelectedDate] = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  });
  const [showEventModal, setShowEventModal] = useState(false);
  const [newEventTitle, setNewEventTitle] = useState('');
  const [newEventTime, setNewEventTime] = useState('10:00');

  const today = new Date();
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  // Days in month calculation (handles leap years automatically)
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayWeekday = new Date(year, month, 1).getDay(); // 0 is Sunday

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const monthName = currentDate.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });

  // Filter events for selected date
  const selectedDateEvents = events.filter((e) => e.date === selectedDate);

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventTitle.trim()) return;
    onAddEvent({
      title: newEventTitle.trim(),
      date: selectedDate,
      time: newEventTime,
      color: accentColor
    });
    setNewEventTitle('');
    setShowEventModal(false);
  };

  const isSelectedDateToday = selectedDate === todayStr;

  return (
    <div
      ref={elementRef}
      {...dragProps}
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0) scale(${scale})`,
        transformOrigin: 'top left',
        cursor: isDragging ? 'grabbing' : isDragMode ? 'grab' : 'default',
        touchAction: isDragMode ? 'none' : 'auto'
      }}
      className={`fixed top-0 left-0 w-[280px] p-4 rounded-3xl backdrop-blur-2xl border select-none ${getThemeSurfaceClasses(themeStyle)} ${
        isDragging ? 'z-50 transition-shadow' : 'z-30 transition-shadow'
      } ${isDragMode ? 'ring-2 ring-emerald-400/80' : ''}`}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-1.5">
          <CalIcon className="w-4 h-4 text-white/70" />
          <span className="text-xs font-bold tracking-tight text-white/90">{monthName}</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={prevMonth}
            className="w-6 h-6 rounded-full flex items-center justify-center hover:bg-white/15 text-white/70 hover:text-white transition-colors"
            title="Previous Month"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={nextMonth}
            className="w-6 h-6 rounded-full flex items-center justify-center hover:bg-white/15 text-white/70 hover:text-white transition-colors"
            title="Next Month"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Weekday Labels */}
      <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-bold text-white/50 mb-1">
        <span>S</span>
        <span>M</span>
        <span>T</span>
        <span>W</span>
        <span>T</span>
        <span>F</span>
        <span>S</span>
      </div>

      {/* Date Grid */}
      <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-medium">
        {/* Leading empty cells */}
        {Array.from({ length: firstDayWeekday }).map((_, i) => (
          <div key={`empty-${i}`} className="h-7" />
        ))}

        {/* Days of current month */}
        {Array.from({ length: daysInMonth }).map((_, i) => {
          const dayNum = i + 1;
          const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
          const isToday = dateStr === todayStr;
          const isSelected = dateStr === selectedDate;
          const hasEvents = events.some((e) => e.date === dateStr);

          return (
            <button
              key={dateStr}
              onClick={() => setSelectedDate(dateStr)}
              className={`relative h-7 w-7 mx-auto rounded-full flex items-center justify-center text-xs transition-transform active:scale-90 ${
                isToday
                  ? 'text-white font-extrabold shadow-md'
                  : isSelected
                  ? 'bg-white/30 text-white font-bold ring-1 ring-white/60'
                  : 'hover:bg-white/10 text-white/80'
              }`}
              style={isToday ? { backgroundColor: accentColor } : undefined}
            >
              <span>{dayNum}</span>

              {/* Event indicator dot */}
              {hasEvents && !isToday && (
                <span
                  className="absolute bottom-0.5 w-1 h-1 rounded-full"
                  style={{ backgroundColor: accentColor }}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Selected Date Summary & Events Strip */}
      <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between text-xs">
        <div className="min-w-0 flex-1 pr-2">
          <div className="text-[10px] font-semibold text-white/60 uppercase tracking-wider">
            {isSelectedDateToday ? 'Today’s Events' : `${selectedDate}`}
          </div>
          <div className="text-xs font-bold truncate text-white/90">
            {selectedDateEvents.length === 0
              ? 'No events scheduled'
              : `${selectedDateEvents.length} event${selectedDateEvents.length > 1 ? 's' : ''}`}
          </div>
        </div>
        <button
          onClick={() => setShowEventModal(true)}
          className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-white/15 hover:bg-white/25 text-white font-semibold text-[11px] transition-all"
        >
          <Plus className="w-3 h-3" />
          <span>Add</span>
        </button>
      </div>

      {/* Events List for selected date */}
      {selectedDateEvents.length > 0 && (
        <div className="mt-2 space-y-1.5 max-h-24 overflow-y-auto pr-1">
          {selectedDateEvents.map((evt) => (
            <div
              key={evt.id}
              className="flex items-center justify-between px-2 py-1 rounded-xl bg-black/20 border border-white/5 text-[11px]"
            >
              <div className="flex items-center gap-2 min-w-0">
                <span
                  className="w-1.5 h-3 rounded-full flex-shrink-0"
                  style={{ backgroundColor: evt.color || accentColor }}
                />
                <span className="truncate font-medium text-white/90">{evt.title}</span>
                {evt.time && <span className="text-[10px] text-white/50">{evt.time}</span>}
              </div>
              <button
                onClick={() => onDeleteEvent(evt.id)}
                className="text-white/40 hover:text-red-400 p-0.5 transition-colors ml-1"
                title="Delete event"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Add Event Modal */}
      {showEventModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
          <div className="w-full max-w-xs p-4 rounded-2xl bg-[#14161f] border border-white/20 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-white/10">
              <span className="text-xs font-bold text-white">Add Event on {selectedDate}</span>
              <button
                onClick={() => setShowEventModal(false)}
                className="text-white/50 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleCreateEvent} className="space-y-3">
              <div>
                <label className="block text-[10px] font-medium text-white/60 mb-1">
                  Event Title
                </label>
                <input
                  type="text"
                  value={newEventTitle}
                  onChange={(e) => setNewEventTitle(e.target.value)}
                  placeholder="Meeting, Birthday, Task..."
                  required
                  autoFocus
                  className="w-full px-3 py-1.5 rounded-xl bg-white/10 border border-white/15 text-xs text-white placeholder-white/40 outline-none focus:border-emerald-400"
                />
              </div>
              <div>
                <label className="block text-[10px] font-medium text-white/60 mb-1">
                  Time (Optional)
                </label>
                <input
                  type="time"
                  value={newEventTime}
                  onChange={(e) => setNewEventTime(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-xl bg-white/10 border border-white/15 text-xs text-white outline-none focus:border-emerald-400"
                />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowEventModal(false)}
                  className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow-lg"
                  style={{ backgroundColor: accentColor }}
                >
                  Save Event
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { useClock } from '../../hooks/useClock';
import { useDraggable } from '../../hooks/useDraggable';
import { AnalogClockSettings, ElementPosition, ElementThemeStyle } from '../../types';

interface AnalogClockWidgetProps {
  settings: AnalogClockSettings;
  position: ElementPosition;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
  scale?: number;
  themeStyle?: ElementThemeStyle;
  accentColor?: string;
}

export const AnalogClockWidget: React.FC<AnalogClockWidgetProps> = ({
  settings,
  position,
  isDragMode = false,
  onPositionChange,
  scale = 1,
  themeStyle,
  accentColor = '#ff453a'
}) => {
  const clock = useClock(settings.smoothSweep);
  const { elementRef, isDragging, dragProps } = useDraggable({
    position,
    isDragMode,
    onPositionChange
  });

  const currentSecondAngle = settings.smoothSweep ? clock.secondAngleSmooth : clock.secondAngleStep;

  // Theme styling for the circular clock face
  const getThemeStyles = () => {
    const activeTheme = themeStyle || settings.theme;
    switch (activeTheme) {
      case 'cream':
        return {
          faceBg: 'bg-[#f4efe6]/95 backdrop-blur-2xl text-[#18181b]',
          border: 'border-white/80 shadow-[0_20px_50px_rgba(0,0,0,0.45),inset_0_2px_4px_rgba(255,255,255,0.9),inset_0_-2px_6px_rgba(0,0,0,0.06)]',
          markerColor: '#27272a',
          handColor: '#18181b',
          subtext: 'text-[#71717a]'
        };
      case 'oled':
      case 'dark':
        return {
          faceBg: 'bg-[#090b10]/92 backdrop-blur-2xl text-white',
          border: 'border-white/15 shadow-[0_20px_60px_rgba(0,0,0,0.85),inset_0_1px_2px_rgba(255,255,255,0.2)]',
          markerColor: '#e4e4e7',
          handColor: '#ffffff',
          subtext: 'text-zinc-400'
        };
      case 'aurora':
        return {
          faceBg: 'bg-gradient-to-br from-indigo-950/85 via-purple-950/80 to-cyan-950/85 backdrop-blur-2xl text-white',
          border: 'border-cyan-300/35 shadow-[0_20px_55px_rgba(56,189,248,0.28),inset_0_1px_2px_rgba(165,243,252,0.4)]',
          markerColor: '#a5f3fc',
          handColor: '#ffffff',
          subtext: 'text-cyan-200/80'
        };
      case 'gold':
        return {
          faceBg: 'bg-gradient-to-br from-[#231b0a]/90 via-[#382a0e]/85 to-[#1a1408]/95 backdrop-blur-2xl text-amber-50',
          border: 'border-amber-400/45 shadow-[0_20px_55px_rgba(245,158,11,0.28),inset_0_1px_2px_rgba(251,191,36,0.45)]',
          markerColor: '#fcd34d',
          handColor: '#fef3c7',
          subtext: 'text-amber-300/80'
        };
      case 'titanium':
        return {
          faceBg: 'bg-zinc-100/90 backdrop-blur-2xl text-zinc-900',
          border: 'border-white/90 shadow-[0_20px_50px_rgba(0,0,0,0.35),inset_0_2px_4px_rgba(255,255,255,1)]',
          markerColor: '#18181b',
          handColor: '#09090b',
          subtext: 'text-zinc-500'
        };
      case 'glass':
      default:
        return {
          faceBg: 'bg-white/15 backdrop-blur-2xl text-white',
          border: 'border-white/30 shadow-[0_20px_60px_rgba(0,0,0,0.5),inset_0_1px_2px_rgba(255,255,255,0.4)]',
          markerColor: '#ffffff',
          handColor: '#ffffff',
          subtext: 'text-white/70'
        };
    }
  };

  const theme = getThemeStyles();
  const radius = settings.size / 2;

  // 12 hour markers
  const markers = Array.from({ length: 12 }, (_, i) => {
    const angle = i * 30;
    const isCardinal = i % 3 === 0;
    return {
      index: i,
      angle,
      isCardinal,
      label: i === 0 ? '12' : i === 3 ? '3' : i === 6 ? '6' : i === 9 ? '9' : null
    };
  });

  return (
    <div
      ref={elementRef}
      {...dragProps}
      style={{
        width: `${settings.size}px`,
        height: `${settings.size}px`,
        transform: `translate3d(${position.x}px, ${position.y}px, 0) scale(${scale})`,
        transformOrigin: 'top left',
        cursor: isDragging ? 'grabbing' : isDragMode ? 'grab' : 'default',
        touchAction: isDragMode ? 'none' : 'auto'
      }}
      className={`fixed top-0 left-0 rounded-full transition-shadow ${
        isDragging ? 'z-50' : 'z-30'
      } ${
        isDragMode ? 'ring-2 ring-emerald-400/80 ring-offset-2 ring-offset-transparent' : ''
      }`}
    >
      <div
        className={`relative w-full h-full rounded-full border ${theme.faceBg} ${theme.border} flex items-center justify-center select-none overflow-hidden`}
      >
        {/* Subtle inner radial gradient sheen */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent via-white/10 to-transparent pointer-events-none" />

        {/* 60 minute ticks & 12 hour markers */}
        {markers.map((m) => {
          const rad = (m.angle * Math.PI) / 180;
          const outerR = radius - 14;
          const innerR = m.isCardinal ? radius - 26 : radius - 20;

          const x1 = radius + Math.sin(rad) * innerR;
          const y1 = radius - Math.cos(rad) * innerR;
          const x2 = radius + Math.sin(rad) * outerR;
          const y2 = radius - Math.cos(rad) * outerR;

          return (
            <svg
              key={m.index}
              className="absolute inset-0 w-full h-full pointer-events-none"
            >
              <line
                x1={x1}
                y1={y1}
                x2={x2}
                y2={y2}
                stroke={theme.markerColor}
                strokeWidth={m.isCardinal ? 2.5 : 1.2}
                strokeLinecap="round"
                opacity={m.isCardinal ? 0.95 : 0.45}
              />
            </svg>
          );
        })}

        {/* Minimal Roman or Arabic numerals if enabled */}
        {settings.showNumerals && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <span
              className={`absolute top-6 font-bold tracking-tight text-[11px] ${theme.subtext}`}
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              12
            </span>
            <span
              className={`absolute right-7 font-bold tracking-tight text-[11px] ${theme.subtext}`}
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              3
            </span>
            <span
              className={`absolute bottom-6 font-bold tracking-tight text-[11px] ${theme.subtext}`}
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              6
            </span>
            <span
              className={`absolute left-7 font-bold tracking-tight text-[11px] ${theme.subtext}`}
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              9
            </span>
          </div>
        )}

        {/* Minimal Brand Label / City Indicator */}
        <div className="absolute top-[32%] text-center pointer-events-none">
          <span
            className={`text-[9px] font-extrabold tracking-[0.2em] uppercase opacity-75 ${theme.subtext}`}
          >
            TABPRO
          </span>
        </div>

        {/* 12h/24h indicator pill at bottom center */}
        <div className="absolute bottom-[28%] text-center pointer-events-none">
          <span
            className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-black/10 dark:bg-white/10 opacity-70 tabular-nums"
          >
            {clock.ampm}
          </span>
        </div>

        {/* Hour Hand */}
        <div
          className="absolute w-1 rounded-full origin-bottom"
          style={{
            height: `${radius * 0.52}px`,
            backgroundColor: theme.handColor,
            top: `${radius - radius * 0.52}px`,
            left: `${radius - 2}px`,
            transform: `rotate(${clock.hourAngle}deg)`,
            transformOrigin: '50% 100%',
            boxShadow: '0 3px 8px rgba(0,0,0,0.35)'
          }}
        />

        {/* Minute Hand */}
        <div
          className="absolute w-0.5 rounded-full origin-bottom"
          style={{
            height: `${radius * 0.72}px`,
            backgroundColor: theme.handColor,
            top: `${radius - radius * 0.72}px`,
            left: `${radius - 1}px`,
            transform: `rotate(${clock.minuteAngle}deg)`,
            transformOrigin: '50% 100%',
            boxShadow: '0 4px 10px rgba(0,0,0,0.3)'
          }}
        />

        {/* Second Hand (Orange / Warm Crimson with subtle tail) */}
        {settings.showSeconds && (
          <div
            className="absolute rounded-full origin-bottom z-10"
            style={{
              width: '1.5px',
              height: `${radius * 0.88}px`,
              backgroundColor: accentColor,
              top: `${radius - radius * 0.76}px`,
              left: `${radius - 0.75}px`,
              transform: `rotate(${currentSecondAngle}deg)`,
              transformOrigin: '50% 86.3%',
              boxShadow: '0 2px 8px rgba(255, 69, 58, 0.45)'
            }}
          >
            {/* Small counter-weight disc on second hand tail */}
            <div
              className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-1.5 h-3 rounded-full"
              style={{ backgroundColor: accentColor }}
            />
          </div>
        )}

        {/* Center Clock Hub Pin */}
        <div
          className="absolute z-20 w-3 h-3 rounded-full border border-black/20 shadow-md"
          style={{ backgroundColor: accentColor }}
        >
          <div className="w-1 h-1 rounded-full bg-white/90 m-auto mt-0.5" />
        </div>
      </div>
    </div>
  );
};

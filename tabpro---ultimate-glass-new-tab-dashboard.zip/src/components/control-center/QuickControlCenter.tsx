import React, { useEffect, useRef } from 'react';
import { Moon, Sun, Volume1, Volume2, VolumeX, Sparkles, Eye } from 'lucide-react';
import { LayoutSettings } from '../../types';

interface QuickControlCenterProps {
  isOpen: boolean;
  onClose: () => void;
  layout: LayoutSettings;
  onUpdateLayout: (updater: (prev: LayoutSettings) => LayoutSettings) => void;
  onOpenEditControls: () => void;
}

export const QuickControlCenter: React.FC<QuickControlCenterProps> = ({
  isOpen,
  onClose,
  layout,
  onUpdateLayout,
  onOpenEditControls
}) => {
  const panelRef = useRef<HTMLDivElement>(null);
  const lastVolumeRef = useRef<number>(layout.mediaVolume > 0 ? layout.mediaVolume : 80);
  const lastBlurRef = useRef<number>(layout.dashboardBlur > 0 ? layout.dashboardBlur : 12);

  // Keep track of last non-zero volume for unmute toggle
  useEffect(() => {
    if (layout.mediaVolume > 0) {
      lastVolumeRef.current = layout.mediaVolume;
    }
  }, [layout.mediaVolume]);

  // Keep track of last non-zero wallpaper blur for quick toggle
  useEffect(() => {
    if (layout.dashboardBlur > 0) {
      lastBlurRef.current = layout.dashboardBlur;
    }
  }, [layout.dashboardBlur]);

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const toggleFocusMode = () => {
    onUpdateLayout((prev) => ({
      ...prev,
      isZenMode: !prev.isZenMode
    }));
  };

  const toggleMute = () => {
    onUpdateLayout((prev) => ({
      ...prev,
      mediaVolume: prev.mediaVolume > 0 ? 0 : lastVolumeRef.current || 80
    }));
  };

  const toggleWallpaperBlur = () => {
    onUpdateLayout((prev) => ({
      ...prev,
      dashboardBlur: prev.dashboardBlur > 0 ? 0 : lastBlurRef.current || 12
    }));
  };

  const brightnessPct = Math.max(0, Math.min(100, ((layout.dashboardBrightness - 20) / 80) * 100));
  const soundPct = Math.max(0, Math.min(100, layout.mediaVolume));
  const blurPct = Math.max(0, Math.min(100, (layout.dashboardBlur / 24) * 100));

  return (
    /* Transparent click-outside overlay with NO background blur */
    <div className="fixed inset-0 z-50 flex justify-end items-start pt-16 pr-5 sm:pr-6 bg-transparent">
      <div
        ref={panelRef}
        className="w-[276px] max-w-[90vw] flex flex-col gap-2 select-none animate-in fade-in slide-in-from-top-3 zoom-in-95 duration-200"
      >
        {/* 1. COMPACT FOCUS PILL (Very small Apple Liquid Glass pill) */}
        <div className="flex items-center">
          <button
            onClick={toggleFocusMode}
            className={`h-8 pl-1.5 pr-3 rounded-full inline-flex items-center gap-2 transition-all duration-200 border backdrop-blur-2xl active:scale-[0.97] ${
              layout.isZenMode
                ? 'bg-gradient-to-br from-[#5e5ce6]/85 to-[#3634a3]/90 border-white/45 shadow-[0_6px_18px_rgba(94,92,230,0.4),inset_0_1px_1px_rgba(255,255,255,0.5)]'
                : 'bg-gradient-to-br from-white/25 via-cyan-400/15 to-white/10 border-white/30 shadow-[0_6px_18px_rgba(0,0,0,0.22),inset_0_1px_1px_rgba(255,255,255,0.45)] hover:from-white/30 hover:to-white/15'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full flex items-center justify-center transition-colors ${
                layout.isZenMode ? 'bg-white text-[#5e5ce6]' : 'bg-white/25 text-white'
              }`}
            >
              <Moon className="w-3 h-3 fill-current" />
            </div>
            <span className="text-[12px] font-semibold tracking-tight text-white">Focus</span>
            <span className="text-[10px] font-medium text-white/70">
              {layout.isZenMode ? 'On' : 'Off'}
            </span>
          </button>
        </div>

        {/* 2. DISPLAY BRIGHTNESS CAPSULE (Decreased Height) */}
        <div className="w-full rounded-[18px] px-3.5 py-2 bg-gradient-to-b from-[#1374f6]/80 to-[#0653d6]/85 backdrop-blur-2xl border border-white/30 shadow-[0_8px_22px_rgba(0,60,180,0.3),inset_0_1px_1px_rgba(255,255,255,0.45)]">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[12px] font-semibold text-white tracking-tight">Display</span>
          </div>

          <div className="flex items-center gap-2">
            <Sun className="w-3 h-3 text-white/90 flex-shrink-0" />

            <div className="relative flex-1 h-4 flex items-center cursor-pointer">
              <div className="w-full h-[5px] rounded-full bg-white/30 overflow-hidden">
                <div
                  className="h-full bg-white rounded-full transition-all duration-75"
                  style={{ width: `${brightnessPct}%` }}
                />
              </div>
              <div
                className="absolute w-4 h-4 rounded-full bg-white shadow-[0_2px_6px_rgba(0,0,0,0.35)] pointer-events-none transition-all duration-75"
                style={{ left: `calc(${brightnessPct}% - ${brightnessPct * 0.16}px)` }}
              />
              <input
                type="range"
                min="20"
                max="100"
                value={layout.dashboardBrightness}
                onChange={(e) =>
                  onUpdateLayout((prev) => ({
                    ...prev,
                    dashboardBrightness: Number(e.target.value)
                  }))
                }
                aria-label="Display Brightness"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>

            <Sun className="w-3.5 h-3.5 text-white flex-shrink-0" />
          </div>
        </div>

        {/* 3. SOUND VOLUME CAPSULE (Decreased Height) */}
        <div className="w-full rounded-[18px] px-3.5 py-2 bg-gradient-to-b from-[#1374f6]/80 to-[#0653d6]/85 backdrop-blur-2xl border border-white/30 shadow-[0_8px_22px_rgba(0,60,180,0.3),inset_0_1px_1px_rgba(255,255,255,0.45)]">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[12px] font-semibold text-white tracking-tight">Sound</span>
          </div>

          <div className="flex items-center gap-2">
            <Volume1 className="w-3.5 h-3.5 text-white/90 flex-shrink-0" />

            <div className="relative flex-1 h-4 flex items-center cursor-pointer">
              <div className="w-full h-[5px] rounded-full bg-white/30 overflow-hidden">
                <div
                  className="h-full bg-white rounded-full transition-all duration-75"
                  style={{ width: `${soundPct}%` }}
                />
              </div>
              <div
                className="absolute w-4 h-4 rounded-full bg-white shadow-[0_2px_6px_rgba(0,0,0,0.35)] pointer-events-none transition-all duration-75"
                style={{ left: `calc(${soundPct}% - ${soundPct * 0.16}px)` }}
              />
              <input
                type="range"
                min="0"
                max="100"
                value={layout.mediaVolume}
                onChange={(e) =>
                  onUpdateLayout((prev) => ({
                    ...prev,
                    mediaVolume: Number(e.target.value)
                  }))
                }
                aria-label="Sound Volume"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>

            <Volume2 className="w-3.5 h-3.5 text-white flex-shrink-0" />

            <button
              onClick={toggleMute}
              title={layout.mediaVolume === 0 ? 'Unmute Media' : 'Mute Media'}
              className="w-6 h-6 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors flex-shrink-0"
            >
              {layout.mediaVolume === 0 ? (
                <VolumeX className="w-3 h-3" />
              ) : (
                <Volume2 className="w-3 h-3" />
              )}
            </button>
          </div>
        </div>

        {/* 4. WALLPAPER BLUR CAPSULE (New option to blur background wallpaper) */}
        <div className="w-full rounded-[18px] px-3.5 py-2 bg-gradient-to-b from-[#1374f6]/80 to-[#0653d6]/85 backdrop-blur-2xl border border-white/30 shadow-[0_8px_22px_rgba(0,60,180,0.3),inset_0_1px_1px_rgba(255,255,255,0.45)]">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[12px] font-semibold text-white tracking-tight">
              Wallpaper Blur
            </span>
            <span className="text-[10px] font-medium text-white/80">
              {layout.dashboardBlur === 0 ? 'Off' : `${layout.dashboardBlur}px`}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Eye className="w-3.5 h-3.5 text-white/90 flex-shrink-0" />

            <div className="relative flex-1 h-4 flex items-center cursor-pointer">
              <div className="w-full h-[5px] rounded-full bg-white/30 overflow-hidden">
                <div
                  className="h-full bg-white rounded-full transition-all duration-75"
                  style={{ width: `${blurPct}%` }}
                />
              </div>
              <div
                className="absolute w-4 h-4 rounded-full bg-white shadow-[0_2px_6px_rgba(0,0,0,0.35)] pointer-events-none transition-all duration-75"
                style={{ left: `calc(${blurPct}% - ${blurPct * 0.16}px)` }}
              />
              <input
                type="range"
                min="0"
                max="24"
                step="1"
                value={layout.dashboardBlur}
                onChange={(e) =>
                  onUpdateLayout((prev) => ({
                    ...prev,
                    dashboardBlur: Number(e.target.value)
                  }))
                }
                aria-label="Wallpaper Blur"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>

            <button
              onClick={toggleWallpaperBlur}
              title={layout.dashboardBlur > 0 ? 'Turn Off Wallpaper Blur' : 'Blur Background Wallpaper'}
              className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors flex-shrink-0 ${
                layout.dashboardBlur > 0
                  ? 'bg-white text-[#0653d6]'
                  : 'bg-white/20 hover:bg-white/30 text-white'
              }`}
            >
              <Sparkles className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* 5. EDIT CONTROLS PILL */}
        <div className="flex justify-center pt-0.5">
          <button
            onClick={() => {
              onClose();
              onOpenEditControls();
            }}
            className="px-4 py-1 rounded-full bg-white/15 hover:bg-white/25 backdrop-blur-2xl border border-white/30 text-[11px] font-medium text-white shadow-[0_6px_20px_rgba(0,0,0,0.25),inset_0_1px_0_rgba(255,255,255,0.4)] transition-all active:scale-95"
          >
            Edit Controls
          </button>
        </div>
      </div>
    </div>
  );
};

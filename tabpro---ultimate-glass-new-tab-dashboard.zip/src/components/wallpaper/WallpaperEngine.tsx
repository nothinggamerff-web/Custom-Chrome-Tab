import React, { useRef, useEffect } from 'react';
import { Wallpaper, LayoutSettings } from '../../types';

interface WallpaperEngineProps {
  wallpaper: Wallpaper;
  layout: LayoutSettings;
}

export const WallpaperEngine: React.FC<WallpaperEngineProps> = ({ wallpaper, layout }) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = Math.max(0, Math.min(1, layout.mediaVolume / 100));
    }
  }, [layout.mediaVolume]);

  const filterStyle = {
    filter: `brightness(${layout.dashboardBrightness}%) blur(${layout.dashboardBlur}px) contrast(${layout.dashboardContrast}%) saturate(${layout.dashboardSaturate}%)`,
    transform: layout.dashboardBlur > 0 ? 'scale(1.05)' : 'scale(1)',
    transition: 'filter 0.25s ease, transform 0.25s ease'
  };

  return (
    <>
      <div
        className="fixed inset-0 -z-30 bg-black pointer-events-none select-none overflow-hidden"
        style={filterStyle}
      >
        {wallpaper.isVideo ? (
          <video
            ref={videoRef}
            key={wallpaper.url}
            src={wallpaper.url}
            autoPlay
            loop
            muted={layout.mediaVolume === 0}
            playsInline
            className="w-full h-full object-cover object-center pointer-events-none transition-opacity duration-700"
          />
        ) : (
          <div
            key={wallpaper.url}
            className="w-full h-full bg-cover bg-center transition-all duration-700"
            style={{ backgroundImage: `url('${wallpaper.url}')` }}
          />
        )}
      </div>

      {/* Subtle vignette scrim overlay */}
      <div
        className="fixed inset-0 -z-20 pointer-events-none"
        style={{
          background: 'radial-gradient(circle at 50% 35%, rgba(0,0,0,0.12) 0%, rgba(0,0,0,0.65) 100%)'
        }}
      />
    </>
  );
};

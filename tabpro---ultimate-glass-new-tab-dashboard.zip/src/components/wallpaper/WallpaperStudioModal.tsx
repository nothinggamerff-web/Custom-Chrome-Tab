import React, { useState } from 'react';
import { X, Image as ImageIcon, Video, Upload, Link, Check, Trash2, Plus } from 'lucide-react';
import { Wallpaper } from '../../types';
import { DEFAULT_LIVE_WALLPAPERS, DEFAULT_IMAGE_WALLPAPERS } from '../../constants/wallpapers';

interface WallpaperStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeWallpaper: Wallpaper;
  onSelectWallpaper: (wp: Wallpaper) => void;
  customWallpapers: Wallpaper[];
  onAddCustomWallpaper: (wp: Wallpaper) => void;
  onDeleteCustomWallpaper: (id: string) => void;
}

export const WallpaperStudioModal: React.FC<WallpaperStudioModalProps> = ({
  isOpen,
  onClose,
  activeWallpaper,
  onSelectWallpaper,
  customWallpapers,
  onAddCustomWallpaper,
  onDeleteCustomWallpaper
}) => {
  const [tab, setTab] = useState<'all' | 'live' | 'image' | 'custom'>('all');
  const [urlInput, setUrlInput] = useState('');
  const [titleInput, setTitleInput] = useState('');

  if (!isOpen) return null;

  const handleApplyUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;

    const isVideo = /\.(mp4|webm|mov)($|\?)/i.test(urlInput) || urlInput.includes('video') || urlInput.includes('previewhd');
    const newWp: Wallpaper = {
      id: `custom-wp-${Date.now()}`,
      title: titleInput.trim() || (isVideo ? 'Live Video Wallpaper' : 'Custom Image Wallpaper'),
      url: urlInput.trim(),
      isVideo,
      category: 'custom',
      thumbnail: isVideo
        ? 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=400&q=80'
        : urlInput.trim()
    };

    onAddCustomWallpaper(newWp);
    onSelectWallpaper(newWp);
    setUrlInput('');
    setTitleInput('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const blobUrl = URL.createObjectURL(file);
    const isVideo = file.type.startsWith('video');
    const cleanName = file.name.replace(/\.[^/.]+$/, '');

    const newWp: Wallpaper = {
      id: `local-wp-${Date.now()}`,
      title: cleanName || 'Uploaded Wallpaper',
      url: blobUrl,
      isVideo,
      category: 'custom',
      thumbnail: isVideo
        ? 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80'
        : blobUrl
    };

    onAddCustomWallpaper(newWp);
    onSelectWallpaper(newWp);
  };

  const allWallpapers = [
    ...DEFAULT_LIVE_WALLPAPERS,
    ...DEFAULT_IMAGE_WALLPAPERS,
    ...customWallpapers
  ];

  const displayedWallpapers = allWallpapers.filter((wp) => {
    if (tab === 'live') return wp.isVideo;
    if (tab === 'image') return !wp.isVideo && wp.category === 'image';
    if (tab === 'custom') return wp.category === 'custom';
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
      <div className="w-full max-w-4xl p-6 rounded-3xl bg-[#141620] border border-white/20 shadow-2xl animate-in fade-in zoom-in-95 duration-150 text-white max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-white/10 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-500 flex items-center justify-center shadow-md">
              <ImageIcon className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Wallpaper Studio</h3>
              <p className="text-[11px] text-white/50">Live MP4 Loops, 4K Presets, Custom URLs and Local Uploads</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/10 text-white/60 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Add Custom Wallpaper Bar */}
        <div className="p-3.5 mb-4 rounded-2xl bg-white/5 border border-white/10 flex-shrink-0">
          <div className="text-xs font-bold text-emerald-400 mb-2 flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5" />
            Add Custom Wallpaper (Live Video or Static Image)
          </div>
          <form onSubmit={handleApplyUrl} className="flex flex-wrap items-center gap-2">
            <input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="Paste image URL or MP4/WebM live loop URL..."
              className="flex-1 min-w-[200px] px-3 py-2 rounded-xl bg-white/10 border border-white/15 text-xs text-white placeholder-white/40 outline-none focus:border-emerald-400"
            />
            <input
              type="text"
              value={titleInput}
              onChange={(e) => setTitleInput(e.target.value)}
              placeholder="Title (optional)"
              className="w-40 px-3 py-2 rounded-xl bg-white/10 border border-white/15 text-xs text-white placeholder-white/40 outline-none focus:border-emerald-400"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white shadow-md transition-all flex items-center gap-1.5"
            >
              <Link className="w-3.5 h-3.5" />
              Apply URL
            </button>
            <label className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white/90 border border-white/15 cursor-pointer flex items-center gap-1.5 transition-all">
              <Upload className="w-3.5 h-3.5" />
              Upload File
              <input
                type="file"
                accept="image/*,video/mp4,video/webm"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </form>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 mb-3 pb-2 border-b border-white/10 flex-shrink-0">
          <button
            onClick={() => setTab('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              tab === 'all' ? 'bg-white/20 text-white' : 'text-white/60 hover:text-white'
            }`}
          >
            All Wallpapers ({allWallpapers.length})
          </button>
          <button
            onClick={() => setTab('live')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              tab === 'live' ? 'bg-white/20 text-white' : 'text-white/60 hover:text-white'
            }`}
          >
            <Video className="w-3 h-3 text-cyan-400" />
            Live Videos ({DEFAULT_LIVE_WALLPAPERS.length})
          </button>
          <button
            onClick={() => setTab('image')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              tab === 'image' ? 'bg-white/20 text-white' : 'text-white/60 hover:text-white'
            }`}
          >
            <ImageIcon className="w-3 h-3 text-amber-400" />
            4K Static ({DEFAULT_IMAGE_WALLPAPERS.length})
          </button>
          <button
            onClick={() => setTab('custom')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              tab === 'custom' ? 'bg-white/20 text-white' : 'text-white/60 hover:text-white'
            }`}
          >
            Custom & Uploads ({customWallpapers.length})
          </button>
        </div>

        {/* Gallery Grid */}
        <div className="flex-1 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 pr-1">
          {displayedWallpapers.map((wp) => {
            const isActive = activeWallpaper.id === wp.id || activeWallpaper.url === wp.url;
            return (
              <div
                key={wp.id}
                onClick={() => onSelectWallpaper(wp)}
                className={`group relative h-28 rounded-2xl overflow-hidden cursor-pointer border-2 transition-all duration-200 hover:scale-[1.03] shadow-lg ${
                  isActive ? 'border-emerald-400 ring-2 ring-emerald-400/50' : 'border-transparent hover:border-white/40'
                }`}
                style={{
                  backgroundImage: `url('${wp.thumbnail || wp.url}')`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center'
                }}
              >
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent flex flex-col justify-between p-2">
                  <div className="flex items-center justify-between">
                    {wp.isVideo ? (
                      <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded-md bg-cyan-500/80 text-black flex items-center gap-1">
                        <Video className="w-2.5 h-2.5" />
                        Live
                      </span>
                    ) : (
                      <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded-md bg-black/60 text-white/90">
                        4K
                      </span>
                    )}

                    {isActive && (
                      <span className="w-5 h-5 rounded-full bg-emerald-400 text-black flex items-center justify-center text-xs shadow-md">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}

                    {wp.category === 'custom' && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteCustomWallpaper(wp.id);
                        }}
                        className="w-5 h-5 rounded-full bg-black/70 hover:bg-red-500 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all"
                        title="Delete custom wallpaper"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>

                  <span className="text-[11px] font-bold text-white truncate drop-shadow-md">
                    {wp.title}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

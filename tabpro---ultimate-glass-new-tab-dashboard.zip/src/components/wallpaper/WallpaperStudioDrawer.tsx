import React, { useState } from 'react';
import { X, Image as ImageIcon, Video, Upload, Link, Check, Trash2, Plus } from 'lucide-react';
import { Wallpaper } from '../../types';
import { DEFAULT_LIVE_WALLPAPERS, DEFAULT_IMAGE_WALLPAPERS } from '../../constants/wallpapers';

interface WallpaperStudioDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeWallpaper: Wallpaper;
  onSelectWallpaper: (wp: Wallpaper) => void;
  customWallpapers: Wallpaper[];
  onAddCustomWallpaper: (wp: Wallpaper) => void;
  onAddCustomWallpapers?: (wps: Wallpaper[]) => void;
  onDeleteCustomWallpaper: (id: string) => void;
}

export const WallpaperStudioDrawer: React.FC<WallpaperStudioDrawerProps> = ({
  isOpen,
  onClose,
  activeWallpaper,
  onSelectWallpaper,
  customWallpapers,
  onAddCustomWallpaper,
  onAddCustomWallpapers,
  onDeleteCustomWallpaper
}) => {
  const [tab, setTab] = useState<'all' | 'live' | 'image' | 'custom'>('all');
  const [urlInput, setUrlInput] = useState('');
  const [titleInput, setTitleInput] = useState('');
  const [failedMedia, setFailedMedia] = useState<Record<string, boolean>>({});

  if (!isOpen) return null;

  const handleApplyUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;

    const cleanUrl = urlInput.trim();
    const isVideo =
      /\.(mp4|webm|mov|m4v|ogg)($|\?)/i.test(cleanUrl) ||
      cleanUrl.includes('video') ||
      cleanUrl.includes('previewhd');

    const newWp: Wallpaper = {
      id: `custom-wp-${Date.now()}`,
      title: titleInput.trim() || (isVideo ? 'Live Video Wallpaper' : 'Custom Image Wallpaper'),
      url: cleanUrl,
      isVideo,
      category: 'custom',
      thumbnail: isVideo ? undefined : cleanUrl
    };

    onAddCustomWallpaper(newWp);
    onSelectWallpaper(newWp);
    setUrlInput('');
    setTitleInput('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const now = Date.now();
    const uploadedWallpapers: Wallpaper[] = files.map((file, idx) => {
      const blobUrl = URL.createObjectURL(file);
      const isVideo = file.type.startsWith('video') || /\.(mp4|webm|mov|m4v|ogg)$/i.test(file.name);
      const cleanName = file.name.replace(/\.[^/.]+$/, '');

      return {
        id: `local-wp-${now}-${idx}`,
        title: cleanName || 'Uploaded Wallpaper',
        url: blobUrl,
        isVideo,
        category: 'custom',
        thumbnail: isVideo ? undefined : blobUrl
      };
    });

    if (onAddCustomWallpapers) {
      onAddCustomWallpapers(uploadedWallpapers);
    } else {
      uploadedWallpapers.forEach((wp) => onAddCustomWallpaper(wp));
    }

    onSelectWallpaper(uploadedWallpapers[0]);
    e.target.value = '';
  };

  const allWallpapers = [
    ...DEFAULT_LIVE_WALLPAPERS,
    ...DEFAULT_IMAGE_WALLPAPERS,
    ...customWallpapers
  ];

  const displayedWallpapers = allWallpapers.filter((wp) => {
    if (tab === 'live') return wp.isVideo;
    if (tab === 'image') return !wp.isVideo && wp.category === 'image';
    if (tab === 'custom') return wp.category === 'custom';
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex justify-end pointer-events-none select-none">
      {/* Note: NO heavy blur background overlay so user sees wallpaper update live! */}
      <div className="pointer-events-auto w-[380px] max-w-full h-full bg-[#12141c]/90 text-white backdrop-blur-md border-l border-white/20 shadow-[-16px_0_50px_rgba(0,0,0,0.65)] flex flex-col animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-500 flex items-center justify-center shadow-md">
              <ImageIcon className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">Wallpaper Studio</h3>
              <p className="text-[10px] text-white/50">Live MP4 Loops & 4K Aesthetics</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full flex items-center justify-center hover:bg-white/10 text-white/60 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Custom URL or Multi-File Upload bar */}
        <div className="p-3 border-b border-white/10 flex-shrink-0">
          <div className="text-[11px] font-bold text-emerald-400 mb-2 flex items-center gap-1">
            <Plus className="w-3 h-3" />
            Add Wallpapers (Multi-Upload or URL)
          </div>
          <form onSubmit={handleApplyUrl} className="space-y-2">
            <input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="Paste image URL or MP4 live loop..."
              className="w-full px-2.5 py-1.5 rounded-xl bg-white/10 border border-white/15 text-xs text-white placeholder-white/40 outline-none focus:border-emerald-400"
            />
            <div className="flex gap-2">
              <button
                type="submit"
                className="flex-1 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white shadow-md transition-colors flex items-center justify-center gap-1"
              >
                <Link className="w-3 h-3" />
                Apply URL
              </button>
              <label
                className="flex-1 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white/90 border border-white/15 cursor-pointer flex items-center justify-center gap-1 transition-colors"
                title="Select one or multiple images and videos"
              >
                <Upload className="w-3 h-3" />
                Upload Files
                <input
                  type="file"
                  multiple
                  accept="image/*,video/mp4,video/webm,video/quicktime,video/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </form>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-1 p-2 border-b border-white/10 flex-shrink-0 text-[11px] font-semibold overflow-x-auto scrollbar-none">
          <button
            onClick={() => setTab('all')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              tab === 'all' ? 'bg-white/20 text-white font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            All ({allWallpapers.length})
          </button>
          <button
            onClick={() => setTab('live')}
            className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 ${
              tab === 'live' ? 'bg-white/20 text-white font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            <Video className="w-3 h-3 text-cyan-400" />
            Live ({allWallpapers.filter((w) => w.isVideo).length})
          </button>
          <button
            onClick={() => setTab('image')}
            className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 ${
              tab === 'image' ? 'bg-white/20 text-white font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            <ImageIcon className="w-3 h-3 text-amber-400" />
            4K ({DEFAULT_IMAGE_WALLPAPERS.length})
          </button>
          <button
            onClick={() => setTab('custom')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              tab === 'custom' ? 'bg-white/20 text-white font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            Uploads ({customWallpapers.length})
          </button>
        </div>

        {/* Gallery Grid */}
        <div className="flex-1 overflow-y-auto p-3 grid grid-cols-2 gap-2.5">
          {displayedWallpapers.map((wp) => {
            const isActive = activeWallpaper.id === wp.id || activeWallpaper.url === wp.url;
            const hasFailed = failedMedia[wp.id];

            return (
              <div
                key={wp.id}
                onClick={() => onSelectWallpaper(wp)}
                className={`group relative h-24 rounded-2xl overflow-hidden cursor-pointer border-2 bg-[#0c0e14] transition-all duration-200 hover:scale-[1.03] shadow-md ${
                  isActive ? 'border-emerald-400 ring-2 ring-emerald-400/40' : 'border-transparent hover:border-white/40'
                }`}
              >
                {/* Real Live Video Preview or Image Preview */}
                {wp.isVideo && !hasFailed ? (
                  <video
                    src={wp.url}
                    autoPlay
                    loop
                    muted
                    playsInline
                    preload="auto"
                    onError={() => setFailedMedia((prev) => ({ ...prev, [wp.id]: true }))}
                    className="absolute inset-0 w-full h-full object-cover object-center pointer-events-none"
                  />
                ) : !hasFailed ? (
                  <img
                    src={wp.isVideo ? wp.thumbnail || wp.url : wp.url}
                    alt={wp.title}
                    loading="lazy"
                    onError={() => setFailedMedia((prev) => ({ ...prev, [wp.id]: true }))}
                    className="absolute inset-0 w-full h-full object-cover object-center pointer-events-none"
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-slate-800 to-slate-950 text-white/40">
                    {wp.isVideo ? <Video className="w-6 h-6" /> : <ImageIcon className="w-6 h-6" />}
                  </div>
                )}

                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/15 to-transparent flex flex-col justify-between p-2">
                  <div className="flex items-center justify-between">
                    {wp.isVideo ? (
                      <span className="text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-cyan-500/85 text-black flex items-center gap-0.5">
                        <Video className="w-2.5 h-2.5" />
                        Live
                      </span>
                    ) : (
                      <span className="text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-black/60 text-white/90">
                        4K
                      </span>
                    )}

                    <div className="flex items-center gap-1">
                      {isActive && (
                        <span className="w-4 h-4 rounded-full bg-emerald-400 text-black flex items-center justify-center text-[10px] shadow-md">
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </span>
                      )}

                      {wp.category === 'custom' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteCustomWallpaper(wp.id);
                          }}
                          className="w-4 h-4 rounded-full bg-black/70 hover:bg-red-500 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all"
                          title="Delete custom wallpaper"
                        >
                          <Trash2 className="w-2.5 h-2.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  <span className="text-[10px] font-bold text-white truncate drop-shadow-md">
                    {wp.title}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

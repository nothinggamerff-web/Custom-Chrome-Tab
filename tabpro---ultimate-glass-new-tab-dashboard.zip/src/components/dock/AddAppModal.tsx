import React, { useState } from 'react';
import { X, Plus, Globe, Link2 } from 'lucide-react';
import { QuickApp } from '../../types';
import { getFaviconUrl } from '../../utils/favicon';

interface AddAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddApp: (app: QuickApp) => void;
}

const KNOWN_APP_NAMES: Record<string, string> = {
  'google.com': 'Google',
  'mail.google.com': 'Gmail',
  'docs.google.com': 'Google Docs',
  'sheets.google.com': 'Google Sheets',
  'slides.google.com': 'Google Slides',
  'drive.google.com': 'Google Drive',
  'calendar.google.com': 'Google Calendar',
  'meet.google.com': 'Google Meet',
  'maps.google.com': 'Google Maps',
  'youtube.com': 'YouTube',
  'youtu.be': 'YouTube',
  'music.youtube.com': 'YouTube Music',
  'github.com': 'GitHub',
  'chatgpt.com': 'ChatGPT',
  'chat.openai.com': 'ChatGPT',
  'openai.com': 'OpenAI',
  'claude.ai': 'Claude',
  'perplexity.ai': 'Perplexity',
  'x.com': 'X',
  'twitter.com': 'X',
  'linkedin.com': 'LinkedIn',
  'whatsapp.com': 'WhatsApp',
  'web.whatsapp.com': 'WhatsApp',
  'spotify.com': 'Spotify',
  'open.spotify.com': 'Spotify',
  'netflix.com': 'Netflix',
  'figma.com': 'Figma',
  'notion.so': 'Notion',
  'reddit.com': 'Reddit',
  'instagram.com': 'Instagram',
  'facebook.com': 'Facebook',
  'discord.com': 'Discord',
  'slack.com': 'Slack',
  'vercel.com': 'Vercel',
  'amazon.com': 'Amazon',
  'amazon.in': 'Amazon',
  'flipkart.com': 'Flipkart',
  'wikipedia.org': 'Wikipedia'
};

export const deriveAppNameFromUrl = (rawUrl: string): string => {
  const trimmed = rawUrl.trim();
  if (!trimmed) return '';
  try {
    const normalized = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    const parsed = new URL(normalized);
    const host = parsed.hostname.toLowerCase().replace(/^www\./, '');
    if (KNOWN_APP_NAMES[host]) return KNOWN_APP_NAMES[host];

    const parts = host.split('.').filter(Boolean);
    if (parts.length === 0) return '';
    // Pick primary brand segment (skip leading generic prefixes if another segment exists)
    const genericPrefixes = new Set(['app', 'web', 'open', 'm', 'portal', 'my']);
    const candidate =
      parts.length > 2 && genericPrefixes.has(parts[0]) ? parts[1] : parts[0];
    if (!candidate) return '';
    return candidate.charAt(0).toUpperCase() + candidate.slice(1);
  } catch {
    return '';
  }
};

export const AddAppModal: React.FC<AddAppModalProps> = ({ isOpen, onClose, onAddApp }) => {
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');
  const [hasCustomTitle, setHasCustomTitle] = useState(false);
  const [faviconError, setFaviconError] = useState(false);

  if (!isOpen) return null;

  const handleUrlChange = (val: string) => {
    setUrl(val);
    setFaviconError(false);
    if (!hasCustomTitle) {
      setTitle(deriveAppNameFromUrl(val));
    }
  };

  const handleTitleChange = (val: string) => {
    setTitle(val);
    setHasCustomTitle(val.trim().length > 0);
    if (val.trim().length === 0 && url.trim().length > 0) {
      // Allow user to clear, or auto-derive on submit
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedUrl = url.trim();
    if (!trimmedUrl) return;

    const targetUrl = /^https?:\/\//i.test(trimmedUrl) ? trimmedUrl : `https://${trimmedUrl}`;
    const resolvedTitle = title.trim() || deriveAppNameFromUrl(targetUrl) || 'Quick App';

    const newApp: QuickApp = {
      id: `custom-app-${Date.now()}`,
      title: resolvedTitle,
      url: targetUrl,
      color: '',
      iconType: 'favicon'
    };

    onAddApp(newApp);
    setTitle('');
    setUrl('');
    setHasCustomTitle(false);
    setFaviconError(false);
    onClose();
  };

  const previewFavicon = url.trim().includes('.') ? getFaviconUrl(url) : '';

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xs p-4 rounded-3xl bg-[#141620]/95 backdrop-blur-2xl border border-white/20 shadow-2xl animate-in fade-in zoom-in-95 duration-150 text-white"
      >
        <div className="flex items-center justify-between pb-2.5 mb-3.5 border-b border-white/10">
          <h3 className="text-xs font-bold flex items-center gap-2">
            <Plus className="w-4 h-4 text-emerald-400" />
            Add Quick App
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="w-6 h-6 rounded-full flex items-center justify-center hover:bg-white/10 text-white/60 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          {/* Live Original App Icon Preview + URL */}
          <div>
            <label className="block text-[11px] font-semibold text-white/70 mb-1">
              Website URL
            </label>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-white/10 border border-white/15 flex items-center justify-center flex-shrink-0 overflow-hidden">
                {previewFavicon && !faviconError ? (
                  <img
                    src={previewFavicon}
                    alt="App Icon"
                    className="w-5 h-5 object-contain rounded-sm"
                    onError={() => setFaviconError(true)}
                  />
                ) : (
                  <Globe className="w-4 h-4 text-white/50" />
                )}
              </div>
              <div className="relative flex-1">
                <Link2 className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-white/40" />
                <input
                  type="text"
                  value={url}
                  onChange={(e) => handleUrlChange(e.target.value)}
                  placeholder="https://figma.com"
                  required
                  autoFocus
                  className="w-full pl-8 pr-3 py-2 rounded-xl bg-white/10 border border-white/15 text-xs text-white placeholder-white/40 outline-none focus:border-blue-400"
                />
              </div>
            </div>
          </div>

          {/* App Name (auto-filled from URL, customizable) */}
          <div>
            <label className="block text-[11px] font-semibold text-white/70 mb-1">
              App Name <span className="text-white/40 font-normal">(auto-detected from URL)</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => handleTitleChange(e.target.value)}
              placeholder={deriveAppNameFromUrl(url) || 'Auto-filled from URL'}
              className="w-full px-3 py-2 rounded-xl bg-white/10 border border-white/15 text-xs text-white placeholder-white/40 outline-none focus:border-blue-400"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white shadow-lg transition-colors"
            >
              Add App
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Plus, X, Globe, Move } from 'lucide-react';
import { QuickApp, ElementPosition, ElementThemeStyle } from '../../types';
import { AddAppModal } from './AddAppModal';
import { getFaviconUrl } from '../../utils/favicon';
import { useDraggable } from '../../hooks/useDraggable';
import { getThemeSurfaceClasses } from '../../utils/theme';

interface BottomDockProps {
  apps: QuickApp[];
  onAddApp: (app: QuickApp) => void;
  onRemoveApp: (id: string) => void;
  onLaunchApp?: (title: string, url: string) => void;
  position: ElementPosition;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
  scale: number;
  themeStyle?: ElementThemeStyle;
}

export const BottomDock: React.FC<BottomDockProps> = ({
  apps,
  onAddApp,
  onRemoveApp,
  onLaunchApp,
  position,
  isDragMode = false,
  onPositionChange,
  scale,
  themeStyle = 'oled'
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [hoveredAppId, setHoveredAppId] = useState<string | null>(null);
  const [failedFavicons, setFailedFavicons] = useState<Record<string, boolean>>({});

  const { elementRef, isDragging, dragProps } = useDraggable({
    position,
    isDragMode,
    onPositionChange
  });

  const handleFaviconError = (appId: string) => {
    setFailedFavicons((prev) => ({ ...prev, [appId]: true }));
  };

  return (
    <>
      <div
        ref={elementRef}
        {...dragProps}
        style={{
          transform: `translate3d(calc(-50% + ${position.x}px), ${position.y}px, 0) scale(${scale})`,
          cursor: isDragging ? 'grabbing' : isDragMode ? 'grab' : 'default',
          touchAction: isDragMode ? 'none' : 'auto'
        }}
        className={`fixed bottom-6 left-1/2 flex items-center gap-2.5 px-4 py-2.5 rounded-3xl backdrop-blur-2xl border transition-shadow origin-bottom select-none ${getThemeSurfaceClasses(themeStyle)} ${
          isDragging ? 'z-50' : 'z-30'
        } ${isDragMode ? 'ring-2 ring-emerald-400/80' : ''}`}
      >
        {isDragMode && (
          <div className="flex items-center text-emerald-400 pl-1 pr-0.5 cursor-grab">
            <Move className="w-3.5 h-3.5 opacity-80" />
          </div>
        )}

        {apps.map((app) => {
          const faviconSrc = getFaviconUrl(app.url);
          const hasFailed = failedFavicons[app.id];

          return (
            <div
              key={app.id}
              className="relative group"
              onMouseEnter={() => setHoveredAppId(app.id)}
              onMouseLeave={() => setHoveredAppId(null)}
            >
              <a
                href={app.url}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => onLaunchApp?.(app.title, app.url)}
                title={app.title}
                className="w-11 h-11 rounded-2xl flex items-center justify-center p-2 text-white shadow-lg transition-all duration-200 hover:-translate-y-2 hover:scale-115 active:scale-95 bg-white/10 hover:bg-white/20 border border-white/15"
              >
                {!hasFailed && faviconSrc ? (
                  <img
                    src={faviconSrc}
                    alt={app.title}
                    className="w-6 h-6 object-contain rounded-md drop-shadow transition-transform duration-200"
                    onError={() => handleFaviconError(app.id)}
                    loading="lazy"
                  />
                ) : (
                  <Globe className="w-5 h-5 text-white/80" />
                )}
              </a>

              {/* Tooltip */}
              <div className="absolute -top-8 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-lg bg-black/85 backdrop-blur-md border border-white/15 text-white text-[10px] font-semibold whitespace-nowrap pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
                {app.title}
              </div>

              {/* Delete badge */}
              {hoveredAppId === app.id && (
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    onRemoveApp(app.id);
                  }}
                  className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center text-[10px] shadow-md z-10 transition-transform active:scale-75"
                  title="Remove quick app"
                >
                  <X className="w-2.5 h-2.5" />
                </button>
              )}
            </div>
          );
        })}

        {/* Add App Button */}
        <button
          onClick={() => setShowAddModal(true)}
          className="w-11 h-11 rounded-2xl flex items-center justify-center bg-white/10 hover:bg-white/20 text-white/80 hover:text-white border border-dashed border-white/30 shadow-md transition-all duration-200 hover:-translate-y-1 hover:scale-105 active:scale-95"
          title="Add new quick app"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <AddAppModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onAddApp={onAddApp}
      />
    </>
  );
};

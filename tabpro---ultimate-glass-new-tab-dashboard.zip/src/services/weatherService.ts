import { WeatherData, HourlyForecast } from '../types';

export function mapWeatherCode(code: number): { condition: string; icon: string } {
  switch (code) {
    case 0:
      return { condition: 'Clear Sky', icon: '☀️' };
    case 1:
      return { condition: 'Mainly Clear', icon: '🌤️' };
    case 2:
      return { condition: 'Partly Cloudy', icon: '⛅' };
    case 3:
      return { condition: 'Overcast', icon: '☁️' };
    case 45:
    case 48:
      return { condition: 'Foggy & Mist', icon: '🌫️' };
    case 51:
    case 53:
    case 55:
      return { condition: 'Drizzle', icon: '🌦️' };
    case 61:
    case 63:
    case 65:
      return { condition: 'Rain Showers', icon: '🌧️' };
    case 71:
    case 73:
    case 75:
      return { condition: 'Snowfall', icon: '❄️' };
    case 80:
    case 81:
    case 82:
      return { condition: 'Heavy Rain', icon: '⛈️' };
    case 95:
    case 96:
    case 99:
      return { condition: 'Thunderstorm', icon: '⚡' };
    default:
      return { condition: 'Fair', icon: '🌤️' };
  }
}

interface CacheEntry {
  data: WeatherData;
  timestamp: number;
}

const CACHE_KEY_PREFIX = 'tabpro_weather_cache_';
const CACHE_TTL_MS = 20 * 60 * 1000; // 20 minutes

export async function fetchWeather(
  lat: number,
  lon: number,
  cityName: string,
  regionName: string,
  isCelsius: boolean = true
): Promise<WeatherData> {
  const cacheKey = `${CACHE_KEY_PREFIX}${lat.toFixed(2)}_${lon.toFixed(2)}_${isCelsius}`;
  const cachedStr = localStorage.getItem(cacheKey);

  if (cachedStr) {
    try {
      const cached: CacheEntry = JSON.parse(cachedStr);
      if (Date.now() - cached.timestamp < CACHE_TTL_MS) {
        return cached.data;
      }
    } catch {
      // ignore cache parsing error
    }
  }

  const tempUnit = isCelsius ? 'celsius' : 'fahrenheit';
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&hourly=temperature_2m,precipitation_probability,weather_code&daily=temperature_2m_max,temperature_2m_min&temperature_unit=${tempUnit}&timezone=auto`;

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Weather service responded with status ${res.status}`);
  }

  const json = await res.json();
  const current = json.current;
  const hourly = json.hourly;
  const daily = json.daily;

  const code = current?.weather_code ?? 0;
  const { condition } = mapWeatherCode(code);

  // Next 6 hours
  const now = new Date();
  const currentHour = now.getHours();
  const hourlyForecast: HourlyForecast[] = [];

  if (hourly && Array.isArray(hourly.time)) {
    for (let i = currentHour; i < currentHour + 6 && i < hourly.time.length; i++) {
      const timeDate = new Date(hourly.time[i]);
      let hourFmt = timeDate.toLocaleTimeString([], { hour: 'numeric', hour12: true });
      if (i === currentHour) hourFmt = 'Now';
      hourlyForecast.push({
        timeStr: hourFmt,
        temp: Math.round(hourly.temperature_2m[i]),
        weatherCode: hourly.weather_code[i] ?? 0,
        rainProb: hourly.precipitation_probability ? hourly.precipitation_probability[i] ?? 0 : 0
      });
    }
  }

  const weatherData: WeatherData = {
    city: cityName,
    region: regionName,
    temp: Math.round(current?.temperature_2m ?? 24),
    condition,
    weatherCode: code,
    feelsLike: Math.round(current?.apparent_temperature ?? current?.temperature_2m ?? 24),
    high: Math.round(daily?.temperature_2m_max?.[0] ?? current?.temperature_2m ?? 26),
    low: Math.round(daily?.temperature_2m_min?.[0] ?? (current?.temperature_2m ? current.temperature_2m - 5 : 18)),
    humidity: Math.round(current?.relative_humidity_2m ?? 50),
    windSpeed: Math.round(current?.wind_speed_10m ?? 8),
    hourly: hourlyForecast,
    lastUpdated: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    isCelsius
  };

  try {
    localStorage.setItem(
      cacheKey,
      JSON.stringify({ data: weatherData, timestamp: Date.now() })
    );
  } catch {
    // quota exceeded fallback
  }

  return weatherData;
}

export async function searchLocations(query: string): Promise<Array<{ name: string; admin1?: string; country: string; lat: number; lon: number }>> {
  if (!query || query.trim().length < 2) return [];
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query.trim())}&count=8&language=en&format=json`;
  const res = await fetch(url);
  if (!res.ok) return [];
  const json = await res.json();
  if (!json.results) return [];

  return json.results.map((r: { name: string; admin1?: string; country?: string; latitude: number; longitude: number }) => ({
    name: r.name,
    admin1: r.admin1 || '',
    country: r.country || '',
    lat: r.latitude,
    lon: r.longitude
  }));
}

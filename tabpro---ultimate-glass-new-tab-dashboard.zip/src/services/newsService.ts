import { NewsArticle } from '../types';

const NEWS_API_KEY = '76ca30ef394b44a5b3236831f2f8d637';

const FALLBACK_ARTICLES: Record<string, NewsArticle[]> = {
  general: [
    {
      id: 'gen-1',
      title: 'Global Tech Breakthroughs: Next-Gen AI & Sustainable Computing Architecture',
      description: 'Major technology leaders announce landmark agreements on next-generation computing efficiency and clean energy data centers.',
      url: 'https://news.google.com',
      source: 'Global Tech Wire',
      publishedAt: 'Just now'
    },
    {
      id: 'gen-2',
      title: 'Space Exploration Milestone: Deep Space Telescope Captures Cosmic Aurora',
      description: 'Spectacular new images reveal atmospheric chemical composition on distant exoplanets with unprecedented resolution.',
      url: 'https://news.google.com',
      source: 'Astro Science',
      publishedAt: '25m ago'
    },
    {
      id: 'gen-3',
      title: 'Clean Energy Supergrid Expansion Accelerates Across Asian & European Corridors',
      description: 'High-voltage DC interconnectors cross major international waters, boosting renewable power distribution.',
      url: 'https://news.google.com',
      source: 'Renewable Daily',
      publishedAt: '1h ago'
    }
  ],
  technology: [
    {
      id: 'tech-1',
      title: 'WebAssembly & WebGPU Deliver Desktop-Class Fluidity Inside Next-Gen Browsers',
      description: 'Developers report native 120fps graphics processing and low-latency local neural network inferences in modern web runtimes.',
      url: 'https://news.google.com',
      source: 'Ars Technica',
      publishedAt: '10m ago'
    },
    {
      id: 'tech-2',
      title: 'Semiconductor Foundry Roadmap Unveils 1.4nm RibbonFET Node Production Timelines',
      description: 'Extreme ultraviolet lithography yields breakthrough power-performance density targets for mobile and workstation silicon.',
      url: 'https://news.google.com',
      source: 'Silicon Index',
      publishedAt: '40m ago'
    },
    {
      id: 'tech-3',
      title: 'Quantum Key Cryptography Standards Adopted for Cloud Infrastructure Defense',
      description: 'Post-quantum mathematical encryption algorithms are rolled out across secure browser handshakes worldwide.',
      url: 'https://news.google.com',
      source: 'Cyber Sec Review',
      publishedAt: '2h ago'
    }
  ],
  business: [
    {
      id: 'bus-1',
      title: 'Global Markets Rally as Tech Innovation Fuels Solid Corporate Earnings',
      description: 'Indexes reach fresh quarterly highs led by semiconductor, software infrastructure, and renewable energy sectors.',
      url: 'https://news.google.com',
      source: 'Financial Express',
      publishedAt: '15m ago'
    },
    {
      id: 'bus-2',
      title: 'Venture Capital Inflows Double for Edge Computing & Robotics Startups',
      description: 'Early-stage funding rounds witness unprecedented valuation discipline and rapid commercial adoption.',
      url: 'https://news.google.com',
      source: 'Bloomberg Markets',
      publishedAt: '1h ago'
    }
  ],
  science: [
    {
      id: 'sci-1',
      title: 'Breakthrough Fusion Experiment Sustains Net Positive Energy Output',
      description: 'Magnetic confinement tokamak maintains stable burning plasma for record duration in milestone demonstration.',
      url: 'https://news.google.com',
      source: 'Nature News',
      publishedAt: '30m ago'
    },
    {
      id: 'sci-2',
      title: 'New Deep Ocean Expedition Documents Hundreds of Bioluminescent Species',
      description: 'Autonomous submarine submersibles discover thriving abyssal ecosystems around newly mapped hydrothermal vents.',
      url: 'https://news.google.com',
      source: 'Oceanographic Journal',
      publishedAt: '2h ago'
    }
  ]
};

export async function fetchTopHeadlines(category: string = 'general'): Promise<NewsArticle[]> {
  const cacheKey = `tabpro_news_${category}`;
  const cached = localStorage.getItem(cacheKey);

  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Date.now() - parsed.timestamp < 15 * 60 * 1000) {
        return parsed.data;
      }
    } catch {}
  }

  try {
    const url = `https://newsapi.org/v2/top-headlines?category=${category}&language=en&pageSize=8&apiKey=${NEWS_API_KEY}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`News API status: ${res.status}`);
    const json = await res.json();

    if (json.articles && Array.isArray(json.articles) && json.articles.length > 0) {
      const articles: NewsArticle[] = json.articles
        .filter((a: any) => a.title && a.title !== '[Removed]')
        .map((a: any, idx: number) => ({
          id: `news-${category}-${idx}-${Date.now()}`,
          title: a.title,
          description: a.description || '',
          url: a.url || '#',
          source: a.source?.name || 'News Source',
          publishedAt: a.publishedAt ? new Date(a.publishedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Recent',
          urlToImage: a.urlToImage
        }));

      localStorage.setItem(cacheKey, JSON.stringify({ data: articles, timestamp: Date.now() }));
      return articles;
    }
  } catch (err) {
    // If CORS or rate-limit happens, gracefully fallback
    console.warn('News API fetch fallback:', err);
  }

  return FALLBACK_ARTICLES[category] || FALLBACK_ARTICLES['general'];
}

export interface Wallpaper {
  id: string;
  title: string;
  url: string;
  isVideo: boolean;
  category: 'live' | 'image' | 'custom';
  thumbnail?: string;
}

export interface SongTrack {
  id: string;
  title: string;
  artist: string;
  url: string;
  isYt: boolean;
  duration?: number;
  albumArt?: string;
}

export interface DigitalClockSettings {
  font: string; // from 32 Google Fonts
  colorMode: 'solid' | 'gradient';
  solidColor: string;
  gradientFrom: string;
  gradientTo: string;
  gradientAngle: number;
  fontSize: number; // in px
  is12h: boolean;
  showSeconds: boolean;
  showDate: boolean;
  scale: number;
}

export interface AnalogClockSettings {
  theme: 'cream' | 'dark' | 'glass' | 'titanium';
  showSeconds: boolean;
  smoothSweep: boolean;
  size: number; // in px
  showNumerals: boolean;
}

export interface ElementPosition {
  x: number;
  y: number;
}

export interface TodoItem {
  id: string;
  text: string;
  completed: boolean;
  createdAt: number;
}

export interface NewsArticle {
  id: string;
  title: string;
  description?: string;
  url: string;
  source: string;
  publishedAt?: string;
  urlToImage?: string;
}

export interface PasswordSettings {
  length: number;
  useUpper: boolean;
  useLower: boolean;
  useNumbers: boolean;
  useSymbols: boolean;
}

export type ElementThemeStyle = 'oled' | 'glass' | 'aurora' | 'titanium' | 'gold';
export type ElementThemeOverride = 'inherit' | ElementThemeStyle;

export type ElementKey =
  | 'island'
  | 'digitalClock'
  | 'analogClock'
  | 'searchBar'
  | 'weather'
  | 'calendar'
  | 'todo'
  | 'passwordGen'
  | 'news'
  | 'dock';

export type ElementScales = Record<ElementKey, number>;
export type ElementThemes = Record<ElementKey, ElementThemeOverride>;

export interface AppActivityEntry {
  id: string;
  title: string;
  url: string;
  status: 'open' | 'closed';
  openedAt: number;
  closedAt?: number;
}

export interface LayoutSettings {
  // Island
  islandScale: number;
  islandTop: number;

  // Visibility
  showDynamicIsland: boolean;
  showCenterClock: boolean;
  showAnalogClock: boolean;
  showSearchBar: boolean;
  showWeather: boolean;
  showCalendar: boolean;
  showBottomDock: boolean;
  showTodo: boolean;
  showNews: boolean;
  showPasswordGen: boolean;

  // Positions (custom drag coordinates)
  islandPos: ElementPosition;
  centerClockPos: ElementPosition;
  searchBarPos: ElementPosition;
  analogClockPos: ElementPosition;
  weatherPos: ElementPosition;
  calendarPos: ElementPosition;
  sideWidgetsPos: ElementPosition;
  dockPos: ElementPosition;
  todoPos: ElementPosition;
  newsPos: ElementPosition;
  passwordPos: ElementPosition;

  // Per-element Sizes & Themes
  elementScales: ElementScales;
  elementThemes: ElementThemes;

  sideAlign: 'left' | 'right';
  dockBottom: number;
  dockScale: number;
  searchWidth: number;
  searchYPercent: number;

  // Appearance & Themes
  themeStyle: ElementThemeStyle;
  accentColor: string;
  dashboardBrightness: number;
  dashboardBlur: number;
  dashboardContrast: number;
  dashboardSaturate: number;
  mediaVolume: number;
  isZenMode: boolean;
  dragModeEnabled: boolean;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  time?: string;
  color?: string;
  category?: string;
}

export interface HourlyForecast {
  timeStr: string;
  temp: number;
  weatherCode: number;
  rainProb: number;
}

export interface WeatherData {
  city: string;
  region: string;
  temp: number;
  condition: string;
  weatherCode: number;
  feelsLike: number;
  high: number;
  low: number;
  humidity: number;
  windSpeed: number;
  hourly: HourlyForecast[];
  lastUpdated: string;
  isCelsius: boolean;
}

export interface IndianLocation {
  name: string;
  state: string;
  touristSpot: string;
  lat: number;
  lon: number;
  description: string;
}

export interface QuickApp {
  id: string;
  title: string;
  url: string;
  color: string;
  iconType: string; // e.g. 'google', 'gmail', 'youtube', 'github', 'x', 'spotify', 'chatgpt', 'custom'
  customIcon?: string;
}

export type SearchEngine = 'google' | 'youtube' | 'duckduckgo' | 'bing' | 'github' | 'reddit' | 'wikipedia' | 'x';

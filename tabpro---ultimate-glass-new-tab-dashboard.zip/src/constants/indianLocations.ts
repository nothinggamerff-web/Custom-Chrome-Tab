import { IndianLocation } from '../types';

export const INDIAN_LOCATIONS: IndianLocation[] = [
  {
    name: 'Gwalior',
    state: 'Madhya Pradesh',
    touristSpot: 'Gwalior Fort & Jai Vilas Palace',
    lat: 26.2183,
    lon: 78.1828,
    description: 'Historic city renowned for the majestic Gwalior Fort, Teli Ka Mandir, and royal Jai Vilas Palace.'
  },
  {
    name: 'Agra',
    state: 'Uttar Pradesh',
    touristSpot: 'Taj Mahal & Agra Fort',
    lat: 27.1767,
    lon: 78.0081,
    description: 'Home of the world wonder Taj Mahal, Agra Fort, and Mehtab Bagh along the Yamuna river.'
  },
  {
    name: 'Jaipur',
    state: 'Rajasthan',
    touristSpot: 'Hawa Mahal & Amber Palace',
    lat: 26.9124,
    lon: 75.7873,
    description: 'The Pink City famous for Hawa Mahal, Jal Mahal, City Palace, and grand Rajput architecture.'
  },
  {
    name: 'Varanasi',
    state: 'Uttar Pradesh',
    touristSpot: 'Kashi Vishwanath & Ganga Ghats',
    lat: 25.3176,
    lon: 82.9739,
    description: 'Spiritual capital of India on the sacred banks of the Ganges, famed for Ganga Aarti and ancient ghats.'
  },
  {
    name: 'New Delhi',
    state: 'Delhi NCR',
    touristSpot: 'India Gate & Red Fort',
    lat: 28.6139,
    lon: 77.2090,
    description: 'Capital metropolis showcasing India Gate, Qutub Minar, Humayun’s Tomb, and Lotus Temple.'
  },
  {
    name: 'Mumbai',
    state: 'Maharashtra',
    touristSpot: 'Gateway of India & Marine Drive',
    lat: 18.9220,
    lon: 72.8347,
    description: 'City of dreams with iconic Marine Drive, Elephanta Caves, and Arabian Sea promenades.'
  },
  {
    name: 'Goa',
    state: 'Goa',
    touristSpot: 'Baga Beach & Basilica of Bom Jesus',
    lat: 15.5527,
    lon: 73.7517,
    description: 'Coastal paradise renowned for pristine sandy beaches, Portuguese heritage churches, and water sports.'
  },
  {
    name: 'Shimla',
    state: 'Himachal Pradesh',
    touristSpot: 'Mall Road & Jakhoo Hill',
    lat: 31.1048,
    lon: 77.1734,
    description: 'Queen of the Hills set in pine-covered valleys with colonial charm, toy train, and snow-capped peaks.'
  },
  {
    name: 'Manali',
    state: 'Himachal Pradesh',
    touristSpot: 'Solang Valley & Rohtang Pass',
    lat: 32.2396,
    lon: 77.1887,
    description: 'Scenic Himalayan alpine haven known for Solang adventures, Atal Tunnel, and snowy valleys.'
  },
  {
    name: 'Udaipur',
    state: 'Rajasthan',
    touristSpot: 'City Palace & Lake Pichola',
    lat: 24.5854,
    lon: 73.7125,
    description: 'City of Lakes boasting romantic marble palaces, boat cruises on Lake Pichola, and Jag Mandir.'
  },
  {
    name: 'Munnar',
    state: 'Kerala',
    touristSpot: 'Tea Gardens & Anamudi Peak',
    lat: 10.0889,
    lon: 77.0595,
    description: 'God’s Own Country hill station with rolling emerald tea plantations, mist-covered cliffs, and waterfalls.'
  },
  {
    name: 'Rishikesh',
    state: 'Uttarakhand',
    touristSpot: 'Laxman Jhula & Triveni Ghat',
    lat: 30.0869,
    lon: 78.2676,
    description: 'Yoga capital of the world by the turquoise Himalayan Ganges, renowned for river rafting and meditation.'
  },
  {
    name: 'Amritsar',
    state: 'Punjab',
    touristSpot: 'Golden Temple (Harmandir Sahib)',
    lat: 31.6200,
    lon: 74.8765,
    description: 'Spiritual haven famed for the gilded Golden Temple, peaceful holy sarovar, and Wagah Border ceremony.'
  },
  {
    name: 'Khajuraho',
    state: 'Madhya Pradesh',
    touristSpot: 'Kandariya Mahadeva & Western Temples',
    lat: 24.8318,
    lon: 79.9199,
    description: 'UNESCO World Heritage site celebrated for ancient intricately sculpted Nagara-style stone temples.'
  },
  {
    name: 'Bengaluru',
    state: 'Karnataka',
    touristSpot: 'Lalbagh Glass House & Bangalore Palace',
    lat: 12.9716,
    lon: 77.5946,
    description: 'Garden City and tech hub with Lalbagh Botanical Gardens, Cubbon Park, and Tudor-style palaces.'
  },
  {
    name: 'Srinagar',
    state: 'Jammu & Kashmir',
    touristSpot: 'Dal Lake & Mughal Gardens',
    lat: 34.0837,
    lon: 74.7973,
    description: 'Paradise on Earth famed for Shikara rides on Dal Lake, houseboats, and vibrant Nishat Bagh gardens.'
  }
];

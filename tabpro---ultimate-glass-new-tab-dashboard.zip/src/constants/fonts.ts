export interface FontOption {
  name: string;
  family: string;
  category: 'Modern' | 'Display' | 'Serif' | 'Handwriting' | 'Sci-Fi / Cyber' | 'Bold & Heavy';
  previewText?: string;
}

export const CLOCK_FONTS: FontOption[] = [
  { name: 'Abril Fatface', family: "'Abril Fatface', cursive", category: 'Display' },
  { name: 'Acme', family: "'Acme', sans-serif", category: 'Modern' },
  { name: 'Alfa Slab One', family: "'Alfa Slab One', cursive", category: 'Bold & Heavy' },
  { name: 'Alegreya', family: "'Alegreya', serif", category: 'Serif' },
  { name: 'Anton', family: "'Anton', sans-serif", category: 'Bold & Heavy' },
  { name: 'Bebas Neue', family: "'Bebas Neue', sans-serif", category: 'Bold & Heavy' },
  { name: 'Black Ops One', family: "'Black Ops One', cursive", category: 'Sci-Fi / Cyber' },
  { name: 'Bungee', family: "'Bungee', cursive", category: 'Display' },
  { name: 'Changa', family: "'Changa', sans-serif", category: 'Modern' },
  { name: 'Cinzel', family: "'Cinzel', serif", category: 'Serif' },
  { name: 'Concert One', family: "'Concert One', cursive", category: 'Display' },
  { name: 'Cookie', family: "'Cookie', cursive", category: 'Handwriting' },
  { name: 'Cormorant Garamond', family: "'Cormorant Garamond', serif", category: 'Serif' },
  { name: 'Electrolize', family: "'Electrolize', sans-serif", category: 'Sci-Fi / Cyber' },
  { name: 'Fjalla One', family: "'Fjalla One', sans-serif", category: 'Bold & Heavy' },
  { name: 'Lilita One', family: "'Lilita One', cursive", category: 'Display' },
  { name: 'Lobster Two', family: "'Lobster Two', cursive", category: 'Handwriting' },
  { name: 'Lobster', family: "'Lobster', cursive", category: 'Handwriting' },
  { name: 'Merienda', family: "'Merienda', cursive", category: 'Handwriting' },
  { name: 'Noto Color Emoji', family: "'Noto Color Emoji', sans-serif", category: 'Display' },
  { name: 'Oleo Script', family: "'Oleo Script', cursive", category: 'Handwriting' },
  { name: 'Orbitron', family: "'Orbitron', sans-serif", category: 'Sci-Fi / Cyber' },
  { name: 'Paytone One', family: "'Paytone One', sans-serif", category: 'Bold & Heavy' },
  { name: 'Permanent Marker', family: "'Permanent Marker', cursive", category: 'Handwriting' },
  { name: 'Prata', family: "'Prata', serif", category: 'Serif' },
  { name: 'Rubik Bubbles', family: "'Rubik Bubbles', cursive", category: 'Display' },
  { name: 'Rubik Mono One', family: "'Rubik Mono One', monospace", category: 'Sci-Fi / Cyber' },
  { name: 'Silkscreen', family: "'Silkscreen', cursive", category: 'Sci-Fi / Cyber' },
  { name: 'Six Caps', family: "'Six Caps', sans-serif", category: 'Modern' },
  { name: 'Special Elite', family: "'Special Elite', cursive", category: 'Display' },
  { name: 'Titan One', family: "'Titan One', cursive", category: 'Bold & Heavy' },
  { name: 'Yeseva One', family: "'Yeseva One', cursive", category: 'Serif' },
];

export const GRADIENT_PRESETS = [
  { name: 'Cyber Sunset', from: '#ff5e62', to: '#ff9966', angle: 135 },
  { name: 'Neon Electric', from: '#00f2fe', to: '#4facfe', angle: 120 },
  { name: 'Aurora Borealis', from: '#43e97b', to: '#38f9d7', angle: 90 },
  { name: 'Cosmic Purple', from: '#b92b27', to: '#1565c0', angle: 145 },
  { name: 'Golden Glow', from: '#fce38a', to: '#f38181', angle: 110 },
  { name: 'Velvet Fuchsia', from: '#f857a6', to: '#ff5858', angle: 135 },
  { name: 'Clean White Glass', from: '#ffffff', to: '#94a3b8', angle: 180 },
  { name: 'Mint Fresh', from: '#a8ff78', to: '#78ffd6', angle: 100 },
];

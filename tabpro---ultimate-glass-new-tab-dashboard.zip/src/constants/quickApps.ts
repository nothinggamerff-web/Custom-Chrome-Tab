import { QuickApp } from '../types';

export const DEFAULT_QUICK_APPS: QuickApp[] = [
  {
    id: 'app-google',
    title: 'Google',
    url: 'https://www.google.com',
    color: '#4285F4',
    iconType: 'google'
  },
  {
    id: 'app-gmail',
    title: 'Gmail',
    url: 'https://mail.google.com',
    color: '#EA4335',
    iconType: 'gmail'
  },
  {
    id: 'app-youtube',
    title: 'YouTube',
    url: 'https://www.youtube.com',
    color: '#FF0000',
    iconType: 'youtube'
  },
  {
    id: 'app-github',
    title: 'GitHub',
    url: 'https://github.com',
    color: '#24292e',
    iconType: 'github'
  },
  {
    id: 'app-x',
    title: 'X',
    url: 'https://x.com',
    color: '#000000',
    iconType: 'x'
  },
  {
    id: 'app-spotify',
    title: 'Spotify',
    url: 'https://open.spotify.com',
    color: '#1DB954',
    iconType: 'spotify'
  },
  {
    id: 'app-chatgpt',
    title: 'ChatGPT',
    url: 'https://chatgpt.com',
    color: '#10a37f',
    iconType: 'chatgpt'
  },
  {
    id: 'app-maps',
    title: 'Google Maps',
    url: 'https://maps.google.com',
    color: '#34A853',
    iconType: 'maps'
  },
  {
    id: 'app-calendar',
    title: 'Google Calendar',
    url: 'https://calendar.google.com',
    color: '#1a73e8',
    iconType: 'calendar'
  }
];

import { Wallpaper } from '../types';

export const DEFAULT_LIVE_WALLPAPERS: Wallpaper[] = [
  {
    id: 'live-1',
    title: 'Neon Cyber Anime Room',
    url: 'https://s4.wallspace.app/wallpaper/155556311212381/previewhd.mp4',
    isVideo: true,
    category: 'live'
  },
  {
    id: 'live-2',
    title: 'Rainy Cyberpunk Tokyo Alley',
    url: 'https://s4.wallspace.app/wallpaper/972758623212835/previewhd.mp4',
    isVideo: true,
    category: 'live'
  },
  {
    id: 'live-3',
    title: 'Cosmic Horizon Odyssey',
    url: 'https://s4.wallspace.app/wallpaper/965267819737575/previewhd.mp4',
    isVideo: true,
    category: 'live'
  },
  {
    id: 'live-4',
    title: 'Lofi Chill Study Evening',
    url: 'https://s4.wallspace.app/wallpaper/715683899981696/previewhd.mp4',
    isVideo: true,
    category: 'live'
  },
  {
    id: 'live-5',
    title: 'Retro Synthwave Grid Sunset',
    url: 'https://s4.wallspace.app/wallpaper/213924118113497/previewhd.mp4',
    isVideo: true,
    category: 'live'
  },
  {
    id: 'live-6',
    title: 'Fluid Chromatic Aurora Loop',
    url: 'https://assets.awwwards.com/awards/element/2025/10/68e03906efd18063225322.mp4',
    isVideo: true,
    category: 'live'
  }
];

export const DEFAULT_IMAGE_WALLPAPERS: Wallpaper[] = [
  {
    id: 'img-1',
    title: 'Tokyo Night Horizon 4K',
    url: 'https://4kwallpapers.com/images/walls/thumbs_3t/27569.jpg',
    isVideo: false,
    category: 'image',
    thumbnail: 'https://4kwallpapers.com/images/walls/thumbs_3t/27569.jpg'
  },
  {
    id: 'img-2',
    title: 'Aesthetic Sunset Silhouette',
    url: 'https://i.pinimg.com/originals/b7/26/85/b726851e825ff112658fa410135ca1ad.jpg',
    isVideo: false,
    category: 'image',
    thumbnail: 'https://i.pinimg.com/originals/b7/26/85/b726851e825ff112658fa410135ca1ad.jpg'
  },
  {
    id: 'img-3',
    title: 'Minimalist Mountain Horizon',
    url: 'https://i.pinimg.com/originals/79/c9/16/79c916e7c16fdbaa838568ac5e9aca79.png',
    isVideo: false,
    category: 'image',
    thumbnail: 'https://i.pinimg.com/originals/79/c9/16/79c916e7c16fdbaa838568ac5e9aca79.png'
  },
  {
    id: 'img-4',
    title: 'Khyzyl Saleem Toyota 2000GT',
    url: 'https://japanesenostalgiccar.com/wordpress/wp-content/uploads/2015/09/Khyzyl-Saleem-Toyota-2000GT-02.jpg',
    isVideo: false,
    category: 'image',
    thumbnail: 'https://japanesenostalgiccar.com/wordpress/wp-content/uploads/2015/09/Khyzyl-Saleem-Toyota-2000GT-02.jpg'
  },
  {
    id: 'img-5',
    title: 'Anime Rooftop Dusk Serenity',
    url: 'https://i.pinimg.com/originals/f6/b5/6f/f6b56f1d4f3e91c7101f39df22013f57.jpg',
    isVideo: false,
    category: 'image',
    thumbnail: 'https://i.pinimg.com/originals/f6/b5/6f/f6b56f1d4f3e91c7101f39df22013f57.jpg'
  },
  {
    id: 'img-6',
    title: 'Khyzyl Saleem Nissan Silvia S15',
    url: 'https://japanesenostalgiccar.com/wordpress/wp-content/uploads/2015/09/Khyzyl-Saleem-Nissan-Silvia-S15.jpg',
    isVideo: false,
    category: 'image',
    thumbnail: 'https://japanesenostalgiccar.com/wordpress/wp-content/uploads/2015/09/Khyzyl-Saleem-Nissan-Silvia-S15.jpg'
  },
  {
    id: 'img-7',
    title: 'Khyzyl Saleem Toyota Celica Phantom',
    url: 'https://japanesenostalgiccar.com/wordpress/wp-content/uploads/2015/09/Khyzyl-Saleem-Toyota-Celica-Phantom.jpg',
    isVideo: false,
    category: 'image',
    thumbnail: 'https://japanesenostalgiccar.com/wordpress/wp-content/uploads/2015/09/Khyzyl-Saleem-Toyota-Celica-Phantom.jpg'
  },
  {
    id: 'img-8',
    title: 'Midnight Cyber City Rain',
    url: 'https://i.pinimg.com/originals/c4/85/cc/c485ccd4ef512dbe411bf886296bda13.jpg',
    isVideo: false,
    category: 'image',
    thumbnail: 'https://i.pinimg.com/originals/c4/85/cc/c485ccd4ef512dbe411bf886296bda13.jpg'
  },
  {
    id: 'img-9',
    title: 'Dark Aesthetic Abstract Glass',
    url: 'https://i.pinimg.com/originals/f1/aa/0c/f1aa0ce1352228e00bd541aac7e4fe3b.png',
    isVideo: false,
    category: 'image',
    thumbnail: 'https://i.pinimg.com/originals/f1/aa/0c/f1aa0ce1352228e00bd541aac7e4fe3b.png'
  },
  {
    id: 'img-10',
    title: 'Midnight Spider-Man Hero',
    url: 'https://images.hdqwalls.com/download/midnight-spiderman-hero-bf-1366x768.jpg',
    isVideo: false,
    category: 'image',
    thumbnail: 'https://images.hdqwalls.com/download/midnight-spiderman-hero-bf-1366x768.jpg'
  }
];

export const ALL_DEFAULT_WALLPAPERS: Wallpaper[] = [
  ...DEFAULT_LIVE_WALLPAPERS,
  ...DEFAULT_IMAGE_WALLPAPERS
];

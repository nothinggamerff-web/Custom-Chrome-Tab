import { ElementThemeOverride, ElementThemeStyle } from '../types';

export const resolveElementTheme = (
  override: ElementThemeOverride | undefined,
  globalTheme: ElementThemeStyle
): ElementThemeStyle => {
  if (!override || override === 'inherit') return globalTheme;
  return override;
};

export const getThemeSurfaceClasses = (theme: ElementThemeStyle): string => {
  switch (theme) {
    case 'oled':
      return 'bg-[#090b10]/88 text-white border-white/15 shadow-[0_18px_44px_rgba(0,0,0,0.72),inset_0_1px_0_rgba(255,255,255,0.18)]';
    case 'glass':
      return 'bg-white/14 text-white border-white/30 shadow-[0_16px_40px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.45)]';
    case 'aurora':
      return 'bg-gradient-to-br from-indigo-950/75 via-purple-950/65 to-cyan-950/75 text-white border-cyan-300/30 shadow-[0_16px_40px_rgba(56,189,248,0.22),inset_0_1px_0_rgba(165,243,252,0.35)]';
    case 'titanium':
      return 'bg-gradient-to-br from-slate-700/75 via-zinc-800/80 to-slate-900/85 text-white border-slate-300/45 shadow-[0_16px_40px_rgba(148,163,184,0.22),inset_0_1px_0_rgba(255,255,255,0.5)]';
    case 'gold':
      return 'bg-gradient-to-br from-[#231b0a]/85 via-[#382a0e]/80 to-[#1a1408]/90 text-amber-50 border-amber-400/40 shadow-[0_16px_40px_rgba(245,158,11,0.22),inset_0_1px_0_rgba(251,191,36,0.4)]';
    default:
      return 'bg-white/10 text-white border-white/20 shadow-[0_16px_40px_rgba(0,0,0,0.35),inset_0_1px_0_rgba(255,255,255,0.3)]';
  }
};

export const getIslandThemeClasses = (theme: ElementThemeStyle): string => {
  switch (theme) {
    case 'oled':
      return 'bg-black/95 text-white border-white/20 shadow-[0_24px_70px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(255,255,255,0.3)]';
    case 'glass':
      return 'bg-white/15 text-white border-white/35 shadow-[0_24px_65px_rgba(0,0,0,0.45),inset_0_1px_0_rgba(255,255,255,0.5)]';
    case 'aurora':
      return 'bg-gradient-to-br from-indigo-950/90 via-purple-950/85 to-cyan-950/90 text-white border-cyan-300/35 shadow-[0_24px_70px_rgba(56,189,248,0.25),inset_0_1px_0_rgba(165,243,252,0.4)]';
    case 'titanium':
      return 'bg-gradient-to-br from-slate-800/90 via-zinc-900/90 to-slate-950/95 text-white border-slate-300/45 shadow-[0_24px_70px_rgba(15,23,42,0.65),inset_0_1px_0_rgba(255,255,255,0.5)]';
    case 'gold':
      return 'bg-gradient-to-br from-[#1f1707]/95 via-[#2e210a]/90 to-[#140e04]/95 text-amber-50 border-amber-400/45 shadow-[0_24px_70px_rgba(245,158,11,0.25),inset_0_1px_0_rgba(251,191,36,0.45)]';
    default:
      return 'bg-black/90 text-white border-white/20 shadow-[0_24px_70px_rgba(0,0,0,0.85),inset_0_1px_0_rgba(255,255,255,0.35)]';
  }
};

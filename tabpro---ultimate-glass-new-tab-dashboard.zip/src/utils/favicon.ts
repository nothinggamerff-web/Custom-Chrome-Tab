export const getFaviconUrl = (url: string): string => {
  try {
    const cleanUrl = url.trim();
    if (!cleanUrl) return '';
    const parsed = new URL(cleanUrl.startsWith('http') ? cleanUrl : `https://${cleanUrl}`);
    return `https://www.google.com/s2/favicons?domain=${parsed.hostname}&sz=64`;
  } catch {
    return '';
  }
};

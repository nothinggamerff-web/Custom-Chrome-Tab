import React, { useRef, useState, useCallback } from 'react';
import { ElementPosition } from '../types';

interface UseDraggableOptions {
  position: ElementPosition;
  isDragMode?: boolean;
  onPositionChange?: (pos: ElementPosition) => void;
  minMargin?: number;
}

export function useDraggable({
  position,
  isDragMode = false,
  onPositionChange,
  minMargin = 4
}: UseDraggableOptions) {
  const elementRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const wasDraggedRef = useRef(false);

  const handlePointerDown = useCallback(
    (e: React.PointerEvent<HTMLElement>) => {
      if (!onPositionChange) return;
      if (e.button !== 0 && e.pointerType === 'mouse') return;

      const target = e.target as HTMLElement;

      // Always allow typing/editing inside form inputs
      if (target.closest('input, textarea, select, option, [contenteditable="true"]')) {
        return;
      }

      // Outside explicit Edit Layout mode, don't hijack clicks on buttons/links/sliders
      if (
        !isDragMode &&
        target.closest('button, a, label, iframe, [role="button"], [role="slider"], .no-drag')
      ) {
        return;
      }

      const el = elementRef.current;
      if (!el) return;

      const startClientX = e.clientX;
      const startClientY = e.clientY;
      const startPos = { x: position.x, y: position.y };
      const startRect = el.getBoundingClientRect();
      let moved = false;

      if (isDragMode) {
        e.preventDefault();
      }

      const handlePointerMove = (moveEvent: PointerEvent) => {
        const rawDx = moveEvent.clientX - startClientX;
        const rawDy = moveEvent.clientY - startClientY;

        if (!moved && Math.hypot(rawDx, rawDy) < 4) {
          return;
        }

        if (!moved) {
          moved = true;
          wasDraggedRef.current = true;
          setIsDragging(true);
        }

        const minDx = minMargin - startRect.left;
        const maxDx = window.innerWidth - minMargin - startRect.right;
        const minDy = minMargin - startRect.top;
        const maxDy = window.innerHeight - minMargin - startRect.bottom;

        const clampedDx =
          minDx <= maxDx ? Math.max(minDx, Math.min(maxDx, rawDx)) : rawDx;
        const clampedDy =
          minDy <= maxDy ? Math.max(minDy, Math.min(maxDy, rawDy)) : rawDy;

        onPositionChange({
          x: Math.round(startPos.x + clampedDx),
          y: Math.round(startPos.y + clampedDy)
        });
      };

      const handlePointerUp = () => {
        window.removeEventListener('pointermove', handlePointerMove);
        window.removeEventListener('pointerup', handlePointerUp);
        window.removeEventListener('pointercancel', handlePointerUp);
        setIsDragging(false);

        if (moved) {
          setTimeout(() => {
            wasDraggedRef.current = false;
          }, 50);
        }
      };

      window.addEventListener('pointermove', handlePointerMove);
      window.addEventListener('pointerup', handlePointerUp);
      window.addEventListener('pointercancel', handlePointerUp);
    },
    [isDragMode, minMargin, onPositionChange, position.x, position.y]
  );

  const handleClickCapture = useCallback((e: React.MouseEvent) => {
    if (wasDraggedRef.current) {
      e.preventDefault();
      e.stopPropagation();
      wasDraggedRef.current = false;
    }
  }, []);

  return {
    elementRef,
    isDragging,
    dragProps: {
      onPointerDown: handlePointerDown,
      onClickCapture: handleClickCapture
    }
  };
}

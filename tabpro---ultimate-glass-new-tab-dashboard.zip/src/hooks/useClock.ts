import { useState, useEffect } from 'react';

export interface ClockState {
  date: Date;
  hours12: number;
  hours24: number;
  minutes: number;
  seconds: number;
  milliseconds: number;
  ampm: 'AM' | 'PM';
  dateString: string;
  dayString: string;
  hourAngle: number;
  minuteAngle: number;
  secondAngleSmooth: number;
  secondAngleStep: number;
}

export function useClock(smooth: boolean = true): ClockState {
  const [date, setDate] = useState(() => new Date());

  useEffect(() => {
    let animId: number;
    if (smooth) {
      const update = () => {
        setDate(new Date());
        animId = requestAnimationFrame(update);
      };
      animId = requestAnimationFrame(update);
      return () => cancelAnimationFrame(animId);
    } else {
      const interval = setInterval(() => {
        setDate(new Date());
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [smooth]);

  const h = date.getHours();
  const m = date.getMinutes();
  const s = date.getSeconds();
  const ms = date.getMilliseconds();

  const hours12 = h % 12 || 12;
  const ampm = h >= 12 ? 'PM' : 'AM';

  // Smooth angles
  const secondAngleSmooth = (s + ms / 1000) * 6; // 360 / 60 = 6 deg/sec
  const secondAngleStep = s * 6;
  const minuteAngle = (m + s / 60) * 6;
  const hourAngle = ((h % 12) + m / 60 + s / 3600) * 30; // 360 / 12 = 30 deg/hour

  const dateString = date.toLocaleDateString(undefined, {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });

  const dayString = date.toLocaleDateString(undefined, {
    weekday: 'long'
  });

  return {
    date,
    hours12,
    hours24: h,
    minutes: m,
    seconds: s,
    milliseconds: ms,
    ampm,
    dateString,
    dayString,
    hourAngle,
    minuteAngle,
    secondAngleSmooth,
    secondAngleStep
  };
}

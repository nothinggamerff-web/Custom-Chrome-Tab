import React, { useState, useEffect } from 'react';
import {
  Wallpaper,
  SongTrack,
  DigitalClockSettings,
  AnalogClockSettings,
  LayoutSettings,
  CalendarEvent,
  QuickApp,
  TodoItem,
  ElementScales,
  ElementThemes,
  AppActivityEntry
} from './types';
import { useLocalStorage } from './hooks/useLocalStorage';
import { resolveElementTheme } from './utils/theme';
import { ALL_DEFAULT_WALLPAPERS } from './constants/wallpapers';
import { DEFAULT_QUICK_APPS } from './constants/quickApps';
import { WallpaperEngine } from './components/wallpaper/WallpaperEngine';
import { DynamicIsland } from './components/dynamic-island/DynamicIsland';
import { DigitalCenterClock } from './components/clock/DigitalCenterClock';
import { AnalogClockWidget } from './components/widgets/AnalogClockWidget';
import { MonthlyCalendarWidget } from './components/widgets/MonthlyCalendarWidget';
import { WeatherWidget } from './components/widgets/WeatherWidget';
import { TodoWidget } from './components/widgets/TodoWidget';
import { PasswordGeneratorWidget } from './components/widgets/PasswordGeneratorWidget';
import { NewsWidget } from './components/widgets/NewsWidget';
import { CenterSearchBar } from './components/search/CenterSearchBar';
import { BottomDock } from './components/dock/BottomDock';
import { QuickControlCenter } from './components/control-center/QuickControlCenter';
import { CustomizationDrawer } from './components/drawer/CustomizationDrawer';
import { WallpaperStudioDrawer } from './components/wallpaper/WallpaperStudioDrawer';
import { Sliders, Settings, Pencil, Move, Check } from 'lucide-react';

const DEFAULT_DIGITAL_CLOCK: DigitalClockSettings = {
  font: "'Bebas Neue', sans-serif",
  colorMode: 'gradient',
  solidColor: '#ffffff',
  gradientFrom: '#ff5e62',
  gradientTo: '#ff9966',
  gradientAngle: 135,
  fontSize: 72,
  is12h: true,
  showSeconds: true,
  showDate: true,
  scale: 1
};

const DEFAULT_ANALOG_CLOCK: AnalogClockSettings = {
  theme: 'cream',
  showSeconds: true,
  smoothSweep: true,
  size: 190,
  showNumerals: true
};

const DEFAULT_ELEMENT_SCALES: ElementScales = {
  island: 1,
  digitalClock: 1,
  analogClock: 1,
  searchBar: 1,
  weather: 1,
  calendar: 1,
  todo: 1,
  passwordGen: 1,
  news: 1,
  dock: 1
};

const DEFAULT_ELEMENT_THEMES: ElementThemes = {
  island: 'inherit',
  digitalClock: 'inherit',
  analogClock: 'inherit',
  searchBar: 'inherit',
  weather: 'inherit',
  calendar: 'inherit',
  todo: 'inherit',
  passwordGen: 'inherit',
  news: 'inherit',
  dock: 'inherit'
};

const DEFAULT_LAYOUT: LayoutSettings = {
  islandScale: 1,
  islandTop: 0,
  showDynamicIsland: true,
  showCenterClock: true,
  showAnalogClock: true,
  showSearchBar: true,
  showWeather: true,
  showCalendar: true,
  showBottomDock: true,
  showTodo: true,
  showNews: false,
  showPasswordGen: false,
  islandPos: { x: 0, y: 0 },
  centerClockPos: { x: 0, y: 0 },
  searchBarPos: { x: 0, y: 0 },
  analogClockPos: { x: 32, y: 24 },
  weatherPos: { x: 32, y: 230 },
  calendarPos: { x: 32, y: Math.max(380, window.innerHeight - 390) },
  sideWidgetsPos: { x: 32, y: 32 },
  dockPos: { x: 0, y: 0 },
  todoPos: { x: window.innerWidth - 320 > 0 ? window.innerWidth - 320 : 700, y: 80 },
  passwordPos: { x: window.innerWidth - 320 > 0 ? window.innerWidth - 320 : 700, y: 380 },
  newsPos: { x: window.innerWidth - 330 > 0 ? window.innerWidth - 330 : 680, y: 120 },
  elementScales: DEFAULT_ELEMENT_SCALES,
  elementThemes: DEFAULT_ELEMENT_THEMES,
  sideAlign: 'left',
  dockBottom: 24,
  dockScale: 1,
  searchWidth: 540,
  searchYPercent: 48,
  themeStyle: 'oled',
  accentColor: '#ff453a',
  dashboardBrightness: 100,
  dashboardBlur: 0,
  dashboardContrast: 100,
  dashboardSaturate: 100,
  mediaVolume: 80,
  isZenMode: false,
  dragModeEnabled: false
};

const DEFAULT_PLAYLIST: SongTrack[] = [
  {
    id: 'track-1',
    title: 'Midnight City Lights',
    artist: 'The Night Drivers',
    url: 'https://cdn.freesound.org/previews/568/568858_649468-lq.mp3',
    isYt: false
  },
  {
    id: 'track-2',
    title: 'Lofi Hip Hop Study Beat',
    artist: 'Lofi Girl / Ambient Beats',
    url: 'https://www.youtube.com/watch?v=jfKfPfyJRdk',
    isYt: true
  },
  {
    id: 'track-3',
    title: 'Chill Ambient Waves',
    artist: 'Aesthetic Chill Waves',
    url: 'https://cdn.freesound.org/previews/415/415510_5121236-lq.mp3',
    isYt: false
  }
];

const DEFAULT_TODOS: TodoItem[] = [
  { id: 'todo-1', text: 'Review TabPro Apple Liquid Glass UI', completed: true, createdAt: Date.now() - 3600000 },
  { id: 'todo-2', text: 'Customize Analog & Digital clock fonts', completed: false, createdAt: Date.now() - 1800000 },
  { id: 'todo-3', text: 'Test Gwalior weather & Indian tourist spots', completed: false, createdAt: Date.now() }
];

export default function App() {
  // Wallpaper state
  const [activeWallpaper, setActiveWallpaper] = useLocalStorage<Wallpaper>(
    'tabpro_active_wp',
    ALL_DEFAULT_WALLPAPERS[0]
  );
  const [customWallpapers, setCustomWallpapers] = useLocalStorage<Wallpaper[]>(
    'tabpro_custom_wps',
    []
  );

  // Layout & Settings state
  const [layout, setLayout] = useLocalStorage<LayoutSettings>('tabpro_layout_v3', DEFAULT_LAYOUT);

  // Clocks
  const [digitalClock, setDigitalClock] = useLocalStorage<DigitalClockSettings>(
    'tabpro_digital_clock',
    DEFAULT_DIGITAL_CLOCK
  );
  const [analogClock, setAnalogClock] = useLocalStorage<AnalogClockSettings>(
    'tabpro_analog_clock',
    DEFAULT_ANALOG_CLOCK
  );

  // Quick Apps
  const [quickApps, setQuickApps] = useLocalStorage<QuickApp[]>(
    'tabpro_quick_apps',
    DEFAULT_QUICK_APPS
  );

  // Playlist
  const [playlist, setPlaylist] = useLocalStorage<SongTrack[]>(
    'tabpro_playlist',
    DEFAULT_PLAYLIST
  );

  // Calendar Events
  const [events, setEvents] = useLocalStorage<CalendarEvent[]>('tabpro_events', [
    {
      id: 'event-init',
      title: 'Design Review & Standup',
      date: new Date().toISOString().split('T')[0],
      time: '11:00 AM',
      color: '#ff453a'
    }
  ]);

  // To-Dos
  const [todos, setTodos] = useLocalStorage<TodoItem[]>('tabpro_todos', DEFAULT_TODOS);

  // Recent & Current App Activity (for Dynamic Island System Connectivity)
  const [appActivity, setAppActivity] = useLocalStorage<AppActivityEntry[]>('tabpro_app_activity', []);

  // Drawers
  const [showControlCenter, setShowControlCenter] = useState(false);
  const [showCustomizerDrawer, setShowCustomizerDrawer] = useState(false);
  const [customizerDrawerTab, setCustomizerDrawerTab] = useState('clock');
  const [showWallpaperStudio, setShowWallpaperStudio] = useState(false);

  // Keyboard shortcut: 'f' for Focus/Zen mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.key.toLowerCase() === 'f' &&
        !['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName || '')
      ) {
        setLayout((prev) => ({ ...prev, isZenMode: !prev.isZenMode }));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setLayout]);

  // Event handlers
  const handleAddEvent = (evt: Omit<CalendarEvent, 'id'>) => {
    setEvents((prev) => [{ ...evt, id: `evt-${Date.now()}` }, ...prev]);
  };
  const handleDeleteEvent = (id: string) => {
    setEvents((prev) => prev.filter((e) => e.id !== id));
  };

  // Track handlers
  const handleAddTrack = (track: SongTrack) => {
    setPlaylist((prev) => [...prev, track]);
  };
  const handleDeleteTrack = (id: string) => {
    setPlaylist((prev) => prev.filter((t) => t.id !== id));
  };

  // Quick app handlers
  const handleAddQuickApp = (app: QuickApp) => {
    setQuickApps((prev) => [...prev, app]);
  };
  const handleRemoveQuickApp = (id: string) => {
    setQuickApps((prev) => prev.filter((a) => a.id !== id));
  };

  // Todo handlers
  const handleAddTodo = (text: string) => {
    setTodos((prev) => [
      { id: `todo-${Date.now()}`, text, completed: false, createdAt: Date.now() },
      ...prev
    ]);
  };
  const handleToggleTodo = (id: string) => {
    setTodos((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };
  const handleDeleteTodo = (id: string) => {
    setTodos((prev) => prev.filter((t) => t.id !== id));
  };

  // App activity handlers (System Connectivity)
  const handleLaunchApp = (title: string, url: string) => {
    const now = Date.now();
    setAppActivity((prev) => {
      const filtered = prev.filter((item) => !(item.url === url && item.status === 'open'));
      const entry: AppActivityEntry = {
        id: `act-${now}`,
        title,
        url,
        status: 'open',
        openedAt: now
      };
      return [entry, ...filtered].slice(0, 20);
    });
  };

  const handleCloseAppActivity = (id: string) => {
    const now = Date.now();
    setAppActivity((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: 'closed', closedAt: now } : item))
    );
  };

  const handleClearAppActivity = () => {
    setAppActivity([]);
  };

  // Reset defaults
  const handleResetDefaults = () => {
    if (window.confirm('Reset all layout, font, and widget settings to original defaults?')) {
      setLayout(DEFAULT_LAYOUT);
      setDigitalClock(DEFAULT_DIGITAL_CLOCK);
      setAnalogClock(DEFAULT_ANALOG_CLOCK);
      setActiveWallpaper(ALL_DEFAULT_WALLPAPERS[0]);
    }
  };

  const isZenMode = layout.isZenMode;
  const isDragMode = layout.dragModeEnabled;
  const safeScales: ElementScales = { ...DEFAULT_ELEMENT_SCALES, ...(layout.elementScales || {}) };
  const safeThemes: ElementThemes = { ...DEFAULT_ELEMENT_THEMES, ...(layout.elementThemes || {}) };

  return (
    <div className={`relative w-screen h-screen overflow-hidden text-white font-sans ${layout.themeStyle}`}>
      {/* 1. WALLPAPER ENGINE (Live Video & Static 4K) */}
      <WallpaperEngine wallpaper={activeWallpaper} layout={layout} />

      {/* 2. DYNAMIC ISLAND (Top Center, Draggable) */}
      {layout.showDynamicIsland && (
        <DynamicIsland
          layout={layout}
          playlist={playlist}
          onAddTrack={handleAddTrack}
          onDeleteTrack={handleDeleteTrack}
          onOpenControlCenter={() => setShowControlCenter(true)}
          onOpenWallpaperStudio={() => setShowWallpaperStudio(true)}
          onOpenDrawer={() => {
            setCustomizerDrawerTab('clock');
            setShowCustomizerDrawer(true);
          }}
          position={layout.islandPos || { x: 0, y: 0 }}
          isDragMode={isDragMode}
          onPositionChange={(pos) => setLayout((prev) => ({ ...prev, islandPos: pos }))}
          scale={safeScales.island}
          themeStyle={resolveElementTheme(safeThemes.island, layout.themeStyle)}
          appActivity={appActivity}
          onLaunchApp={handleLaunchApp}
          onCloseAppActivity={handleCloseAppActivity}
          onClearAppActivity={handleClearAppActivity}
          accentColor={layout.accentColor}
        />
      )}

      {/* 4. TOP RIGHT QUICK LAUNCHERS (Control Center & Customizer) */}
      <div className="fixed top-5 right-6 z-30 flex items-center gap-2">
        {isDragMode && (
          <div className="px-3 py-1 rounded-full bg-emerald-500 text-black text-[10px] font-extrabold uppercase tracking-wider animate-pulse shadow-md flex items-center gap-1.5">
            <Move className="w-3 h-3" />
            Drag Mode Enabled
          </div>
        )}

        {isZenMode && (
          <button
            onClick={() => setLayout((prev) => ({ ...prev, isZenMode: false }))}
            className="px-3 py-1.5 rounded-full bg-amber-500 text-black text-xs font-bold shadow-lg hover:bg-amber-400 transition-colors flex items-center gap-1.5"
            title="Exit Zen / Focus Mode"
          >
            <span>👁️ Focus Active</span>
            <span className="text-[10px] font-mono opacity-80">(F)</span>
          </button>
        )}

        <button
          onClick={() => setShowControlCenter(true)}
          className="w-10 h-10 rounded-2xl bg-white/10 hover:bg-white/20 backdrop-blur-xl border border-white/25 flex items-center justify-center text-white/90 hover:text-white shadow-lg transition-all hover:scale-105 active:scale-95"
          title="Open Quick Control Center"
        >
          <Sliders className="w-4 h-4" />
        </button>

        <button
          onClick={() => {
            setCustomizerDrawerTab('layout');
            setShowCustomizerDrawer(true);
          }}
          className="w-10 h-10 rounded-2xl bg-white/10 hover:bg-white/20 backdrop-blur-xl border border-white/25 flex items-center justify-center text-white/90 hover:text-white shadow-lg transition-all hover:scale-105 active:scale-95"
          title="Open Element Customizer Studio"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>

      {/* 5. CENTER HERO AREA (Digital Clock Upper of Search + Center Search Bar) */}
      <div className="fixed inset-0 pointer-events-none flex flex-col items-center justify-center">
        <div className="pointer-events-none flex flex-col items-center gap-4 -mt-10 sm:-mt-14">
          {/* Digital Clock with 32 Google Fonts & Gradient Text */}
          {layout.showCenterClock && (
            <DigitalCenterClock
              settings={digitalClock}
              position={layout.centerClockPos}
              isDragMode={isDragMode}
              onPositionChange={(pos) => setLayout((prev) => ({ ...prev, centerClockPos: pos }))}
              scale={safeScales.digitalClock}
              themeStyle={resolveElementTheme(safeThemes.digitalClock, layout.themeStyle)}
            />
          )}

          {/* Center Search Bar with Google Favicon API Engine Logos */}
          {layout.showSearchBar && (
            <CenterSearchBar
              position={layout.searchBarPos}
              width={layout.searchWidth}
              isDragMode={isDragMode}
              onPositionChange={(pos) => setLayout((prev) => ({ ...prev, searchBarPos: pos }))}
              scale={safeScales.searchBar}
              themeStyle={resolveElementTheme(safeThemes.searchBar, layout.themeStyle)}
              onLaunchApp={handleLaunchApp}
              accentColor={layout.accentColor}
            />
          )}
        </div>
      </div>

      {/* 6A. DRAGGABLE WEATHER WIDGET */}
      {layout.showWeather && !isZenMode && (
        <WeatherWidget
          position={layout.weatherPos || DEFAULT_LAYOUT.weatherPos}
          isDragMode={isDragMode}
          onPositionChange={(pos) => setLayout((prev) => ({ ...prev, weatherPos: pos }))}
          scale={safeScales.weather}
          themeStyle={resolveElementTheme(safeThemes.weather, layout.themeStyle)}
          accentColor={layout.accentColor}
        />
      )}

      {/* 6B. DRAGGABLE MONTHLY CALENDAR WIDGET */}
      {layout.showCalendar && !isZenMode && (
        <MonthlyCalendarWidget
          events={events}
          onAddEvent={handleAddEvent}
          onDeleteEvent={handleDeleteEvent}
          position={layout.calendarPos || DEFAULT_LAYOUT.calendarPos}
          isDragMode={isDragMode}
          onPositionChange={(pos) => setLayout((prev) => ({ ...prev, calendarPos: pos }))}
          scale={safeScales.calendar}
          accentColor={layout.accentColor}
          themeStyle={resolveElementTheme(safeThemes.calendar, layout.themeStyle)}
        />
      )}

      {/* 7. ANALOG CLOCK WIDGET */}
      {layout.showAnalogClock && !isZenMode && (
        <AnalogClockWidget
          settings={analogClock}
          position={layout.analogClockPos}
          isDragMode={isDragMode}
          onPositionChange={(pos) => setLayout((prev) => ({ ...prev, analogClockPos: pos }))}
          scale={safeScales.analogClock}
          themeStyle={safeThemes.analogClock === 'inherit' ? undefined : safeThemes.analogClock}
          accentColor={layout.accentColor}
        />
      )}

      {/* 8. DRAGGABLE TO-DO WIDGET (With Progress Bar) */}
      {layout.showTodo && !isZenMode && (
        <TodoWidget
          todos={todos}
          onAddTodo={handleAddTodo}
          onToggleTodo={handleToggleTodo}
          onDeleteTodo={handleDeleteTodo}
          position={layout.todoPos}
          isDragMode={isDragMode}
          onPositionChange={(pos) => setLayout((prev) => ({ ...prev, todoPos: pos }))}
          scale={safeScales.todo}
          themeStyle={resolveElementTheme(safeThemes.todo, layout.themeStyle)}
          accentColor={layout.accentColor}
        />
      )}

      {/* 9. DRAGGABLE PASSWORD GENERATOR WIDGET */}
      {layout.showPasswordGen && !isZenMode && (
        <PasswordGeneratorWidget
          position={layout.passwordPos}
          isDragMode={isDragMode}
          onPositionChange={(pos) => setLayout((prev) => ({ ...prev, passwordPos: pos }))}
          scale={safeScales.passwordGen}
          themeStyle={resolveElementTheme(safeThemes.passwordGen, layout.themeStyle)}
          accentColor={layout.accentColor}
        />
      )}

      {/* 10. DRAGGABLE NEWS HEADLINES WIDGET */}
      {layout.showNews && !isZenMode && (
        <NewsWidget
          position={layout.newsPos}
          isDragMode={isDragMode}
          onPositionChange={(pos) => setLayout((prev) => ({ ...prev, newsPos: pos }))}
          scale={safeScales.news}
          themeStyle={resolveElementTheme(safeThemes.news, layout.themeStyle)}
          onLaunchApp={handleLaunchApp}
          accentColor={layout.accentColor}
        />
      )}

      {/* 11. BOTTOM DOCK QUICK APPS (With Google Favicon API & Drag Support) */}
      {layout.showBottomDock && !isZenMode && (
        <BottomDock
          apps={quickApps}
          onAddApp={handleAddQuickApp}
          onRemoveApp={handleRemoveQuickApp}
          onLaunchApp={handleLaunchApp}
          position={layout.dockPos}
          isDragMode={isDragMode}
          onPositionChange={(pos) => setLayout((prev) => ({ ...prev, dockPos: pos }))}
          scale={safeScales.dock}
          themeStyle={resolveElementTheme(safeThemes.dock, layout.themeStyle)}
        />
      )}

      {/* 12. DEDICATED EDIT BUTTON AT RIGHT-BOTTOM (To toggle drag & drop mode!) */}
      <div className="fixed bottom-6 right-6 z-40 flex items-center">
        <button
          onClick={() =>
            setLayout((prev) => ({
              ...prev,
              dragModeEnabled: !prev.dragModeEnabled
            }))
          }
          className={`h-12 px-4 rounded-2xl flex items-center gap-2 font-bold text-xs shadow-2xl transition-all duration-300 active:scale-95 border backdrop-blur-2xl ${
            isDragMode
              ? 'bg-emerald-500 hover:bg-emerald-400 text-black border-emerald-400 shadow-[0_10px_30px_rgba(16,185,129,0.5)]'
              : 'bg-white/10 hover:bg-white/20 text-white border-white/25 shadow-[0_10px_30px_rgba(0,0,0,0.5)]'
          }`}
          title={isDragMode ? 'Lock Layout / Exit Drag Mode' : 'Edit Layout / Drag & Drop Elements'}
        >
          {isDragMode ? (
            <>
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Done Editing</span>
            </>
          ) : (
            <>
              <Pencil className="w-4 h-4" />
              <span>Edit Layout</span>
            </>
          )}
        </button>
      </div>

      {/* 13. QUICK CONTROL CENTER */}
      <QuickControlCenter
        isOpen={showControlCenter}
        onClose={() => setShowControlCenter(false)}
        layout={layout}
        onUpdateLayout={setLayout}
        onOpenEditControls={() => {
          setShowControlCenter(false);
          setCustomizerDrawerTab('visibility');
          setShowCustomizerDrawer(true);
        }}
      />

      {/* 14. ELEMENT CUSTOMIZER STUDIO (Right-Side Liquid Glass Drawer without screen blur) */}
      <CustomizationDrawer
        isOpen={showCustomizerDrawer}
        onClose={() => setShowCustomizerDrawer(false)}
        layout={layout}
        onUpdateLayout={setLayout}
        digitalClock={digitalClock}
        onUpdateDigitalClock={setDigitalClock}
        analogClock={analogClock}
        onUpdateAnalogClock={setAnalogClock}
        initialTab={customizerDrawerTab}
        onResetDefaults={handleResetDefaults}
      />

      {/* 15. WALLPAPER STUDIO (Right-Side Liquid Glass Drawer without screen blur) */}
      <WallpaperStudioDrawer
        isOpen={showWallpaperStudio}
        onClose={() => setShowWallpaperStudio(false)}
        activeWallpaper={activeWallpaper}
        onSelectWallpaper={setActiveWallpaper}
        customWallpapers={customWallpapers}
        onAddCustomWallpaper={(wp) => setCustomWallpapers((prev) => [wp, ...prev])}
        onAddCustomWallpapers={(wps) => setCustomWallpapers((prev) => [...wps, ...prev])}
        onDeleteCustomWallpaper={(id) => setCustomWallpapers((prev) => prev.filter((w) => w.id !== id))}
      />
    </div>
  );
}
